//
//  BackupService.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Backup, export, and import functionality
//

import Foundation
import CoreData
import UIKit

/// Service for backing up and restoring data
class BackupService: ObservableObject {
    
    // MARK: - Singleton
    static let shared = BackupService()
    
    // MARK: - Properties
    private let persistence = PersistenceService.shared
    
    @Published var isExporting: Bool = false
    @Published var isImporting: Bool = false
    @Published var lastBackupDate: Date?
    
    // MARK: - Initialization
    
    private init() {
        loadLastBackupDate()
    }
    
    // MARK: - Full Backup
    
    /// Create complete backup of all data
    func createFullBackup(completion: @escaping (Result<URL, Error>) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            DispatchQueue.main.async {
                self.isExporting = true
            }
            
            do {
                let backup = self.generateBackupData()
                let url = try self.saveBackupToFile(backup)
                self.updateLastBackupDate()
                
                DispatchQueue.main.async {
                    self.isExporting = false
                    completion(.success(url))
                }
            } catch {
                DispatchQueue.main.async {
                    self.isExporting = false
                    completion(.failure(error))
                }
            }
        }
    }
    
    /// Generate backup data structure
    private func generateBackupData() -> BackupData {
        var backup = BackupData()
        backup.version = "1.0"
        backup.timestamp = Date()
        backup.appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
        
        // Export conversations
        backup.conversations = exportConversations()
        
        // Export symbol usages
        backup.symbolUsages = exportSymbolUsages()
        
        // Export custom symbols
        backup.customSymbols = exportCustomSymbols()
        
        // Export sessions
        backup.sessions = exportSessions()
        
        return backup
    }
    
    // MARK: - Export Individual Data Types
    
    private func exportConversations() -> [ExportedConversation] {
        let conversations = ConversationEntity.fetchAll(in: persistence.viewContext)
        
        return conversations.compactMap { conversation in
            guard let id = conversation.id,
                  let text = conversation.text,
                  let timestamp = conversation.timestamp,
                  let symbolIds = conversation.symbolIds else {
                return nil
            }
            
            return ExportedConversation(
                id: id.uuidString,
                text: text,
                symbolIds: symbolIds,
                timestamp: timestamp,
                duration: conversation.duration
            )
        }
    }
    
    private func exportSymbolUsages() -> [ExportedSymbolUsage] {
        let usages = SymbolUsageEntity.fetchAll(in: persistence.viewContext)
        
        return usages.compactMap { usage in
            guard let id = usage.id,
                  let symbolId = usage.symbolId,
                  let label = usage.label else {
                return nil
            }
            
            return ExportedSymbolUsage(
                id: id.uuidString,
                symbolId: symbolId,
                label: label,
                category: usage.category,
                usageCount: Int(usage.usageCount),
                firstUsed: usage.firstUsed,
                lastUsed: usage.lastUsed
            )
        }
    }
    
    private func exportCustomSymbols() -> [ExportedCustomSymbol] {
        let symbols = CustomSymbolEntity.fetchAll(in: persistence.viewContext)
        
        return symbols.compactMap { symbol in
            guard let id = symbol.id,
                  let label = symbol.label,
                  let imageData = symbol.imageData else {
                return nil
            }
            
            // Convert image data to base64 for JSON
            let base64Image = imageData.base64EncodedString()
            
            return ExportedCustomSymbol(
                id: id.uuidString,
                label: label,
                imageData: base64Image,
                category: symbol.category,
                tags: symbol.tags,
                createdAt: symbol.createdAt,
                lastModified: symbol.lastModified,
                usageCount: Int(symbol.usageCount),
                isFavorite: symbol.isFavorite
            )
        }
    }
    
    private func exportSessions() -> [ExportedSession] {
        let sessions = SessionEntity.fetchAll(in: persistence.viewContext)
        
        return sessions.compactMap { session in
            guard let id = session.id,
                  let startTime = session.startTime else {
                return nil
            }
            
            return ExportedSession(
                id: id.uuidString,
                startTime: startTime,
                endTime: session.endTime,
                phraseCount: Int(session.phraseCount),
                symbolCount: Int(session.symbolCount)
            )
        }
    }
    
    // MARK: - Save/Load Backup Files
    
    private func saveBackupToFile(_ backup: BackupData) throws -> URL {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        encoder.dateEncodingStrategy = .iso8601
        
        let jsonData = try encoder.encode(backup)
        
        // Create file in documents directory
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd_HHmmss"
        let dateString = dateFormatter.string(from: Date())
        let filename = "OpenVoice_Backup_\(dateString).json"
        let fileURL = documentsURL.appendingPathComponent(filename)
        
        try jsonData.write(to: fileURL)
        
        print("✅ Backup saved to: \(fileURL.path)")
        return fileURL
    }
    
    // MARK: - Import/Restore
    
    /// Restore from backup file
    func restoreFromBackup(
        fileURL: URL,
        replaceExisting: Bool = false,
        completion: @escaping (Result<RestoreResult, Error>) -> Void
    ) {
        DispatchQueue.global(qos: .userInitiated).async {
            DispatchQueue.main.async {
                self.isImporting = true
            }
            
            do {
                // Load backup file
                let backup = try self.loadBackupFromFile(fileURL)
                
                // Optionally clear existing data
                if replaceExisting {
                    self.persistence.clearAllData()
                }
                
                // Restore data
                let result = self.restoreBackupData(backup)
                
                DispatchQueue.main.async {
                    self.isImporting = false
                    completion(.success(result))
                }
            } catch {
                DispatchQueue.main.async {
                    self.isImporting = false
                    completion(.failure(error))
                }
            }
        }
    }
    
    private func loadBackupFromFile(_ fileURL: URL) throws -> BackupData {
        let data = try Data(contentsOf: fileURL)
        
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        
        let backup = try decoder.decode(BackupData.self, from: data)
        return backup
    }
    
    private func restoreBackupData(_ backup: BackupData) -> RestoreResult {
        var result = RestoreResult()
        let context = persistence.viewContext
        
        // Restore conversations
        for exportedConv in backup.conversations {
            _ = ConversationEntity.create(
                in: context,
                text: exportedConv.text,
                symbols: exportedConv.symbolIds,
                timestamp: exportedConv.timestamp,
                duration: exportedConv.duration
            )
            result.conversationsRestored += 1
        }
        
        // Restore custom symbols
        for exportedSymbol in backup.customSymbols {
            if let imageData = Data(base64Encoded: exportedSymbol.imageData) {
                _ = CustomSymbolEntity.create(
                    in: context,
                    label: exportedSymbol.label,
                    imageData: imageData,
                    category: exportedSymbol.category,
                    tags: exportedSymbol.tags
                )
                result.customSymbolsRestored += 1
            }
        }
        
        // Restore sessions
        for exportedSession in backup.sessions {
            let session = SessionEntity.create(
                in: context,
                startTime: exportedSession.startTime
            )
            session.endTime = exportedSession.endTime
            session.phraseCount = Int64(exportedSession.phraseCount)
            session.symbolCount = Int64(exportedSession.symbolCount)
            result.sessionsRestored += 1
        }
        
        // Save all changes
        persistence.save()
        
        print("✅ Restore complete: \(result)")
        return result
    }
    
    // MARK: - Export Formats
    
    /// Export to CSV
    func exportToCSV() -> URL? {
        let csvContent = ConversationHistoryService.shared.exportToCSV()
        
        do {
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd_HHmmss"
            let dateString = dateFormatter.string(from: Date())
            let filename = "OpenVoice_Conversations_\(dateString).csv"
            let fileURL = documentsURL.appendingPathComponent(filename)
            
            try csvContent.write(to: fileURL, atomically: true, encoding: .utf8)
            print("✅ CSV exported to: \(fileURL.path)")
            return fileURL
        } catch {
            print("❌ CSV export error: \(error)")
            return nil
        }
    }
    
    /// Export conversations only
    func exportConversationsJSON() -> URL? {
        guard let jsonData = ConversationHistoryService.shared.exportToJSON() else {
            return nil
        }
        
        do {
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd_HHmmss"
            let dateString = dateFormatter.string(from: Date())
            let filename = "OpenVoice_Conversations_\(dateString).json"
            let fileURL = documentsURL.appendingPathComponent(filename)
            
            try jsonData.write(to: fileURL)
            print("✅ Conversations JSON exported to: \(fileURL.path)")
            return fileURL
        } catch {
            print("❌ JSON export error: \(error)")
            return nil
        }
    }
    
    // MARK: - Last Backup Date
    
    private func loadLastBackupDate() {
        lastBackupDate = UserDefaults.standard.object(forKey: "LastBackupDate") as? Date
    }
    
    private func updateLastBackupDate() {
        let now = Date()
        UserDefaults.standard.set(now, forKey: "LastBackupDate")
        
        DispatchQueue.main.async {
            self.lastBackupDate = now
        }
    }
}

// MARK: - Supporting Types

/// Complete backup data structure
struct BackupData: Codable {
    var version: String = "1.0"
    var timestamp: Date = Date()
    var appVersion: String = ""
    var conversations: [ExportedConversation] = []
    var symbolUsages: [ExportedSymbolUsage] = []
    var customSymbols: [ExportedCustomSymbol] = []
    var sessions: [ExportedSession] = []
}

/// Exported conversation
struct ExportedConversation: Codable {
    let id: String
    let text: String
    let symbolIds: [String]
    let timestamp: Date
    let duration: Double
}

/// Exported symbol usage
struct ExportedSymbolUsage: Codable {
    let id: String
    let symbolId: String
    let label: String
    let category: String?
    let usageCount: Int
    let firstUsed: Date?
    let lastUsed: Date?
}

/// Exported custom symbol
struct ExportedCustomSymbol: Codable {
    let id: String
    let label: String
    let imageData: String // Base64 encoded
    let category: String?
    let tags: [String]?
    let createdAt: Date?
    let lastModified: Date?
    let usageCount: Int
    let isFavorite: Bool
}

/// Exported session
struct ExportedSession: Codable {
    let id: String
    let startTime: Date
    let endTime: Date?
    let phraseCount: Int
    let symbolCount: Int
}

/// Restore result
struct RestoreResult {
    var conversationsRestored: Int = 0
    var customSymbolsRestored: Int = 0
    var sessionsRestored: Int = 0
    
    var totalRestored: Int {
        return conversationsRestored + customSymbolsRestored + sessionsRestored
    }
}
