//
//  PersistenceService.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Core Data Stack and Manager
//

import Foundation
import CoreData
import UIKit

/// Main persistence service managing Core Data stack
/// Handles all database operations for OpenVoice
class PersistenceService: ObservableObject {
    
    // MARK: - Singleton
    static let shared = PersistenceService()
    
    // MARK: - Core Data Stack
    
    /// Main persistent container
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "OpenVoiceDataModel")
        
        // Configure for better performance
        let description = container.persistentStoreDescriptions.first
        description?.setOption(true as NSNumber, forKey: NSPersistentHistoryTrackingKey)
        description?.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
        
        container.loadPersistentStores { storeDescription, error in
            if let error = error as NSError? {
                // In production, handle this error appropriately
                print("❌ Core Data Error: \(error), \(error.userInfo)")
                fatalError("Unresolved Core Data error: \(error)")
            }
            print("✅ Core Data loaded: \(storeDescription.url?.lastPathComponent ?? "unknown")")
        }
        
        // Automatic merging from parent
        container.viewContext.automaticallyMergesChangesFromParent = true
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        
        return container
    }()
    
    /// Main view context (use on main thread)
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    /// Background context for heavy operations
    func newBackgroundContext() -> NSManagedObjectContext {
        let context = persistentContainer.newBackgroundContext()
        context.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        return context
    }
    
    // MARK: - Initialization
    
    private init() {
        // Force lazy loading of container
        _ = persistentContainer
    }
    
    // MARK: - Save Operations
    
    /// Save the view context
    func save() {
        save(context: viewContext)
    }
    
    /// Save a specific context
    func save(context: NSManagedObjectContext) {
        guard context.hasChanges else { return }
        
        do {
            try context.save()
            print("✅ Context saved successfully")
        } catch {
            print("❌ Save error: \(error.localizedDescription)")
            // Rollback on error
            context.rollback()
        }
    }
    
    /// Save with completion handler
    func save(completion: @escaping (Result<Void, Error>) -> Void) {
        guard viewContext.hasChanges else {
            completion(.success(()))
            return
        }
        
        do {
            try viewContext.save()
            completion(.success(()))
        } catch {
            completion(.failure(error))
        }
    }
    
    // MARK: - Background Save
    
    /// Perform operation in background context
    func performBackgroundTask(_ block: @escaping (NSManagedObjectContext) -> Void) {
        persistentContainer.performBackgroundTask { context in
            block(context)
            
            if context.hasChanges {
                do {
                    try context.save()
                } catch {
                    print("❌ Background save error: \(error.localizedDescription)")
                }
            }
        }
    }
    
    // MARK: - Fetch Operations
    
    /// Generic fetch request
    func fetch<T: NSManagedObject>(_ request: NSFetchRequest<T>) -> [T] {
        do {
            return try viewContext.fetch(request)
        } catch {
            print("❌ Fetch error: \(error.localizedDescription)")
            return []
        }
    }
    
    /// Fetch with predicate
    func fetch<T: NSManagedObject>(
        entityName: String,
        predicate: NSPredicate? = nil,
        sortDescriptors: [NSSortDescriptor]? = nil,
        limit: Int? = nil
    ) -> [T] {
        let request = NSFetchRequest<T>(entityName: entityName)
        request.predicate = predicate
        request.sortDescriptors = sortDescriptors
        if let limit = limit {
            request.fetchLimit = limit
        }
        return fetch(request)
    }
    
    /// Fetch single object
    func fetchFirst<T: NSManagedObject>(
        entityName: String,
        predicate: NSPredicate? = nil
    ) -> T? {
        let results: [T] = fetch(
            entityName: entityName,
            predicate: predicate,
            sortDescriptors: nil,
            limit: 1
        )
        return results.first
    }
    
    // MARK: - Count Operations
    
    /// Count objects matching predicate
    func count<T: NSManagedObject>(
        entityName: String,
        predicate: NSPredicate? = nil
    ) -> Int {
        let request = NSFetchRequest<T>(entityName: entityName)
        request.predicate = predicate
        
        do {
            return try viewContext.count(for: request)
        } catch {
            print("❌ Count error: \(error.localizedDescription)")
            return 0
        }
    }
    
    // MARK: - Delete Operations
    
    /// Delete a single object
    func delete(_ object: NSManagedObject) {
        viewContext.delete(object)
        save()
    }
    
    /// Delete multiple objects
    func delete(_ objects: [NSManagedObject]) {
        objects.forEach { viewContext.delete($0) }
        save()
    }
    
    /// Delete all objects of a type
    func deleteAll<T: NSManagedObject>(entityName: String) {
        let fetchRequest = NSFetchRequest<T>(entityName: entityName)
        
        do {
            let objects = try viewContext.fetch(fetchRequest)
            objects.forEach { viewContext.delete($0) }
            save()
            print("✅ Deleted \(objects.count) \(entityName) objects")
        } catch {
            print("❌ Delete all error: \(error.localizedDescription)")
        }
    }
    
    /// Batch delete (more efficient for large datasets)
    func batchDelete(entityName: String, predicate: NSPredicate? = nil) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.predicate = predicate
        
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        batchDeleteRequest.resultType = .resultTypeObjectIDs
        
        do {
            let result = try viewContext.execute(batchDeleteRequest) as? NSBatchDeleteResult
            let objectIDArray = result?.result as? [NSManagedObjectID] ?? []
            let changes = [NSDeletedObjectsKey: objectIDArray]
            NSManagedObjectContext.mergeChanges(fromRemoteContextSave: changes, into: [viewContext])
            print("✅ Batch deleted objects from \(entityName)")
        } catch {
            print("❌ Batch delete error: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Reset/Clear
    
    /// Clear all data from database
    func clearAllData() {
        let entities = persistentContainer.managedObjectModel.entities
        
        for entity in entities {
            guard let entityName = entity.name else { continue }
            batchDelete(entityName: entityName)
        }
        
        print("✅ All data cleared")
    }
    
    // MARK: - Database Statistics
    
    /// Get database statistics
    func getDatabaseStats() -> DatabaseStats {
        var stats = DatabaseStats()
        
        // Count conversations
        stats.conversationCount = count(entityName: "ConversationEntity") as Int
        
        // Count custom symbols
        stats.customSymbolCount = count(entityName: "CustomSymbolEntity") as Int
        
        // Count symbol usages
        stats.symbolUsageCount = count(entityName: "SymbolUsageEntity") as Int
        
        // Count sessions
        stats.sessionCount = count(entityName: "SessionEntity") as Int
        
        // Calculate total size (approximate)
        if let storeURL = persistentContainer.persistentStoreDescriptions.first?.url {
            do {
                let attributes = try FileManager.default.attributesOfItem(atPath: storeURL.path)
                stats.databaseSize = attributes[.size] as? Int64 ?? 0
            } catch {
                print("❌ Error getting database size: \(error)")
            }
        }
        
        return stats
    }
    
    // MARK: - Migration Support
    
    /// Check if migration is needed
    func needsMigration() -> Bool {
        guard let storeURL = persistentContainer.persistentStoreDescriptions.first?.url else {
            return false
        }
        
        do {
            let metadata = try NSPersistentStoreCoordinator.metadataForPersistentStore(
                ofType: NSSQLiteStoreType,
                at: storeURL,
                options: nil
            )
            
            let model = persistentContainer.managedObjectModel
            return !model.isConfiguration(withName: nil, compatibleWithStoreMetadata: metadata)
        } catch {
            return false
        }
    }
    
    // MARK: - Debugging
    
    /// Print database contents for debugging
    func printDatabaseContents() {
        let stats = getDatabaseStats()
        print("""
        
        📊 DATABASE STATS:
        - Conversations: \(stats.conversationCount)
        - Custom Symbols: \(stats.customSymbolCount)
        - Symbol Usages: \(stats.symbolUsageCount)
        - Sessions: \(stats.sessionCount)
        - Database Size: \(stats.databaseSize / 1024) KB
        
        """)
    }
}

// MARK: - Supporting Types

/// Database statistics
struct DatabaseStats {
    var conversationCount: Int = 0
    var customSymbolCount: Int = 0
    var symbolUsageCount: Int = 0
    var sessionCount: Int = 0
    var databaseSize: Int64 = 0
    
    var totalRecords: Int {
        return conversationCount + customSymbolCount + symbolUsageCount + sessionCount
    }
}
