//
//  AnalyticsService.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Local-only usage analytics (no data collection/tracking)
//

import Foundation
import CoreData
import Combine

/// Local analytics service for usage insights
/// All data stays on device - no tracking or data collection
class AnalyticsService: ObservableObject {
    
    // MARK: - Singleton
    static let shared = AnalyticsService()
    
    // MARK: - Properties
    private let persistence = PersistenceService.shared
    
    @Published var mostUsedSymbols: [SymbolUsageEntity] = []
    @Published var recentlyUsedSymbols: [SymbolUsageEntity] = []
    @Published var usageByCategory: [String: Int] = [:]
    @Published var dailyUsage: [Date: Int] = [:]
    
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Initialization
    
    private init() {
        loadAnalytics()
    }
    
    // MARK: - Symbol Usage Tracking
    
    /// Record symbol usage
    func recordSymbolUsage(
        symbolId: String,
        label: String,
        category: String? = nil
    ) {
        let context = persistence.viewContext
        
        // Record usage
        SymbolUsageEntity.recordUsage(
            symbolId: symbolId,
            label: label,
            category: category,
            in: context
        )
        
        // Get or create today's session and update it
        let session = SessionEntity.getTodaySession(in: context)
        session.symbolCount += 1
        
        // Save
        persistence.save()
        
        // Refresh analytics
        DispatchQueue.main.async {
            self.loadAnalytics()
        }
    }
    
    /// Record multiple symbol usages
    func recordSymbolUsages(_ symbols: [(id: String, label: String, category: String?)]) {
        persistence.performBackgroundTask { context in
            let session = SessionEntity.getTodaySession(in: context)
            
            for symbol in symbols {
                SymbolUsageEntity.recordUsage(
                    symbolId: symbol.id,
                    label: symbol.label,
                    category: symbol.category,
                    in: context
                )
            }
            
            session.symbolCount += Int64(symbols.count)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.loadAnalytics()
        }
    }
    
    // MARK: - Read Analytics
    
    /// Load all analytics data
    func loadAnalytics() {
        loadMostUsedSymbols()
        loadRecentlyUsedSymbols()
        loadUsageByCategory()
        loadDailyUsage()
    }
    
    /// Load most used symbols
    func loadMostUsedSymbols(limit: Int = 20) {
        let symbols = SymbolUsageEntity.fetchMostUsed(
            limit: limit,
            in: persistence.viewContext
        )
        
        DispatchQueue.main.async {
            self.mostUsedSymbols = symbols
        }
    }
    
    /// Load recently used symbols
    func loadRecentlyUsedSymbols(limit: Int = 20) {
        let symbols = SymbolUsageEntity.fetchRecentlyUsed(
            limit: limit,
            in: persistence.viewContext
        )
        
        DispatchQueue.main.async {
            self.recentlyUsedSymbols = symbols
        }
    }
    
    /// Load usage grouped by category
    func loadUsageByCategory() {
        let allUsages = SymbolUsageEntity.fetchAll(in: persistence.viewContext)
        
        var categoryMap: [String: Int] = [:]
        for usage in allUsages {
            let category = usage.category ?? "Uncategorized"
            categoryMap[category, default: 0] += Int(usage.usageCount)
        }
        
        DispatchQueue.main.async {
            self.usageByCategory = categoryMap
        }
    }
    
    /// Load daily usage for past N days
    func loadDailyUsage(days: Int = 30) {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let startDate = calendar.date(byAdding: .day, value: -days, to: today) ?? today
        
        // Get all sessions in range
        let sessions = SessionEntity.fetchBetween(
            startDate: startDate,
            endDate: Date(),
            in: persistence.viewContext
        )
        
        var dailyMap: [Date: Int] = [:]
        for session in sessions {
            if let start = session.startTime {
                let day = calendar.startOfDay(for: start)
                dailyMap[day, default: 0] += Int(session.phraseCount)
            }
        }
        
        DispatchQueue.main.async {
            self.dailyUsage = dailyMap
        }
    }
    
    // MARK: - Statistics
    
    /// Get comprehensive usage statistics
    func getUsageStatistics() -> UsageStatistics {
        var stats = UsageStatistics()
        
        // Total symbol usages
        stats.totalSymbolUsages = SymbolUsageEntity.totalUsageCount(
            in: persistence.viewContext
        )
        
        // Unique symbols used
        stats.uniqueSymbolsUsed = SymbolUsageEntity.count(
            in: persistence.viewContext
        ) as Int
        
        // Session stats
        stats.totalSessions = SessionEntity.count(in: persistence.viewContext)
        stats.totalTimeSpent = SessionEntity.totalTimeSpent(in: persistence.viewContext)
        stats.totalPhrases = SessionEntity.totalPhrases(in: persistence.viewContext)
        
        // Averages
        if stats.totalSessions > 0 {
            stats.averagePhrasesPerSession = Double(stats.totalPhrases) / Double(stats.totalSessions)
            stats.averageSymbolsPerSession = Double(stats.totalSymbolUsages) / Double(stats.totalSessions)
            stats.averageSessionDuration = stats.totalTimeSpent / Double(stats.totalSessions)
        }
        
        if stats.totalPhrases > 0 {
            stats.averageSymbolsPerPhrase = Double(stats.totalSymbolUsages) / Double(stats.totalPhrases)
        }
        
        // Most used symbol
        if let topSymbol = SymbolUsageEntity.fetchMostUsed(limit: 1, in: persistence.viewContext).first {
            stats.mostUsedSymbol = topSymbol.label
            stats.mostUsedSymbolCount = Int(topSymbol.usageCount)
        }
        
        // Custom symbols
        stats.customSymbolsCreated = CustomSymbolEntity.count(in: persistence.viewContext)
        stats.customSymbolsStorage = CustomSymbolEntity.totalStorageUsed(in: persistence.viewContext)
        
        return stats
    }
    
    /// Get usage trends
    func getUsageTrends(days: Int = 7) -> UsageTrends {
        var trends = UsageTrends()
        
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let startDate = calendar.date(byAdding: .day, value: -days, to: today) ?? today
        
        // Get sessions for period
        let sessions = SessionEntity.fetchBetween(
            startDate: startDate,
            endDate: Date(),
            in: persistence.viewContext
        )
        
        // Calculate daily averages
        var dailyPhrases: [Int] = []
        var dailySymbols: [Int] = []
        
        for day in 0..<days {
            let dayStart = calendar.date(byAdding: .day, value: -day, to: today) ?? today
            let dayEnd = calendar.date(byAdding: .day, value: 1, to: dayStart) ?? Date()
            
            let daySessions = sessions.filter { session in
                guard let start = session.startTime else { return false }
                return start >= dayStart && start < dayEnd
            }
            
            let phrases = daySessions.reduce(0) { $0 + Int($1.phraseCount) }
            let symbols = daySessions.reduce(0) { $0 + Int($1.symbolCount) }
            
            dailyPhrases.append(phrases)
            dailySymbols.append(symbols)
        }
        
        trends.dailyPhrases = dailyPhrases.reversed()
        trends.dailySymbols = dailySymbols.reversed()
        
        // Calculate trend direction
        if dailyPhrases.count >= 2 {
            let recentAvg = Double(dailyPhrases.suffix(days/2).reduce(0, +)) / Double(days/2)
            let olderAvg = Double(dailyPhrases.prefix(days/2).reduce(0, +)) / Double(days/2)
            
            if recentAvg > olderAvg * 1.1 {
                trends.trendDirection = .increasing
            } else if recentAvg < olderAvg * 0.9 {
                trends.trendDirection = .decreasing
            } else {
                trends.trendDirection = .stable
            }
        }
        
        return trends
    }
    
    /// Get category breakdown
    func getCategoryBreakdown() -> [(category: String, count: Int, percentage: Double)] {
        let totalUsage = SymbolUsageEntity.totalUsageCount(in: persistence.viewContext)
        guard totalUsage > 0 else { return [] }
        
        var breakdown: [(String, Int, Double)] = []
        
        for (category, count) in usageByCategory {
            let percentage = (Double(count) / Double(totalUsage)) * 100
            breakdown.append((category, count, percentage))
        }
        
        // Sort by count descending
        return breakdown.sorted { $0.1 > $1.1 }
    }
    
    /// Get time of day usage
    func getTimeOfDayUsage() -> [Int: Int] {
        let allConversations = ConversationEntity.fetchAll(in: persistence.viewContext)
        
        var hourMap: [Int: Int] = [:]
        
        for conversation in allConversations {
            if let timestamp = conversation.timestamp {
                let hour = Calendar.current.component(.hour, from: timestamp)
                hourMap[hour, default: 0] += 1
            }
        }
        
        return hourMap
    }
    
    // MARK: - Clear Analytics
    
    /// Clear all analytics data
    func clearAnalytics() {
        persistence.deleteAll(entityName: "SymbolUsageEntity")
        persistence.deleteAll(entityName: "SessionEntity")
        persistence.deleteAll(entityName: "ConversationEntity")
        
        DispatchQueue.main.async {
            self.mostUsedSymbols = []
            self.recentlyUsedSymbols = []
            self.usageByCategory = [:]
            self.dailyUsage = [:]
        }
    }
}

// MARK: - Supporting Types

/// Usage statistics
struct UsageStatistics {
    var totalSymbolUsages: Int64 = 0
    var uniqueSymbolsUsed: Int = 0
    var totalSessions: Int = 0
    var totalTimeSpent: TimeInterval = 0
    var totalPhrases: Int64 = 0
    var averagePhrasesPerSession: Double = 0
    var averageSymbolsPerSession: Double = 0
    var averageSessionDuration: TimeInterval = 0
    var averageSymbolsPerPhrase: Double = 0
    var mostUsedSymbol: String? = nil
    var mostUsedSymbolCount: Int = 0
    var customSymbolsCreated: Int = 0
    var customSymbolsStorage: Int64 = 0
    
    var formattedTotalTime: String {
        let hours = Int(totalTimeSpent) / 3600
        let minutes = (Int(totalTimeSpent) % 3600) / 60
        return "\(hours)h \(minutes)m"
    }
    
    var formattedAverageSessionTime: String {
        let minutes = Int(averageSessionDuration) / 60
        return "\(minutes) minutes"
    }
    
    var formattedStorage: String {
        let mb = Double(customSymbolsStorage) / (1024 * 1024)
        return String(format: "%.1f MB", mb)
    }
}

/// Usage trends
struct UsageTrends {
    var dailyPhrases: [Int] = []
    var dailySymbols: [Int] = []
    var trendDirection: TrendDirection = .stable
    
    enum TrendDirection {
        case increasing
        case decreasing
        case stable
    }
}
