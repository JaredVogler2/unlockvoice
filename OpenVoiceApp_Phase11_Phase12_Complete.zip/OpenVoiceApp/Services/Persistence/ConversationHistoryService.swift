//
//  ConversationHistoryService.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Service for managing conversation history with Core Data
//

import Foundation
import CoreData
import Combine

/// Service for managing conversation history
class ConversationHistoryService: ObservableObject {
    
    // MARK: - Singleton
    static let shared = ConversationHistoryService()
    
    // MARK: - Properties
    private let persistence = PersistenceService.shared
    
    @Published var recentConversations: [ConversationEntity] = []
    @Published var totalConversations: Int = 0
    
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Initialization
    
    private init() {
        loadRecentConversations()
        updateCount()
    }
    
    // MARK: - Create Operations
    
    /// Save a new conversation
    @discardableResult
    func saveConversation(
        text: String,
        symbols: [String],
        duration: Double = 0
    ) -> ConversationEntity? {
        let context = persistence.viewContext
        
        // Get or create today's session
        let session = SessionEntity.getTodaySession(in: context)
        
        // Create conversation
        let conversation = ConversationEntity.create(
            in: context,
            text: text,
            symbols: symbols,
            duration: duration,
            session: session
        )
        
        // Update session stats
        session.phraseCount += 1
        session.symbolCount += Int64(symbols.count)
        
        // Save context
        persistence.save()
        
        // Update published properties
        DispatchQueue.main.async {
            self.loadRecentConversations()
            self.updateCount()
        }
        
        print("✅ Conversation saved: \(text)")
        return conversation
    }
    
    /// Save conversation in background
    func saveConversationAsync(
        text: String,
        symbols: [String],
        duration: Double = 0
    ) {
        persistence.performBackgroundTask { context in
            // Get or create session
            let session = SessionEntity.getTodaySession(in: context)
            
            // Create conversation
            _ = ConversationEntity.create(
                in: context,
                text: text,
                symbols: symbols,
                duration: duration,
                session: session
            )
            
            // Update session
            session.phraseCount += 1
            session.symbolCount += Int64(symbols.count)
            
            // Context will auto-save via performBackgroundTask
        }
        
        // Update UI on main thread
        DispatchQueue.main.async {
            self.loadRecentConversations()
            self.updateCount()
        }
    }
    
    // MARK: - Read Operations
    
    /// Load recent conversations
    func loadRecentConversations(limit: Int = 100) {
        let conversations = ConversationEntity.fetchRecent(
            limit: limit,
            in: persistence.viewContext
        )
        
        DispatchQueue.main.async {
            self.recentConversations = conversations
        }
    }
    
    /// Get all conversations
    func getAllConversations() -> [ConversationEntity] {
        return ConversationEntity.fetchAll(in: persistence.viewContext)
    }
    
    /// Get conversations for date range
    func getConversations(
        from startDate: Date,
        to endDate: Date
    ) -> [ConversationEntity] {
        return ConversationEntity.fetchBetween(
            startDate: startDate,
            endDate: endDate,
            in: persistence.viewContext
        )
    }
    
    /// Search conversations
    func searchConversations(query: String) -> [ConversationEntity] {
        guard !query.isEmpty else {
            return recentConversations
        }
        
        return ConversationEntity.search(
            query: query,
            in: persistence.viewContext
        )
    }
    
    /// Get conversations from today
    func getTodayConversations() -> [ConversationEntity] {
        let calendar = Calendar.current
        let startOfDay = calendar.startOfDay(for: Date())
        let endOfDay = calendar.date(byAdding: .day, value: 1, to: startOfDay) ?? Date()
        
        return getConversations(from: startOfDay, to: endOfDay)
    }
    
    /// Get conversations from this week
    func getWeekConversations() -> [ConversationEntity] {
        let calendar = Calendar.current
        let startOfWeek = calendar.date(from: calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: Date())) ?? Date()
        let endOfWeek = calendar.date(byAdding: .weekOfYear, value: 1, to: startOfWeek) ?? Date()
        
        return getConversations(from: startOfWeek, to: endOfWeek)
    }
    
    /// Get conversations from this month
    func getMonthConversations() -> [ConversationEntity] {
        let calendar = Calendar.current
        let startOfMonth = calendar.date(from: calendar.dateComponents([.year, .month], from: Date())) ?? Date()
        let endOfMonth = calendar.date(byAdding: .month, value: 1, to: startOfMonth) ?? Date()
        
        return getConversations(from: startOfMonth, to: endOfMonth)
    }
    
    // MARK: - Update Operations
    
    private func updateCount() {
        let count = ConversationEntity.count(in: persistence.viewContext)
        
        DispatchQueue.main.async {
            self.totalConversations = count
        }
    }
    
    // MARK: - Delete Operations
    
    /// Delete a specific conversation
    func deleteConversation(_ conversation: ConversationEntity) {
        persistence.delete(conversation)
        
        DispatchQueue.main.async {
            self.loadRecentConversations()
            self.updateCount()
        }
    }
    
    /// Delete multiple conversations
    func deleteConversations(_ conversations: [ConversationEntity]) {
        persistence.delete(conversations)
        
        DispatchQueue.main.async {
            self.loadRecentConversations()
            self.updateCount()
        }
    }
    
    /// Delete all conversations
    func deleteAllConversations() {
        persistence.deleteAll(entityName: "ConversationEntity")
        
        DispatchQueue.main.async {
            self.recentConversations = []
            self.totalConversations = 0
        }
    }
    
    /// Delete conversations older than specified date
    func deleteConversationsOlderThan(date: Date) {
        let predicate = NSPredicate(format: "timestamp < %@", date as NSDate)
        persistence.batchDelete(entityName: "ConversationEntity", predicate: predicate)
        
        DispatchQueue.main.async {
            self.loadRecentConversations()
            self.updateCount()
        }
    }
    
    // MARK: - Export Operations
    
    /// Export conversations to JSON
    func exportToJSON() -> Data? {
        let conversations = getAllConversations()
        
        let exportData: [[String: Any]] = conversations.compactMap { conversation in
            guard let text = conversation.text,
                  let timestamp = conversation.timestamp,
                  let symbolIds = conversation.symbolIds else {
                return nil
            }
            
            return [
                "id": conversation.id?.uuidString ?? "",
                "text": text,
                "symbols": symbolIds,
                "timestamp": ISO8601DateFormatter().string(from: timestamp),
                "duration": conversation.duration
            ]
        }
        
        do {
            let jsonData = try JSONSerialization.data(
                withJSONObject: exportData,
                options: .prettyPrinted
            )
            return jsonData
        } catch {
            print("❌ Export error: \(error)")
            return nil
        }
    }
    
    /// Export conversations to CSV
    func exportToCSV() -> String {
        let conversations = getAllConversations()
        
        var csv = "ID,Text,Symbol Count,Timestamp,Duration\n"
        
        for conversation in conversations {
            let id = conversation.id?.uuidString ?? ""
            let text = conversation.text?.replacingOccurrences(of: ",", with: ";") ?? ""
            let symbolCount = conversation.symbolCount
            let timestamp = conversation.formattedTimestamp
            let duration = conversation.duration
            
            csv += "\(id),\"\(text)\",\(symbolCount),\(timestamp),\(duration)\n"
        }
        
        return csv
    }
    
    // MARK: - Statistics
    
    /// Get conversation statistics
    func getStatistics() -> ConversationStatistics {
        var stats = ConversationStatistics()
        
        stats.totalConversations = totalConversations
        stats.todayConversations = getTodayConversations().count
        stats.weekConversations = getWeekConversations().count
        stats.monthConversations = getMonthConversations().count
        
        let allConversations = getAllConversations()
        
        if !allConversations.isEmpty {
            stats.averageSymbolsPerPhrase = Double(allConversations.reduce(0) { $0 + $1.symbolCount }) / Double(allConversations.count)
            
            if let oldest = allConversations.last?.timestamp {
                stats.oldestConversation = oldest
            }
            
            if let newest = allConversations.first?.timestamp {
                stats.newestConversation = newest
            }
        }
        
        return stats
    }
}

// MARK: - Supporting Types

/// Conversation statistics
struct ConversationStatistics {
    var totalConversations: Int = 0
    var todayConversations: Int = 0
    var weekConversations: Int = 0
    var monthConversations: Int = 0
    var averageSymbolsPerPhrase: Double = 0
    var oldestConversation: Date?
    var newestConversation: Date?
}
