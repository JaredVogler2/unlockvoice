//
//  SpeechService.swift
//  OpenVoice
//
//  Enhanced text-to-speech service with pronunciation dictionary and SSML support
//  Phase 3: Professional speech features
//

import Foundation
import AVFoundation
import Combine

class SpeechService: ObservableObject {
    static let shared = SpeechService()
    
    private let synthesizer = AVSpeechSynthesizer()
    private var pronunciationDictionary = PronunciationDictionary()
    
    @Published var isSpeaking = false
    @Published var currentUtterance: String = ""
    @Published var speechQueue: [SpeechQueueItem] = []
    @Published var speechHistory: [SpeechHistoryItem] = []
    
    private let maxHistoryItems = 100
    
    private init() {
        synthesizer.delegate = SpeechDelegate.shared
        loadPronunciationDictionary()
        loadSpeechHistory()
    }
    
    // MARK: - Public Methods
    
    /// Main speak method with all enhancements
    func speak(_ text: String, rate: Float? = nil, pitch: Float? = nil, voice: AVSpeechSynthesisVoice? = nil, volume: Float? = nil) {
        guard !text.isEmpty else { return }
        
        // Apply pronunciation dictionary
        let processedText = pronunciationDictionary.apply(to: text)
        
        // Create utterance
        let utterance = AVSpeechUtterance(string: processedText)
        
        // Apply settings
        let settings = AppSettings.load()
        utterance.rate = rate ?? settings.speechRate
        utterance.pitchMultiplier = pitch ?? settings.speechPitch
        utterance.voice = voice ?? getSelectedVoice()
        utterance.volume = volume ?? 1.0
        
        // Configure audio session
        configureAudioSession()
        
        // Add to history
        addToHistory(text: text, processedText: processedText)
        
        // Speak
        currentUtterance = text
        synthesizer.speak(utterance)
        isSpeaking = true
        
        // Haptic feedback
        HapticManager.shared.impact(.medium)
    }
    
    /// Speak with SSML markup support
    func speakWithSSML(_ ssml: String, rate: Float? = nil, pitch: Float? = nil, voice: AVSpeechSynthesisVoice? = nil) {
        // Parse SSML and extract text with prosody hints
        let parsed = SSMLParser.parse(ssml)
        
        // For now, speak the plain text (full SSML requires more complex implementation)
        // AVSpeechSynthesizer has limited SSML support, but we can extract emphasis
        speak(parsed.text, rate: rate, pitch: pitch, voice: voice)
    }
    
    /// Add phrase to speech queue
    func queuePhrase(_ text: String) {
        let item = SpeechQueueItem(text: text, timestamp: Date())
        speechQueue.append(item)
        
        // If not currently speaking, start
        if !isSpeaking {
            speakNextInQueue()
        }
    }
    
    /// Speak next phrase in queue
    func speakNextInQueue() {
        guard !speechQueue.isEmpty else { return }
        
        let item = speechQueue.removeFirst()
        speak(item.text)
    }
    
    /// Clear speech queue
    func clearQueue() {
        speechQueue.removeAll()
    }
    
    /// Stop speaking immediately
    func stop() {
        synthesizer.stopSpeaking(at: .immediate)
        isSpeaking = false
        currentUtterance = ""
    }
    
    /// Pause speaking
    func pause() {
        synthesizer.pauseSpeaking(at: .word)
    }
    
    /// Resume speaking
    func resume() {
        synthesizer.continueSpeaking()
    }
    
    // MARK: - Speech History
    
    private func addToHistory(text: String, processedText: String) {
        let item = SpeechHistoryItem(
            id: UUID(),
            originalText: text,
            processedText: processedText,
            timestamp: Date(),
            voice: getSelectedVoice()?.name ?? "Default",
            rate: AppSettings.load().speechRate,
            pitch: AppSettings.load().speechPitch
        )
        
        speechHistory.insert(item, at: 0)
        
        // Keep only recent history
        if speechHistory.count > maxHistoryItems {
            speechHistory = Array(speechHistory.prefix(maxHistoryItems))
        }
        
        saveSpeechHistory()
    }
    
    func replayHistoryItem(_ item: SpeechHistoryItem) {
        speak(item.originalText, rate: item.rate, pitch: item.pitch)
    }
    
    func clearHistory() {
        speechHistory.removeAll()
        saveSpeechHistory()
    }
    
    private func loadSpeechHistory() {
        guard let data = UserDefaults.standard.data(forKey: "SpeechHistory"),
              let history = try? JSONDecoder().decode([SpeechHistoryItem].self, from: data) else {
            return
        }
        speechHistory = history
    }
    
    private func saveSpeechHistory() {
        if let data = try? JSONEncoder().encode(speechHistory) {
            UserDefaults.standard.set(data, forKey: "SpeechHistory")
        }
    }
    
    // MARK: - Pronunciation Dictionary
    
    func addPronunciation(word: String, pronunciation: String) {
        pronunciationDictionary.add(word: word, pronunciation: pronunciation)
        savePronunciationDictionary()
    }
    
    func removePronunciation(word: String) {
        pronunciationDictionary.remove(word: word)
        savePronunciationDictionary()
    }
    
    func getPronunciation(for word: String) -> String? {
        pronunciationDictionary.get(word: word)
    }
    
    func getAllPronunciations() -> [String: String] {
        pronunciationDictionary.getAll()
    }
    
    private func loadPronunciationDictionary() {
        guard let data = UserDefaults.standard.data(forKey: "PronunciationDictionary"),
              let dict = try? JSONDecoder().decode(PronunciationDictionary.self, from: data) else {
            return
        }
        pronunciationDictionary = dict
    }
    
    private func savePronunciationDictionary() {
        if let data = try? JSONEncoder().encode(pronunciationDictionary) {
            UserDefaults.standard.set(data, forKey: "PronunciationDictionary")
        }
    }
    
    // MARK: - Voice Selection
    
    func getAvailableVoices() -> [AVSpeechSynthesisVoice] {
        AVSpeechSynthesisVoice.speechVoices()
            .filter { $0.language.starts(with: "en") } // English voices
            .sorted { $0.name < $1.name }
    }
    
    func getVoicesByLanguage() -> [String: [AVSpeechSynthesisVoice]] {
        let allVoices = AVSpeechSynthesisVoice.speechVoices()
        return Dictionary(grouping: allVoices, by: { $0.language })
    }
    
    private func getSelectedVoice() -> AVSpeechSynthesisVoice? {
        let identifier = AppSettings.load().selectedVoice
        return AVSpeechSynthesisVoice(identifier: identifier)
    }
    
    // MARK: - Audio Session
    
    private func configureAudioSession() {
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playback, mode: .spokenAudio, options: .duckOthers)
            try audioSession.setActive(true)
        } catch {
            print("Failed to configure audio session: \(error)")
        }
    }
}

// MARK: - Speech Delegate

class SpeechDelegate: NSObject, AVSpeechSynthesizerDelegate {
    static let shared = SpeechDelegate()
    
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        DispatchQueue.main.async {
            SpeechService.shared.isSpeaking = false
            SpeechService.shared.currentUtterance = ""
            
            // Speak next in queue if available
            if !SpeechService.shared.speechQueue.isEmpty {
                SpeechService.shared.speakNextInQueue()
            }
        }
    }
    
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        DispatchQueue.main.async {
            SpeechService.shared.isSpeaking = false
            SpeechService.shared.currentUtterance = ""
        }
    }
    
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        // Could be used for word highlighting in the future
    }
}

// MARK: - Voice Preview

extension AVSpeechSynthesisVoice {
    func preview(text: String = "Hello, this is how I sound. I can help you communicate.") {
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = self
        utterance.rate = 0.5
        
        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
    }
}

// MARK: - Supporting Types

struct SpeechQueueItem: Identifiable, Codable {
    let id = UUID()
    var text: String
    var timestamp: Date
}

struct SpeechHistoryItem: Identifiable, Codable {
    let id: UUID
    var originalText: String
    var processedText: String
    var timestamp: Date
    var voice: String
    var rate: Float
    var pitch: Float
}

// MARK: - Pronunciation Dictionary

struct PronunciationDictionary: Codable {
    private var dictionary: [String: String] = [:]
    
    // Common AAC pronunciations
    init() {
        // Add some common AAC-specific pronunciations
        dictionary["AAC"] = "A A C"
        dictionary["iOS"] = "eye oh ess"
        dictionary["iPad"] = "eye pad"
        dictionary["iPhone"] = "eye phone"
    }
    
    mutating func add(word: String, pronunciation: String) {
        dictionary[word.lowercased()] = pronunciation
    }
    
    mutating func remove(word: String) {
        dictionary.removeValue(forKey: word.lowercased())
    }
    
    func get(word: String) -> String? {
        dictionary[word.lowercased()]
    }
    
    func getAll() -> [String: String] {
        dictionary
    }
    
    func apply(to text: String) -> String {
        var result = text
        
        // Replace words with custom pronunciations
        for (word, pronunciation) in dictionary {
            // Use word boundaries to avoid partial matches
            let pattern = "\\b\(NSRegularExpression.escapedPattern(for: word))\\b"
            if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) {
                result = regex.stringByReplacingMatches(
                    in: result,
                    range: NSRange(result.startIndex..., in: result),
                    withTemplate: pronunciation
                )
            }
        }
        
        return result
    }
}

// MARK: - SSML Parser (Simplified)

struct SSMLParser {
    struct ParsedSSML {
        var text: String
        var emphasis: [String: String] = [:]
        var breaks: [Int] = []
    }
    
    static func parse(_ ssml: String) -> ParsedSSML {
        // Simplified SSML parsing - extract plain text
        // Full SSML support would require XML parsing
        
        var text = ssml
        
        // Remove SSML tags but keep content
        text = text.replacingOccurrences(of: "<speak>", with: "")
        text = text.replacingOccurrences(of: "</speak>", with: "")
        text = text.replacingOccurrences(of: #"<emphasis[^>]*>"#, with: "", options: .regularExpression)
        text = text.replacingOccurrences(of: "</emphasis>", with: "")
        text = text.replacingOccurrences(of: #"<break[^>]*\/>"#, with: " ", options: .regularExpression)
        
        return ParsedSSML(text: text.trimmingCharacters(in: .whitespacesAndNewlines))
    }
}
