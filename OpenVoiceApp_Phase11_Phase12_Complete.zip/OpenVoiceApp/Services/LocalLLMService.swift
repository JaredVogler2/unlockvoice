//
//  LocalLLMService.swift
//  OpenVoice
//
//  Phase 10: Local LLM Integration
//  Manages interaction with MLX-powered backend
//

import Foundation
import Combine

/// Configuration for LLM service
struct LLMConfig {
    var baseURL: URL = URL(string: "http://localhost:8000")!
    var timeout: TimeInterval = 30.0
    var maxRetries: Int = 2
    var fallbackEnabled: Bool = true
}

/// Intent detected from user communication
enum CommunicationIntent: String, Codable {
    case statement = "STATEMENT"
    case request = "REQUEST"
    case question = "QUESTION"
    case emergency = "EMERGENCY"
    case unknown = "UNKNOWN"
}

/// Urgency level
enum UrgencyLevel: String, Codable {
    case low = "LOW"
    case medium = "MEDIUM"
    case high = "HIGH"
    case urgent = "URGENT"
}

/// Enhanced communication response
struct EnhancedCommunication: Codable {
    let sentence: String
    let confidence: Double
    let suggestions: [String]
    let intent: String
    let urgency: String
    let latencyMs: Double
    let model: String
    
    enum CodingKeys: String, CodingKey {
        case sentence, confidence, suggestions, intent, urgency
        case latencyMs = "latency_ms"
        case model
    }
    
    var intentEnum: CommunicationIntent {
        CommunicationIntent(rawValue: intent) ?? .unknown
    }
    
    var urgencyEnum: UrgencyLevel {
        UrgencyLevel(rawValue: urgency) ?? .low
    }
}

/// Generation response
struct GenerationResponse: Codable {
    let text: String
    let confidence: Double
    let tokens: Int
    let latencyMs: Double
    let model: String
    let finishReason: String
    
    enum CodingKeys: String, CodingKey {
        case text, confidence, tokens, model
        case latencyMs = "latency_ms"
        case finishReason = "finish_reason"
    }
}

/// LLM health status
struct LLMHealth: Codable {
    let status: String
    let phase: Int
    let isLoaded: Bool
    let model: String?
    let mlxAvailable: Bool
    
    enum CodingKeys: String, CodingKey {
        case status, phase, model
        case isLoaded = "is_loaded"
        case mlxAvailable = "mlx_available"
    }
}

/// LLM statistics
struct LLMStats: Codable {
    let isLoaded: Bool
    let model: String
    let totalGenerations: Int
    let totalTokens: Int
    let errors: Int
    let avgLatencyMs: Double
    let avgTokens: Double
    let mlxAvailable: Bool
    
    enum CodingKeys: String, CodingKey {
        case model, errors
        case isLoaded = "is_loaded"
        case totalGenerations = "total_generations"
        case totalTokens = "total_tokens"
        case avgLatencyMs = "avg_latency_ms"
        case avgTokens = "avg_tokens"
        case mlxAvailable = "mlx_available"
    }
}

/// Service for managing local LLM interactions
@MainActor
class LocalLLMService: ObservableObject {
    static let shared = LocalLLMService()
    
    @Published var isAvailable = false
    @Published var isLoading = false
    @Published var error: String?
    @Published var stats: LLMStats?
    
    private var config: LLMConfig
    private var cancellables = Set<AnyCancellable>()
    
    // Health check timer
    private var healthCheckTimer: Timer?
    
    private init(config: LLMConfig = LLMConfig()) {
        self.config = config
        startHealthChecks()
    }
    
    // MARK: - Health Monitoring
    
    private func startHealthChecks() {
        // Check health every 30 seconds
        healthCheckTimer = Timer.scheduledTimer(withTimeInterval: 30.0, repeats: true) { [weak self] _ in
            Task { @MainActor in
                await self?.checkHealth()
            }
        }
        
        // Initial check
        Task {
            await checkHealth()
        }
    }
    
    func checkHealth() async {
        do {
            let url = config.baseURL.appendingPathComponent("/api/v1/llm/health")
            let (data, response) = try await URLSession.shared.data(from: url)
            
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else {
                isAvailable = false
                return
            }
            
            let health = try JSONDecoder().decode(LLMHealth.self, from: data)
            isAvailable = health.mlxAvailable && health.status == "healthy"
            
        } catch {
            isAvailable = false
        }
    }
    
    // MARK: - Main Enhancement Method
    
    /// Enhance AAC symbols with LLM intelligence
    func enhance(
        symbols: [String],
        context: [String: Any]? = nil,
        useMemory: Bool = true
    ) async throws -> EnhancedCommunication {
        
        // Check if service is available
        guard isAvailable else {
            throw LLMError.serviceUnavailable
        }
        
        let url = config.baseURL.appendingPathComponent("/api/v1/llm/enhance")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = config.timeout
        
        // Prepare request body
        let requestBody: [String: Any] = [
            "symbols": symbols,
            "context": context ?? [:],
            "use_memory": useMemory
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)
        
        // Make request with retry
        var lastError: Error?
        for attempt in 0..<config.maxRetries {
            do {
                let (data, response) = try await URLSession.shared.data(for: request)
                
                guard let httpResponse = response as? HTTPURLResponse else {
                    throw LLMError.invalidResponse
                }
                
                if httpResponse.statusCode == 200 {
                    let enhanced = try JSONDecoder().decode(EnhancedCommunication.self, from: data)
                    return enhanced
                } else if httpResponse.statusCode == 503 {
                    // Service temporarily unavailable, maybe model loading
                    if attempt < config.maxRetries - 1 {
                        try await Task.sleep(nanoseconds: 2_000_000_000) // 2 seconds
                        continue
                    }
                    throw LLMError.serviceUnavailable
                } else {
                    throw LLMError.httpError(statusCode: httpResponse.statusCode)
                }
                
            } catch {
                lastError = error
                if attempt < config.maxRetries - 1 {
                    try await Task.sleep(nanoseconds: 1_000_000_000) // 1 second
                }
            }
        }
        
        throw lastError ?? LLMError.unknownError
    }
    
    // MARK: - Generation Methods
    
    /// Generic text generation
    func generate(
        symbols: [String],
        task: String = "enhance",
        additionalContext: String? = nil,
        useMemory: Bool = true,
        maxTokens: Int? = nil,
        temperature: Double? = nil
    ) async throws -> GenerationResponse {
        
        guard isAvailable else {
            throw LLMError.serviceUnavailable
        }
        
        let url = config.baseURL.appendingPathComponent("/api/v1/llm/generate")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        var requestBody: [String: Any] = [
            "symbols": symbols,
            "task": task,
            "use_memory": useMemory
        ]
        
        if let context = additionalContext {
            requestBody["additional_context"] = context
        }
        if let tokens = maxTokens {
            requestBody["max_tokens"] = tokens
        }
        if let temp = temperature {
            requestBody["temperature"] = temp
        }
        
        request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw LLMError.invalidResponse
        }
        
        return try JSONDecoder().decode(GenerationResponse.self, from: data)
    }
    
    /// Answer a question about the conversation
    func answerQuestion(_ question: String) async throws -> String {
        guard isAvailable else {
            throw LLMError.serviceUnavailable
        }
        
        let url = config.baseURL.appendingPathComponent("/api/v1/llm/question")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let requestBody: [String: Any] = ["question": question]
        request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw LLMError.invalidResponse
        }
        
        let result = try JSONDecoder().decode([String: String].self, from: data)
        return result["answer"] ?? "No answer available"
    }
    
    // MARK: - Memory Management
    
    /// Clear conversation memory
    func clearMemory() async throws {
        let url = config.baseURL.appendingPathComponent("/api/v1/llm/memory/clear")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let (_, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw LLMError.invalidResponse
        }
    }
    
    // MARK: - Statistics
    
    /// Get LLM statistics
    func fetchStats() async throws -> LLMStats {
        let url = config.baseURL.appendingPathComponent("/api/v1/llm/stats")
        let (data, response) = try await URLSession.shared.data(from: url)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw LLMError.invalidResponse
        }
        
        let stats = try JSONDecoder().decode(LLMStats.self, from: data)
        await MainActor.run {
            self.stats = stats
        }
        return stats
    }
    
    // MARK: - Model Management
    
    /// Load the LLM model
    func loadModel() async throws {
        isLoading = true
        defer { isLoading = false }
        
        let url = config.baseURL.appendingPathComponent("/api/v1/llm/model/load")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let (_, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw LLMError.invalidResponse
        }
        
        // Wait a bit for model to load
        try await Task.sleep(nanoseconds: 2_000_000_000)
        await checkHealth()
    }
    
    /// Unload the model to save memory
    func unloadModel() async throws {
        let url = config.baseURL.appendingPathComponent("/api/v1/llm/model/unload")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let (_, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw LLMError.invalidResponse
        }
        
        isAvailable = false
    }
    
    // MARK: - Testing
    
    /// Test LLM generation
    func test() async throws -> [String: Any] {
        let url = config.baseURL.appendingPathComponent("/api/v1/llm/test")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw LLMError.invalidResponse
        }
        
        return try JSONSerialization.jsonObject(with: data) as? [String: Any] ?? [:]
    }
}

// MARK: - Error Handling

enum LLMError: LocalizedError {
    case serviceUnavailable
    case invalidResponse
    case httpError(statusCode: Int)
    case unknownError
    
    var errorDescription: String? {
        switch self {
        case .serviceUnavailable:
            return "LLM service is not available. Please ensure the MLX backend is running."
        case .invalidResponse:
            return "Received invalid response from LLM service."
        case .httpError(let statusCode):
            return "LLM service returned error: \(statusCode)"
        case .unknownError:
            return "An unknown error occurred with the LLM service."
        }
    }
}

// MARK: - Convenience Extensions

extension LocalLLMService {
    /// Quick enhancement with automatic fallback
    func enhanceWithFallback(
        symbols: [String],
        context: [String: Any]? = nil
    ) async -> String {
        
        do {
            let enhanced = try await enhance(symbols: symbols, context: context)
            return enhanced.sentence
        } catch {
            // Fallback to simple joining
            let sentence = symbols.joined(separator: " ")
            return sentence.prefix(1).uppercased() + sentence.dropFirst() + "."
        }
    }
    
    /// Get suggested next symbols
    func getSuggestions(for symbols: [String]) async -> [String] {
        do {
            let response = try await generate(symbols: symbols, task: "predict", useMemory: false)
            return response.text.split(separator: ",").map { String($0.trimmingCharacters(in: .whitespaces)) }
        } catch {
            return []
        }
    }
}
