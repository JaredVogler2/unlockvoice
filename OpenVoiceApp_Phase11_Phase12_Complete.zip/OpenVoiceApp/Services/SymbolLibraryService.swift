//
//  SymbolLibraryService.swift
//  OpenVoice
//
//  Service for managing the complete symbol library
//  Handles Mulberry symbols, custom symbols, and symbol operations
//

import Foundation
import UIKit
import Combine

class SymbolLibraryService: ObservableObject {
    static let shared = SymbolLibraryService()
    
    @Published var allSymbols: [Symbol] = []
    @Published var categories: [SymbolCategory: [Symbol]] = [:]
    @Published var favoriteSymbols: [Symbol] = []
    @Published var recentSymbols: [Symbol] = []
    @Published var customSymbols: [Symbol] = []
    @Published var isLoading: Bool = false
    
    private var symbolsByID: [UUID: Symbol] = [:]
    private let maxRecentSymbols = 20
    
    private init() {
        loadAllSymbols()
    }
    
    // MARK: - Loading Symbols
    
    func loadAllSymbols() {
        isLoading = true
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            var symbols: [Symbol] = []
            
            // Load built-in symbols (using SF Symbols for now)
            symbols.append(contentsOf: self.loadBuiltInSymbols())
            
            // Phase 2.1: Load Mulberry symbols from assets
            // symbols.append(contentsOf: self.loadMulberrySymbols())
            
            // Load custom symbols from storage
            symbols.append(contentsOf: self.loadCustomSymbols())
            
            // Organize by category
            let categorized = Dictionary(grouping: symbols, by: { $0.category })
            
            DispatchQueue.main.async {
                self.allSymbols = symbols
                self.categories = categorized
                self.symbolsByID = Dictionary(uniqueKeysWithValues: symbols.map { ($0.id, $0) })
                self.loadFavorites()
                self.loadRecents()
                self.isLoading = false
            }
        }
    }
    
    private func loadBuiltInSymbols() -> [Symbol] {
        // Expanded built-in symbol set using SF Symbols
        return [
            // People & Pronouns
            Symbol(label: "I", imageName: "person.fill", category: .people, tags: ["pronoun", "self", "me"]),
            Symbol(label: "you", imageName: "person.crop.circle", category: .people, tags: ["pronoun"]),
            Symbol(label: "we", imageName: "person.2.fill", category: .people, tags: ["pronoun", "us"]),
            Symbol(label: "mom", imageName: "figure.dress.line.vertical.figure", category: .people, tags: ["mother", "parent", "family"]),
            Symbol(label: "dad", imageName: "figure.stand", category: .people, tags: ["father", "parent", "family"]),
            Symbol(label: "friend", imageName: "person.2", category: .people, tags: ["companion"]),
            Symbol(label: "teacher", imageName: "person.crop.circle.badge.checkmark", category: .people, tags: ["school"]),
            
            // Actions
            Symbol(label: "want", imageName: "hand.raised.fill", category: .actions, tags: ["desire", "need"]),
            Symbol(label: "need", imageName: "exclamationmark.triangle.fill", category: .actions, tags: ["require"]),
            Symbol(label: "eat", imageName: "fork.knife", category: .actions, tags: ["food", "hungry"]),
            Symbol(label: "drink", imageName: "cup.and.saucer.fill", category: .actions, tags: ["beverage", "thirsty"]),
            Symbol(label: "go", imageName: "arrow.right.circle.fill", category: .actions, tags: ["move", "leave"]),
            Symbol(label: "come", imageName: "arrow.left.circle.fill", category: .actions, tags: ["arrive"]),
            Symbol(label: "play", imageName: "gamecontroller.fill", category: .actions, tags: ["fun", "game"]),
            Symbol(label: "sleep", imageName: "bed.double.fill", category: .actions, tags: ["rest", "tired"]),
            Symbol(label: "help", imageName: "hand.raised.fingers.spread.fill", category: .actions, tags: ["assist", "emergency"]),
            Symbol(label: "stop", imageName: "hand.raised.slash.fill", category: .actions, tags: ["halt", "no"]),
            Symbol(label: "wait", imageName: "clock.fill", category: .actions, tags: ["pause"]),
            Symbol(label: "look", imageName: "eye.fill", category: .actions, tags: ["see", "watch"]),
            Symbol(label: "listen", imageName: "ear.fill", category: .actions, tags: ["hear"]),
            Symbol(label: "talk", imageName: "text.bubble.fill", category: .actions, tags: ["speak", "communicate"]),
            
            // Food
            Symbol(label: "food", imageName: "fork.knife", category: .food, tags: ["eat", "meal"]),
            Symbol(label: "water", imageName: "drop.fill", category: .food, tags: ["drink", "beverage"]),
            Symbol(label: "juice", imageName: "cup.and.saucer.fill", category: .food, tags: ["drink"]),
            Symbol(label: "milk", imageName: "drop.triangle.fill", category: .food, tags: ["drink", "dairy"]),
            Symbol(label: "pizza", imageName: "circle.hexagongrid.fill", category: .food, tags: ["food", "dinner"]),
            Symbol(label: "snack", imageName: "carrot.fill", category: .food, tags: ["food"]),
            Symbol(label: "breakfast", imageName: "sun.horizon.fill", category: .food, tags: ["meal", "morning"]),
            Symbol(label: "lunch", imageName: "sun.max.fill", category: .food, tags: ["meal", "noon"]),
            Symbol(label: "dinner", imageName: "moon.fill", category: .food, tags: ["meal", "evening"]),
            
            // Feelings
            Symbol(label: "happy", imageName: "face.smiling.fill", category: .feelings, tags: ["emotion", "joy", "good"]),
            Symbol(label: "sad", imageName: "cloud.rain.fill", category: .feelings, tags: ["emotion", "upset"]),
            Symbol(label: "angry", imageName: "cloud.bolt.fill", category: .feelings, tags: ["emotion", "mad"]),
            Symbol(label: "scared", imageName: "exclamationmark.triangle.fill", category: .feelings, tags: ["emotion", "afraid", "fear"]),
            Symbol(label: "tired", imageName: "zzz", category: .feelings, tags: ["sleepy", "exhausted"]),
            Symbol(label: "sick", imageName: "cross.case.fill", category: .feelings, tags: ["ill", "unwell"]),
            Symbol(label: "hurt", imageName: "bandage.fill", category: .feelings, tags: ["pain", "ow"]),
            Symbol(label: "good", imageName: "hand.thumbsup.fill", category: .feelings, tags: ["positive", "ok"]),
            Symbol(label: "bad", imageName: "hand.thumbsdown.fill", category: .feelings, tags: ["negative"]),
            
            // Places
            Symbol(label: "home", imageName: "house.fill", category: .places, tags: ["location"]),
            Symbol(label: "school", imageName: "building.2.fill", category: .places, tags: ["location", "education"]),
            Symbol(label: "bathroom", imageName: "toilet.fill", category: .places, tags: ["location", "restroom", "essential"]),
            Symbol(label: "bedroom", imageName: "bed.double.fill", category: .places, tags: ["location", "room"]),
            Symbol(label: "kitchen", imageName: "refrigerator.fill", category: .places, tags: ["location", "room"]),
            Symbol(label: "outside", imageName: "tree.fill", category: .places, tags: ["location", "outdoor"]),
            Symbol(label: "park", imageName: "figure.walk", category: .places, tags: ["location", "outdoor"]),
            Symbol(label: "store", imageName: "cart.fill", category: .places, tags: ["location", "shop"]),
            
            // Things
            Symbol(label: "toy", imageName: "teddybear.fill", category: .things, tags: ["object", "play"]),
            Symbol(label: "book", imageName: "book.fill", category: .things, tags: ["object", "read"]),
            Symbol(label: "phone", imageName: "iphone", category: .things, tags: ["object", "device"]),
            Symbol(label: "iPad", imageName: "ipad", category: .things, tags: ["object", "device"]),
            Symbol(label: "TV", imageName: "tv.fill", category: .things, tags: ["object", "watch"]),
            Symbol(label: "music", imageName: "music.note", category: .things, tags: ["object", "sound"]),
            Symbol(label: "ball", imageName: "basketball.fill", category: .things, tags: ["object", "toy", "play"]),
            Symbol(label: "car", imageName: "car.fill", category: .things, tags: ["object", "vehicle"]),
            
            // Descriptors
            Symbol(label: "big", imageName: "arrow.up.left.and.arrow.down.right", category: .descriptors, tags: ["size", "large"]),
            Symbol(label: "small", imageName: "arrow.down.right.and.arrow.up.left", category: .descriptors, tags: ["size", "little"]),
            Symbol(label: "hot", imageName: "flame.fill", category: .descriptors, tags: ["temperature"]),
            Symbol(label: "cold", imageName: "snowflake", category: .descriptors, tags: ["temperature"]),
            Symbol(label: "more", imageName: "plus.circle.fill", category: .descriptors, tags: ["quantity", "additional"]),
            Symbol(label: "less", imageName: "minus.circle.fill", category: .descriptors, tags: ["quantity"]),
            Symbol(label: "all done", imageName: "checkmark.circle.fill", category: .descriptors, tags: ["finished", "complete"]),
            Symbol(label: "fast", imageName: "hare.fill", category: .descriptors, tags: ["speed", "quick"]),
            Symbol(label: "slow", imageName: "tortoise.fill", category: .descriptors, tags: ["speed"]),
            
            // Questions
            Symbol(label: "what", imageName: "questionmark.circle.fill", category: .questions, tags: ["question", "query"]),
            Symbol(label: "where", imageName: "location.fill", category: .questions, tags: ["question", "place"]),
            Symbol(label: "when", imageName: "clock.fill", category: .questions, tags: ["question", "time"]),
            Symbol(label: "who", imageName: "person.crop.circle.badge.questionmark", category: .questions, tags: ["question", "person"]),
            Symbol(label: "why", imageName: "lightbulb.fill", category: .questions, tags: ["question", "reason"]),
            Symbol(label: "how", imageName: "gearshape.fill", category: .questions, tags: ["question", "method"]),
            
            // General
            Symbol(label: "yes", imageName: "checkmark.circle.fill", category: .general, tags: ["affirmative", "agree"]),
            Symbol(label: "no", imageName: "xmark.circle.fill", category: .general, tags: ["negative", "disagree"]),
            Symbol(label: "please", imageName: "hand.wave.fill", category: .general, tags: ["polite", "request"]),
            Symbol(label: "thank you", imageName: "heart.fill", category: .general, tags: ["polite", "gratitude"]),
            Symbol(label: "sorry", imageName: "exclamationmark.bubble.fill", category: .general, tags: ["apology"]),
            Symbol(label: "hello", imageName: "hand.wave.fill", category: .general, tags: ["greeting"]),
            Symbol(label: "goodbye", imageName: "hand.wave", category: .general, tags: ["farewell"]),
        ]
    }
    
    // MARK: - Mulberry Symbols (Phase 2.1)
    
    private func loadMulberrySymbols() -> [Symbol] {
        // Phase 2.1: Load from Assets.xcassets
        // This will be implemented when Mulberry symbols are added to the project
        // For now, return empty array
        return []
    }
    
    // MARK: - Custom Symbols
    
    private func loadCustomSymbols() -> [Symbol] {
        guard let data = UserDefaults.standard.data(forKey: "CustomSymbols"),
              let symbols = try? JSONDecoder().decode([Symbol].self, from: data) else {
            return []
        }
        customSymbols = symbols
        return symbols
    }
    
    func saveCustomSymbol(_ symbol: Symbol) {
        customSymbols.append(symbol)
        allSymbols.append(symbol)
        symbolsByID[symbol.id] = symbol
        
        // Add to appropriate category
        if categories[symbol.category] != nil {
            categories[symbol.category]?.append(symbol)
        } else {
            categories[symbol.category] = [symbol]
        }
        
        // Persist to storage
        saveCustomSymbolsToStorage()
    }
    
    func updateCustomSymbol(_ symbol: Symbol) {
        if let index = customSymbols.firstIndex(where: { $0.id == symbol.id }) {
            customSymbols[index] = symbol
        }
        if let index = allSymbols.firstIndex(where: { $0.id == symbol.id }) {
            allSymbols[index] = symbol
        }
        symbolsByID[symbol.id] = symbol
        
        // Update in category
        if let categoryIndex = categories[symbol.category]?.firstIndex(where: { $0.id == symbol.id }) {
            categories[symbol.category]?[categoryIndex] = symbol
        }
        
        saveCustomSymbolsToStorage()
    }
    
    func deleteCustomSymbol(_ symbol: Symbol) {
        customSymbols.removeAll { $0.id == symbol.id }
        allSymbols.removeAll { $0.id == symbol.id }
        symbolsByID.removeValue(forKey: symbol.id)
        categories[symbol.category]?.removeAll { $0.id == symbol.id }
        
        saveCustomSymbolsToStorage()
    }
    
    private func saveCustomSymbolsToStorage() {
        if let data = try? JSONEncoder().encode(customSymbols) {
            UserDefaults.standard.set(data, forKey: "CustomSymbols")
        }
    }
    
    // MARK: - Favorites
    
    private func loadFavorites() {
        guard let ids = UserDefaults.standard.array(forKey: "FavoriteSymbolIDs") as? [String] else {
            return
        }
        
        favoriteSymbols = ids.compactMap { idString in
            guard let uuid = UUID(uuidString: idString) else { return nil }
            return symbolsByID[uuid]
        }
    }
    
    func toggleFavorite(_ symbol: Symbol) {
        if favoriteSymbols.contains(where: { $0.id == symbol.id }) {
            favoriteSymbols.removeAll { $0.id == symbol.id }
        } else {
            favoriteSymbols.append(symbol)
        }
        
        saveFavorites()
    }
    
    func isFavorite(_ symbol: Symbol) -> Bool {
        favoriteSymbols.contains { $0.id == symbol.id }
    }
    
    private func saveFavorites() {
        let ids = favoriteSymbols.map { $0.id.uuidString }
        UserDefaults.standard.set(ids, forKey: "FavoriteSymbolIDs")
    }
    
    // MARK: - Recents
    
    private func loadRecents() {
        guard let ids = UserDefaults.standard.array(forKey: "RecentSymbolIDs") as? [String] else {
            return
        }
        
        recentSymbols = ids.compactMap { idString in
            guard let uuid = UUID(uuidString: idString) else { return nil }
            return symbolsByID[uuid]
        }
    }
    
    func markAsUsed(_ symbol: Symbol) {
        // Remove if already in recents
        recentSymbols.removeAll { $0.id == symbol.id }
        
        // Add to beginning
        recentSymbols.insert(symbol, at: 0)
        
        // Keep only most recent
        if recentSymbols.count > maxRecentSymbols {
            recentSymbols = Array(recentSymbols.prefix(maxRecentSymbols))
        }
        
        saveRecents()
    }
    
    private func saveRecents() {
        let ids = recentSymbols.map { $0.id.uuidString }
        UserDefaults.standard.set(ids, forKey: "RecentSymbolIDs")
    }
    
    // MARK: - Search
    
    func search(query: String) -> [Symbol] {
        guard !query.isEmpty else { return allSymbols }
        
        let lowercasedQuery = query.lowercased()
        
        return allSymbols.filter { symbol in
            // Search in label
            if symbol.label.lowercased().contains(lowercasedQuery) {
                return true
            }
            
            // Search in tags
            if symbol.tags.contains(where: { $0.lowercased().contains(lowercasedQuery) }) {
                return true
            }
            
            // Search in category
            if symbol.category.rawValue.lowercased().contains(lowercasedQuery) {
                return true
            }
            
            return false
        }
    }
    
    // MARK: - Symbol Retrieval
    
    func getSymbol(by id: UUID) -> Symbol? {
        symbolsByID[id]
    }
    
    func getSymbols(in category: SymbolCategory) -> [Symbol] {
        categories[category] ?? []
    }
}
