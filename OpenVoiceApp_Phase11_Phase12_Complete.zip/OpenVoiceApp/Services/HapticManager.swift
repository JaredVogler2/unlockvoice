//
//  HapticManager.swift
//  OpenVoice
//
//  Haptic feedback service for tactile responses
//  Phase 3: Speech Enhancement
//

import UIKit

class HapticManager {
    static let shared = HapticManager()
    
    private let impactLight = UIImpactFeedbackGenerator(style: .light)
    private let impactMedium = UIImpactFeedbackGenerator(style: .medium)
    private let impactHeavy = UIImpactFeedbackGenerator(style: .heavy)
    private let selectionGenerator = UISelectionFeedbackGenerator()
    private let notificationGenerator = UINotificationFeedbackGenerator()
    
    private init() {
        // Prepare generators for reduced latency
        prepare()
    }
    
    // MARK: - Public Methods
    
    /// Prepare haptic generators (call before anticipated use)
    func prepare() {
        impactLight.prepare()
        impactMedium.prepare()
        impactHeavy.prepare()
        selectionGenerator.prepare()
        notificationGenerator.prepare()
    }
    
    /// Generate impact feedback
    func impact(_ style: UIImpactFeedbackGenerator.FeedbackStyle) {
        switch style {
        case .light:
            impactLight.impactOccurred()
        case .medium:
            impactMedium.impactOccurred()
        case .heavy:
            impactHeavy.impactOccurred()
        case .soft:
            impactLight.impactOccurred(intensity: 0.5)
        case .rigid:
            impactHeavy.impactOccurred(intensity: 1.0)
        @unknown default:
            impactMedium.impactOccurred()
        }
    }
    
    /// Generate selection feedback (for pickers, segmented controls)
    func selection() {
        selectionGenerator.selectionChanged()
    }
    
    /// Generate notification feedback
    func notification(_ type: UINotificationFeedbackGenerator.FeedbackType) {
        notificationGenerator.notificationOccurred(type)
    }
    
    /// Success feedback
    func success() {
        notification(.success)
    }
    
    /// Warning feedback
    func warning() {
        notification(.warning)
    }
    
    /// Error feedback
    func error() {
        notification(.error)
    }
    
    // MARK: - Custom Patterns
    
    /// Play a custom pattern (e.g., for button press)
    func buttonPress() {
        impact(.light)
    }
    
    /// Play feedback for symbol selection
    func symbolSelected() {
        impact(.medium)
    }
    
    /// Play feedback for phrase spoken
    func phraseSpoken() {
        impact(.heavy)
    }
    
    /// Play feedback for delete action
    func delete() {
        impact(.medium)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.impact(.light)
        }
    }
    
    /// Play feedback for clear action
    func clear() {
        impact(.heavy)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            self.impact(.medium)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.impact(.light)
        }
    }
    
    /// Play feedback for adding to favorites
    func favorite() {
        impact(.medium)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.impact(.light)
        }
    }
}

// MARK: - Convenience Extensions

extension UIImpactFeedbackGenerator.FeedbackStyle {
    static var soft: UIImpactFeedbackGenerator.FeedbackStyle {
        .light
    }
    
    static var rigid: UIImpactFeedbackGenerator.FeedbackStyle {
        .heavy
    }
}
