"""
iOS API Service for Python Backend
Connects OpenVoice iOS app to Python ML backend

Phase 7 Implementation
"""

import Foundation

// MARK: - Request/Response Models

struct PredictionRequest: Codable {
    let context: [String]
    let maxPredictions: Int
    let userId: String?
    let timeOfDay: String?
    
    enum CodingKeys: String, CodingKey {
        case context
        case maxPredictions = "max_predictions"
        case userId = "user_id"
        case timeOfDay = "time_of_day"
    }
}

struct Prediction: Codable {
    let text: String
    let confidence: Double
    let source: String
    let metadata: [String: AnyCodable]?
}

struct PredictionResponse: Codable {
    let predictions: [Prediction]
    let latencyMs: Double
    let timestamp: String
    let modelVersion: String
    
    enum CodingKeys: String, CodingKey {
        case predictions
        case latencyMs = "latency_ms"
        case timestamp
        case modelVersion = "model_version"
    }
}

struct SentenceRequest: Codable {
    let symbols: [String]
    let preserveOrder: Bool
    let addGrammar: Bool
    
    enum CodingKeys: String, CodingKey {
        case symbols
        case preserveOrder = "preserve_order"
        case addGrammar = "add_grammar"
    }
}

struct SentenceResponse: Codable {
    let originalSymbols: [String]
    let formedSentence: String
    let confidence: Double
    let grammarChanges: [String]?
    let latencyMs: Double
    let timestamp: String
    
    enum CodingKeys: String, CodingKey {
        case originalSymbols = "original_symbols"
        case formedSentence = "formed_sentence"
        case confidence
        case grammarChanges = "grammar_changes"
        case latencyMs = "latency_ms"
        case timestamp
    }
}

// Helper for decoding Any values
struct AnyCodable: Codable {
    let value: Any
    
    init(_ value: Any) {
        self.value = value
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let intValue = try? container.decode(Int.self) {
            value = intValue
        } else if let doubleValue = try? container.decode(Double.self) {
            value = doubleValue
        } else if let stringValue = try? container.decode(String.self) {
            value = stringValue
        } else if let boolValue = try? container.decode(Bool.self) {
            value = boolValue
        } else {
            value = ""
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        if let intValue = value as? Int {
            try container.encode(intValue)
        } else if let doubleValue = value as? Double {
            try container.encode(doubleValue)
        } else if let stringValue = value as? String {
            try container.encode(stringValue)
        } else if let boolValue = value as? Bool {
            try container.encode(boolValue)
        }
    }
}

// MARK: - API Service

class APIService {
    static let shared = APIService()
    
    private let baseURL: String
    private let session: URLSession
    private var isConnected = false
    
    init(baseURL: String = "http://localhost:8000") {
        self.baseURL = baseURL
        
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 10.0
        config.timeoutIntervalForResource = 30.0
        self.session = URLSession(configuration: config)
    }
    
    // MARK: - Connection Management
    
    func checkHealth() async -> Bool {
        do {
            let url = URL(string: "\(baseURL)/health")!
            let (data, response) = try await session.data(from: url)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                return false
            }
            
            if httpResponse.statusCode == 200 {
                isConnected = true
                print("✅ Connected to Python backend")
                return true
            }
            
            isConnected = false
            return false
            
        } catch {
            print("❌ Backend connection failed: \(error.localizedDescription)")
            isConnected = false
            return false
        }
    }
    
    // MARK: - Prediction Endpoints
    
    func getPredictions(
        context: [String],
        maxPredictions: Int = 10,
        userId: String? = nil,
        timeOfDay: String? = nil
    ) async throws -> PredictionResponse {
        
        guard isConnected else {
            // Try to reconnect
            let connected = await checkHealth()
            if !connected {
                throw APIError.notConnected
            }
        }
        
        let url = URL(string: "\(baseURL)/api/v1/predict")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let requestBody = PredictionRequest(
            context: context,
            maxPredictions: maxPredictions,
            userId: userId,
            timeOfDay: timeOfDay
        )
        
        request.httpBody = try JSONEncoder().encode(requestBody)
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.invalidResponse
        }
        
        guard httpResponse.statusCode == 200 else {
            throw APIError.serverError(httpResponse.statusCode)
        }
        
        let predictionResponse = try JSONDecoder().decode(PredictionResponse.self, from: data)
        return predictionResponse
    }
    
    func formSentence(
        symbols: [String],
        preserveOrder: Bool = true,
        addGrammar: Bool = true
    ) async throws -> SentenceResponse {
        
        guard isConnected else {
            let connected = await checkHealth()
            if !connected {
                throw APIError.notConnected
            }
        }
        
        let url = URL(string: "\(baseURL)/api/v1/sentence/form")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let requestBody = SentenceRequest(
            symbols: symbols,
            preserveOrder: preserveOrder,
            addGrammar: addGrammar
        )
        
        request.httpBody = try JSONEncoder().encode(requestBody)
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.invalidResponse
        }
        
        guard httpResponse.statusCode == 200 else {
            throw APIError.serverError(httpResponse.statusCode)
        }
        
        let sentenceResponse = try JSONDecoder().decode(SentenceResponse.self, from: data)
        return sentenceResponse
    }
    
    func addConversation(text: String, metadata: [String: Any] = [:]) async throws {
        guard isConnected else {
            return // Silently fail for conversation tracking
        }
        
        let url = URL(string: "\(baseURL)/api/v1/conversation/add")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "text": text,
            "timestamp": ISO8601DateFormatter().string(from: Date()),
            "metadata": metadata
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (_, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            return // Silently fail
        }
    }
    
    func getMetrics() async throws -> [String: Any] {
        let url = URL(string: "\(baseURL)/metrics")!
        let (data, _) = try await session.data(from: url)
        
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw APIError.invalidResponse
        }
        
        return json
    }
}

// MARK: - Errors

enum APIError: Error, LocalizedError {
    case notConnected
    case invalidResponse
    case serverError(Int)
    case decodingError(Error)
    
    var errorDescription: String? {
        switch self {
        case .notConnected:
            return "Not connected to backend server"
        case .invalidResponse:
            return "Invalid response from server"
        case .serverError(let code):
            return "Server error: \(code)"
        case .decodingError(let error):
            return "Decoding error: \(error.localizedDescription)"
        }
    }
}

// MARK: - Integration with Existing ViewModel

extension PredictionViewModel {
    """
    Enhanced PredictionViewModel with backend integration
    
    Add this to your existing PredictionViewModel.swift
    """
    
    func updatePredictionsWithBackend(
        currentPhrase: [Symbol],
        allSymbols: [Symbol]
    ) async {
        // Try backend predictions first
        if await APIService.shared.checkHealth() {
            do {
                let context = currentPhrase.map { $0.label }
                let timeOfDay = getTimeOfDay()
                
                let response = try await APIService.shared.getPredictions(
                    context: context,
                    maxPredictions: 10,
                    timeOfDay: timeOfDay
                )
                
                // Convert backend predictions to local format
                let predictions = response.predictions.map { pred in
                    MLPrediction(
                        symbolId: pred.text,
                        label: pred.text,
                        confidence: pred.confidence,
                        source: .hybrid
                    )
                }
                
                await MainActor.run {
                    self.predictions = predictions
                }
                
                print("✅ Using backend predictions (latency: \(response.latencyMs)ms)")
                return
                
            } catch {
                print("⚠️ Backend prediction failed, using local: \(error)")
            }
        }
        
        // Fallback to local predictions
        updatePredictions(currentPhrase: currentPhrase, allSymbols: allSymbols)
    }
    
    private func getTimeOfDay() -> String {
        let hour = Calendar.current.component(.hour, from: Date())
        if hour >= 5 && hour < 12 {
            return "morning"
        } else if hour >= 12 && hour < 17 {
            return "afternoon"
        } else if hour >= 17 && hour < 21 {
            return "evening"
        } else {
            return "night"
        }
    }
}
