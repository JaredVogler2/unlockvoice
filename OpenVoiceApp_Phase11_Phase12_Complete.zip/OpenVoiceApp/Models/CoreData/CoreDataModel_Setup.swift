//
//  CoreDataModel_Setup.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Core Data Model Setup Instructions
//
//  ⚠️ IMPORTANT: This file describes the Core Data model structure
//  In Xcode, you need to create an actual .xcdatamodeld file
//

/*
 CORE DATA MODEL SETUP INSTRUCTIONS
 ===================================
 
 In Xcode, create a new Core Data Model file:
 File → New → File → Data Model
 Name: OpenVoiceDataModel.xcdatamodeld
 
 Then add the following entities:
 
 1. CONVERSATIONENTITY
 -------------------
 Attributes:
 - id: UUID (required)
 - text: String (required)
 - symbolIds: Transformable ([String]) (required)
 - timestamp: Date (required, indexed)
 - duration: Double (default: 0)
 - metadata: String (optional)
 
 Relationships:
 - session: To-One → SessionEntity (optional, nullify on delete)
 
 
 2. SYMBOLUSAGEENTITY
 ------------------
 Attributes:
 - id: UUID (required)
 - symbolId: String (required, indexed)
 - label: String (required)
 - category: String (optional, indexed)
 - usageCount: Integer 64 (default: 0)
 - firstUsed: Date (optional)
 - lastUsed: Date (optional, indexed)
 
 Relationships:
 - session: To-One → SessionEntity (optional, nullify on delete)
 - customSymbol: To-One → CustomSymbolEntity (optional, nullify on delete)
 
 
 3. CUSTOMSYMBOLENTITY
 -------------------
 Attributes:
 - id: UUID (required)
 - label: String (required)
 - imageData: Binary Data (required)
 - category: String (optional, indexed)
 - tags: Transformable ([String]) (optional)
 - createdAt: Date (required, indexed)
 - lastModified: Date (required)
 - lastUsed: Date (optional)
 - usageCount: Integer 64 (default: 0)
 - isFavorite: Boolean (default: NO)
 
 Relationships:
 - usages: To-Many → SymbolUsageEntity (nullify on delete)
 
 
 4. SESSIONENTITY
 --------------
 Attributes:
 - id: UUID (required)
 - startTime: Date (required, indexed)
 - endTime: Date (optional)
 - phraseCount: Integer 64 (default: 0)
 - symbolCount: Integer 64 (default: 0)
 
 Relationships:
 - conversations: To-Many → ConversationEntity (cascade on delete)
 - symbolUsages: To-Many → SymbolUsageEntity (nullify on delete)
 
 
 INDEXES AND PERFORMANCE
 ======================
 Add indexes on these attributes for better query performance:
 - ConversationEntity.timestamp
 - SymbolUsageEntity.symbolId
 - SymbolUsageEntity.lastUsed
 - SymbolUsageEntity.category
 - CustomSymbolEntity.createdAt
 - CustomSymbolEntity.category
 - SessionEntity.startTime
 
 
 DELETE RULES
 ============
 - SessionEntity → ConversationEntity: CASCADE (delete conversations when session deleted)
 - SessionEntity → SymbolUsageEntity: NULLIFY (keep usage data when session deleted)
 - CustomSymbolEntity → SymbolUsageEntity: NULLIFY (keep usage data when symbol deleted)
 
 
 MIGRATION
 =========
 This is the initial model (Version 1.0).
 For future model changes, create model versions and add migration mapping models.
 
 To add a model version in Xcode:
 1. Select the .xcdatamodeld file
 2. Editor → Add Model Version
 3. Create mapping models for migration
 
 
 TESTING
 =======
 After creating the model:
 1. Build the project
 2. Run PersistenceService.shared.printDatabaseContents()
 3. Verify entities can be created
 4. Check that relationships work correctly
 5. Test delete cascades
 
 
 TRANSFORMABLE ATTRIBUTES
 =======================
 For [String] arrays (symbolIds, tags):
 - Custom Class: NSArray
 - Transformer: NSSecureUnarchiveFromDataTransformer
 - Or implement custom ValueTransformer if needed
 
 For Binary Data (imageData):
 - Allows External Storage: YES (for large images)
 - This stores large binary data outside the SQLite database
 
*/

// MARK: - Example Usage

/*
 // Creating a conversation
 let conversation = ConversationEntity.create(
     in: context,
     text: "I want water",
     symbols: ["want", "water"],
     timestamp: Date()
 )
 
 // Recording symbol usage
 let usage = SymbolUsageEntity.recordUsage(
     symbolId: "water",
     label: "Water",
     category: "Food & Drink",
     in: context
 )
 
 // Creating custom symbol
 let symbol = CustomSymbolEntity.create(
     in: context,
     label: "My Cat",
     imageData: imageData,
     category: "Personal"
 )
 
 // Starting a session
 let session = SessionEntity.create(in: context)
 session.addConversation(
     text: "I want water",
     symbols: ["want", "water"],
     in: context
 )
 
 // Save changes
 PersistenceService.shared.save()
*/
