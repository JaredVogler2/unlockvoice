//
//  SymbolUsageEntity+CoreDataClass.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Core Data entity for tracking symbol usage frequency
//

import Foundation
import CoreData

@objc(SymbolUsageEntity)
public class SymbolUsageEntity: NSManagedObject {
    
    // MARK: - Convenience Initializers
    
    /// Create or update symbol usage
    @discardableResult
    static func recordUsage(
        symbolId: String,
        label: String,
        category: String? = nil,
        in context: NSManagedObjectContext,
        session: SessionEntity? = nil
    ) -> SymbolUsageEntity {
        // Try to find existing usage record
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "symbolId == %@", symbolId)
        request.fetchLimit = 1
        
        let existing = try? context.fetch(request).first
        
        if let usage = existing {
            // Update existing
            usage.usageCount += 1
            usage.lastUsed = Date()
            return usage
        } else {
            // Create new
            let usage = SymbolUsageEntity(context: context)
            usage.id = UUID()
            usage.symbolId = symbolId
            usage.label = label
            usage.category = category
            usage.usageCount = 1
            usage.firstUsed = Date()
            usage.lastUsed = Date()
            usage.session = session
            return usage
        }
    }
    
    // MARK: - Computed Properties
    
    /// Usage frequency category
    var frequencyCategory: UsageFrequency {
        if usageCount >= 100 {
            return .veryHigh
        } else if usageCount >= 50 {
            return .high
        } else if usageCount >= 20 {
            return .medium
        } else if usageCount >= 5 {
            return .low
        } else {
            return .rare
        }
    }
    
    /// Days since first use
    var daysSinceFirstUse: Int {
        guard let firstUsed = firstUsed else { return 0 }
        let days = Calendar.current.dateComponents([.day], from: firstUsed, to: Date()).day ?? 0
        return max(0, days)
    }
    
    /// Average uses per day
    var averageUsesPerDay: Double {
        let days = max(1, daysSinceFirstUse)
        return Double(usageCount) / Double(days)
    }
}

// MARK: - Usage Frequency Enum

enum UsageFrequency: String {
    case veryHigh = "Very High"
    case high = "High"
    case medium = "Medium"
    case low = "Low"
    case rare = "Rare"
}

// MARK: - SymbolUsageEntity+CoreDataProperties

extension SymbolUsageEntity {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<SymbolUsageEntity> {
        return NSFetchRequest<SymbolUsageEntity>(entityName: "SymbolUsageEntity")
    }
    
    @NSManaged public var id: UUID?
    @NSManaged public var symbolId: String?
    @NSManaged public var label: String?
    @NSManaged public var category: String?
    @NSManaged public var usageCount: Int64
    @NSManaged public var firstUsed: Date?
    @NSManaged public var lastUsed: Date?
    @NSManaged public var session: SessionEntity?
    @NSManaged public var customSymbol: CustomSymbolEntity?
}

// MARK: - Identifiable

extension SymbolUsageEntity: Identifiable {
    
}

// MARK: - Fetch Helpers

extension SymbolUsageEntity {
    
    /// Fetch all symbol usages, sorted by usage count
    static func fetchAll(in context: NSManagedObjectContext) -> [SymbolUsageEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \SymbolUsageEntity.usageCount, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching symbol usages: \(error)")
            return []
        }
    }
    
    /// Fetch most used symbols (top N)
    static func fetchMostUsed(
        limit: Int,
        in context: NSManagedObjectContext
    ) -> [SymbolUsageEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \SymbolUsageEntity.usageCount, ascending: false)]
        request.fetchLimit = limit
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching most used symbols: \(error)")
            return []
        }
    }
    
    /// Fetch recently used symbols
    static func fetchRecentlyUsed(
        limit: Int,
        in context: NSManagedObjectContext
    ) -> [SymbolUsageEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \SymbolUsageEntity.lastUsed, ascending: false)]
        request.fetchLimit = limit
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching recently used symbols: \(error)")
            return []
        }
    }
    
    /// Fetch usage for specific symbol
    static func fetchUsage(
        for symbolId: String,
        in context: NSManagedObjectContext
    ) -> SymbolUsageEntity? {
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "symbolId == %@", symbolId)
        request.fetchLimit = 1
        
        do {
            return try context.fetch(request).first
        } catch {
            print("❌ Error fetching symbol usage: \(error)")
            return nil
        }
    }
    
    /// Fetch usages by category
    static func fetchByCategory(
        category: String,
        in context: NSManagedObjectContext
    ) -> [SymbolUsageEntity] {
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "category == %@", category)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \SymbolUsageEntity.usageCount, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching category usages: \(error)")
            return []
        }
    }
    
    /// Calculate total usage count across all symbols
    static func totalUsageCount(in context: NSManagedObjectContext) -> Int64 {
        let request = fetchRequest()
        
        do {
            let results = try context.fetch(request)
            return results.reduce(0) { $0 + $1.usageCount }
        } catch {
            print("❌ Error calculating total usage: \(error)")
            return 0
        }
    }
}
