//
//  CustomSymbolEntity+CoreDataClass.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Core Data entity for custom user-created symbols
//

import Foundation
import CoreData
import UIImage

@objc(CustomSymbolEntity)
public class CustomSymbolEntity: NSManagedObject {
    
    // MARK: - Convenience Initializers
    
    /// Create a new custom symbol entity
    @discardableResult
    static func create(
        in context: NSManagedObjectContext,
        label: String,
        imageData: Data,
        category: String? = nil,
        tags: [String]? = nil
    ) -> CustomSymbolEntity {
        let symbol = CustomSymbolEntity(context: context)
        symbol.id = UUID()
        symbol.label = label
        symbol.imageData = imageData
        symbol.category = category
        symbol.tags = tags
        symbol.createdAt = Date()
        symbol.lastModified = Date()
        symbol.usageCount = 0
        return symbol
    }
    
    // MARK: - Computed Properties
    
    /// Convert image data to UIImage
    var image: UIImage? {
        guard let data = imageData else { return nil }
        return UIImage(data: data)
    }
    
    /// Image size in bytes
    var imageSizeInBytes: Int {
        return imageData?.count ?? 0
    }
    
    /// Image size formatted
    var formattedImageSize: String {
        let bytes = imageSizeInBytes
        if bytes < 1024 {
            return "\(bytes) B"
        } else if bytes < 1024 * 1024 {
            return String(format: "%.1f KB", Double(bytes) / 1024.0)
        } else {
            return String(format: "%.1f MB", Double(bytes) / (1024.0 * 1024.0))
        }
    }
    
    /// Time since creation
    var timeSinceCreation: TimeInterval {
        guard let created = createdAt else { return 0 }
        return Date().timeIntervalSince(created)
    }
    
    /// Days since last use
    var daysSinceLastUsed: Int? {
        guard let lastUsed = lastUsed else { return nil }
        let days = Calendar.current.dateComponents([.day], from: lastUsed, to: Date()).day
        return max(0, days ?? 0)
    }
}

// MARK: - CustomSymbolEntity+CoreDataProperties

extension CustomSymbolEntity {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<CustomSymbolEntity> {
        return NSFetchRequest<CustomSymbolEntity>(entityName: "CustomSymbolEntity")
    }
    
    @NSManaged public var id: UUID?
    @NSManaged public var label: String?
    @NSManaged public var imageData: Data?
    @NSManaged public var category: String?
    @NSManaged public var tags: [String]?
    @NSManaged public var createdAt: Date?
    @NSManaged public var lastModified: Date?
    @NSManaged public var lastUsed: Date?
    @NSManaged public var usageCount: Int64
    @NSManaged public var isFavorite: Bool
    @NSManaged public var usages: NSSet?
}

// MARK: - Identifiable

extension CustomSymbolEntity: Identifiable {
    
}

// MARK: - Relationships

extension CustomSymbolEntity {
    
    @objc(addUsagesObject:)
    @NSManaged public func addToUsages(_ value: SymbolUsageEntity)
    
    @objc(removeUsagesObject:)
    @NSManaged public func removeFromUsages(_ value: SymbolUsageEntity)
    
    @objc(addUsages:)
    @NSManaged public func addToUsages(_ values: NSSet)
    
    @objc(removeUsages:)
    @NSManaged public func removeFromUsages(_ values: NSSet)
}

// MARK: - Fetch Helpers

extension CustomSymbolEntity {
    
    /// Fetch all custom symbols
    static func fetchAll(in context: NSManagedObjectContext) -> [CustomSymbolEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CustomSymbolEntity.createdAt, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching custom symbols: \(error)")
            return []
        }
    }
    
    /// Fetch recent custom symbols
    static func fetchRecent(
        limit: Int,
        in context: NSManagedObjectContext
    ) -> [CustomSymbolEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CustomSymbolEntity.createdAt, ascending: false)]
        request.fetchLimit = limit
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching recent custom symbols: \(error)")
            return []
        }
    }
    
    /// Fetch favorite custom symbols
    static func fetchFavorites(in context: NSManagedObjectContext) -> [CustomSymbolEntity] {
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "isFavorite == YES")
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CustomSymbolEntity.usageCount, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching favorite symbols: \(error)")
            return []
        }
    }
    
    /// Fetch by category
    static func fetchByCategory(
        category: String,
        in context: NSManagedObjectContext
    ) -> [CustomSymbolEntity] {
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "category == %@", category)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CustomSymbolEntity.label, ascending: true)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching symbols by category: \(error)")
            return []
        }
    }
    
    /// Search custom symbols
    static func search(
        query: String,
        in context: NSManagedObjectContext
    ) -> [CustomSymbolEntity] {
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "label CONTAINS[cd] %@", query)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CustomSymbolEntity.usageCount, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error searching custom symbols: \(error)")
            return []
        }
    }
    
    /// Fetch most used custom symbols
    static func fetchMostUsed(
        limit: Int,
        in context: NSManagedObjectContext
    ) -> [CustomSymbolEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \CustomSymbolEntity.usageCount, ascending: false)]
        request.fetchLimit = limit
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching most used symbols: \(error)")
            return []
        }
    }
    
    /// Count total custom symbols
    static func count(in context: NSManagedObjectContext) -> Int {
        let request = fetchRequest()
        
        do {
            return try context.count(for: request)
        } catch {
            print("❌ Error counting custom symbols: \(error)")
            return 0
        }
    }
    
    /// Calculate total storage used by custom symbol images
    static func totalStorageUsed(in context: NSManagedObjectContext) -> Int64 {
        let symbols = fetchAll(in: context)
        return symbols.reduce(0) { $0 + Int64($1.imageSizeInBytes) }
    }
}

// MARK: - Update Helpers

extension CustomSymbolEntity {
    
    /// Update image
    func updateImage(_ imageData: Data) {
        self.imageData = imageData
        self.lastModified = Date()
    }
    
    /// Update label
    func updateLabel(_ newLabel: String) {
        self.label = newLabel
        self.lastModified = Date()
    }
    
    /// Toggle favorite status
    func toggleFavorite() {
        self.isFavorite.toggle()
        self.lastModified = Date()
    }
    
    /// Record usage
    func recordUsage() {
        self.usageCount += 1
        self.lastUsed = Date()
    }
}
