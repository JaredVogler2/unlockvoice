//
//  ConversationEntity+CoreDataClass.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Core Data entity for conversation history
//

import Foundation
import CoreData

@objc(ConversationEntity)
public class ConversationEntity: NSManagedObject {
    
    // MARK: - Convenience Initializers
    
    /// Create a new conversation entity
    @discardableResult
    static func create(
        in context: NSManagedObjectContext,
        text: String,
        symbols: [String],
        timestamp: Date = Date(),
        duration: Double = 0,
        session: SessionEntity? = nil
    ) -> ConversationEntity {
        let conversation = ConversationEntity(context: context)
        conversation.id = UUID()
        conversation.text = text
        conversation.symbolIds = symbols
        conversation.timestamp = timestamp
        conversation.duration = duration
        conversation.session = session
        return conversation
    }
    
    // MARK: - Computed Properties
    
    /// Number of symbols in this conversation
    var symbolCount: Int {
        return symbolIds?.count ?? 0
    }
    
    /// Formatted timestamp
    var formattedTimestamp: String {
        guard let timestamp = timestamp else { return "" }
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: timestamp)
    }
    
    /// Time ago string (e.g., "5 minutes ago")
    var timeAgo: String {
        guard let timestamp = timestamp else { return "" }
        let now = Date()
        let seconds = now.timeIntervalSince(timestamp)
        
        if seconds < 60 {
            return "just now"
        } else if seconds < 3600 {
            let minutes = Int(seconds / 60)
            return "\(minutes) minute\(minutes == 1 ? "" : "s") ago"
        } else if seconds < 86400 {
            let hours = Int(seconds / 3600)
            return "\(hours) hour\(hours == 1 ? "" : "s") ago"
        } else {
            let days = Int(seconds / 86400)
            return "\(days) day\(days == 1 ? "" : "s") ago"
        }
    }
}

// MARK: - ConversationEntity+CoreDataProperties

extension ConversationEntity {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<ConversationEntity> {
        return NSFetchRequest<ConversationEntity>(entityName: "ConversationEntity")
    }
    
    @NSManaged public var id: UUID?
    @NSManaged public var text: String?
    @NSManaged public var symbolIds: [String]?
    @NSManaged public var timestamp: Date?
    @NSManaged public var duration: Double
    @NSManaged public var metadata: String?
    @NSManaged public var session: SessionEntity?
}

// MARK: - Identifiable

extension ConversationEntity: Identifiable {
    
}

// MARK: - Fetch Helpers

extension ConversationEntity {
    
    /// Fetch all conversations, sorted by timestamp
    static func fetchAll(in context: NSManagedObjectContext) -> [ConversationEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \ConversationEntity.timestamp, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching conversations: \(error)")
            return []
        }
    }
    
    /// Fetch recent conversations (last N)
    static func fetchRecent(
        limit: Int,
        in context: NSManagedObjectContext
    ) -> [ConversationEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \ConversationEntity.timestamp, ascending: false)]
        request.fetchLimit = limit
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching recent conversations: \(error)")
            return []
        }
    }
    
    /// Fetch conversations within date range
    static func fetchBetween(
        startDate: Date,
        endDate: Date,
        in context: NSManagedObjectContext
    ) -> [ConversationEntity] {
        let request = fetchRequest()
        request.predicate = NSPredicate(
            format: "timestamp >= %@ AND timestamp <= %@",
            startDate as NSDate,
            endDate as NSDate
        )
        request.sortDescriptors = [NSSortDescriptor(keyPath: \ConversationEntity.timestamp, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching conversations in range: \(error)")
            return []
        }
    }
    
    /// Search conversations by text
    static func search(
        query: String,
        in context: NSManagedObjectContext
    ) -> [ConversationEntity] {
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "text CONTAINS[cd] %@", query)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \ConversationEntity.timestamp, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error searching conversations: \(error)")
            return []
        }
    }
    
    /// Count total conversations
    static func count(in context: NSManagedObjectContext) -> Int {
        let request = fetchRequest()
        
        do {
            return try context.count(for: request)
        } catch {
            print("❌ Error counting conversations: \(error)")
            return 0
        }
    }
}
