//
//  SessionEntity+CoreDataClass.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Core Data entity for tracking usage sessions
//

import Foundation
import CoreData

@objc(SessionEntity)
public class SessionEntity: NSManagedObject {
    
    // MARK: - Convenience Initializers
    
    /// Create a new session entity
    @discardableResult
    static func create(
        in context: NSManagedObjectContext,
        startTime: Date = Date()
    ) -> SessionEntity {
        let session = SessionEntity(context: context)
        session.id = UUID()
        session.startTime = startTime
        session.phraseCount = 0
        session.symbolCount = 0
        return session
    }
    
    /// Get or create today's session
    static func getTodaySession(in context: NSManagedObjectContext) -> SessionEntity {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        
        // Try to find existing session for today
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "startTime >= %@", today as NSDate)
        request.fetchLimit = 1
        
        if let existing = try? context.fetch(request).first {
            return existing
        } else {
            // Create new session for today
            return create(in: context, startTime: today)
        }
    }
    
    // MARK: - Computed Properties
    
    /// Session duration
    var duration: TimeInterval {
        guard let start = startTime else { return 0 }
        let end = endTime ?? Date()
        return end.timeIntervalSince(start)
    }
    
    /// Formatted duration (e.g., "1h 23m")
    var formattedDuration: String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m"
        } else {
            return "\(minutes)m"
        }
    }
    
    /// Is session currently active?
    var isActive: Bool {
        return endTime == nil
    }
    
    /// Average phrase length
    var averagePhraseLength: Double {
        guard phraseCount > 0 else { return 0 }
        return Double(symbolCount) / Double(phraseCount)
    }
    
    /// Symbols per minute
    var symbolsPerMinute: Double {
        let minutes = max(1, duration / 60)
        return Double(symbolCount) / minutes
    }
}

// MARK: - SessionEntity+CoreDataProperties

extension SessionEntity {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<SessionEntity> {
        return NSFetchRequest<SessionEntity>(entityName: "SessionEntity")
    }
    
    @NSManaged public var id: UUID?
    @NSManaged public var startTime: Date?
    @NSManaged public var endTime: Date?
    @NSManaged public var phraseCount: Int64
    @NSManaged public var symbolCount: Int64
    @NSManaged public var conversations: NSSet?
    @NSManaged public var symbolUsages: NSSet?
}

// MARK: - Identifiable

extension SessionEntity: Identifiable {
    
}

// MARK: - Relationships

extension SessionEntity {
    
    @objc(addConversationsObject:)
    @NSManaged public func addToConversations(_ value: ConversationEntity)
    
    @objc(removeConversationsObject:)
    @NSManaged public func removeFromConversations(_ value: ConversationEntity)
    
    @objc(addConversations:)
    @NSManaged public func addToConversations(_ values: NSSet)
    
    @objc(removeConversations:)
    @NSManaged public func removeFromConversations(_ values: NSSet)
    
    @objc(addSymbolUsagesObject:)
    @NSManaged public func addToSymbolUsages(_ value: SymbolUsageEntity)
    
    @objc(removeSymbolUsagesObject:)
    @NSManaged public func removeFromSymbolUsages(_ value: SymbolUsageEntity)
    
    @objc(addSymbolUsages:)
    @NSManaged public func addToSymbolUsages(_ values: NSSet)
    
    @objc(removeSymbolUsages:)
    @NSManaged public func removeFromSymbolUsages(_ values: NSSet)
}

// MARK: - Session Management

extension SessionEntity {
    
    /// End the current session
    func endSession() {
        self.endTime = Date()
    }
    
    /// Add a conversation to this session
    func addConversation(text: String, symbols: [String], in context: NSManagedObjectContext) {
        let conversation = ConversationEntity.create(
            in: context,
            text: text,
            symbols: symbols,
            session: self
        )
        
        self.phraseCount += 1
        self.symbolCount += Int64(symbols.count)
        self.addToConversations(conversation)
    }
    
    /// Record symbol usage
    func recordSymbolUsage(
        symbolId: String,
        label: String,
        category: String? = nil,
        in context: NSManagedObjectContext
    ) {
        let usage = SymbolUsageEntity.recordUsage(
            symbolId: symbolId,
            label: label,
            category: category,
            in: context,
            session: self
        )
        
        self.addToSymbolUsages(usage)
    }
}

// MARK: - Fetch Helpers

extension SessionEntity {
    
    /// Fetch all sessions
    static func fetchAll(in context: NSManagedObjectContext) -> [SessionEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \SessionEntity.startTime, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching sessions: \(error)")
            return []
        }
    }
    
    /// Fetch recent sessions
    static func fetchRecent(
        limit: Int,
        in context: NSManagedObjectContext
    ) -> [SessionEntity] {
        let request = fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \SessionEntity.startTime, ascending: false)]
        request.fetchLimit = limit
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching recent sessions: \(error)")
            return []
        }
    }
    
    /// Fetch sessions within date range
    static func fetchBetween(
        startDate: Date,
        endDate: Date,
        in context: NSManagedObjectContext
    ) -> [SessionEntity] {
        let request = fetchRequest()
        request.predicate = NSPredicate(
            format: "startTime >= %@ AND startTime <= %@",
            startDate as NSDate,
            endDate as NSDate
        )
        request.sortDescriptors = [NSSortDescriptor(keyPath: \SessionEntity.startTime, ascending: false)]
        
        do {
            return try context.fetch(request)
        } catch {
            print("❌ Error fetching sessions in range: \(error)")
            return []
        }
    }
    
    /// Fetch active session
    static func fetchActive(in context: NSManagedObjectContext) -> SessionEntity? {
        let request = fetchRequest()
        request.predicate = NSPredicate(format: "endTime == nil")
        request.fetchLimit = 1
        
        do {
            return try context.fetch(request).first
        } catch {
            print("❌ Error fetching active session: \(error)")
            return nil
        }
    }
    
    /// Count total sessions
    static func count(in context: NSManagedObjectContext) -> Int {
        let request = fetchRequest()
        
        do {
            return try context.count(for: request)
        } catch {
            print("❌ Error counting sessions: \(error)")
            return 0
        }
    }
}

// MARK: - Analytics

extension SessionEntity {
    
    /// Calculate total time spent across all sessions
    static func totalTimeSpent(in context: NSManagedObjectContext) -> TimeInterval {
        let sessions = fetchAll(in: context)
        return sessions.reduce(0) { $0 + $1.duration }
    }
    
    /// Calculate total phrases across all sessions
    static func totalPhrases(in context: NSManagedObjectContext) -> Int64 {
        let sessions = fetchAll(in: context)
        return sessions.reduce(0) { $0 + $1.phraseCount }
    }
    
    /// Calculate total symbols used across all sessions
    static func totalSymbols(in context: NSManagedObjectContext) -> Int64 {
        let sessions = fetchAll(in: context)
        return sessions.reduce(0) { $0 + $1.symbolCount }
    }
}
