//
//  Phrase.swift
//  OpenVoice
//
//  Model for building and managing phrases from symbols
//

import Foundation

/// Represents a phrase built from symbols
struct Phrase: Identifiable, Codable {
    let id: UUID
    var symbols: [Symbol]
    var timestamp: Date
    var wasSpoken: Bool
    
    init(id: UUID = UUID(), symbols: [Symbol] = [], timestamp: Date = Date(), wasSpoken: Bool = false) {
        self.id = id
        self.symbols = symbols
        self.timestamp = timestamp
        self.wasSpoken = wasSpoken
    }
    
    /// Get the raw text of the phrase (space-separated labels)
    var rawText: String {
        symbols.map { $0.label }.joined(separator: " ")
    }
    
    /// Get the text with proper grammar (will use BERT in later phase)
    var formattedText: String {
        // Phase 1: Simple concatenation
        // Phase 9: Will use BERT for proper grammar
        return rawText.capitalizingFirstLetter()
    }
    
    /// Check if phrase is empty
    var isEmpty: Bool {
        symbols.isEmpty
    }
    
    /// Add a symbol to the phrase
    mutating func add(_ symbol: Symbol) {
        symbols.append(symbol)
    }
    
    /// Remove the last symbol
    mutating func removeLast() {
        if !symbols.isEmpty {
            symbols.removeLast()
        }
    }
    
    /// Clear all symbols
    mutating func clear() {
        symbols.removeAll()
    }
}

/// Helper for phrase history
struct PhraseHistory: Codable {
    var phrases: [Phrase]
    var maxHistory: Int = 100
    
    init(phrases: [Phrase] = []) {
        self.phrases = phrases
    }
    
    mutating func add(_ phrase: Phrase) {
        phrases.insert(phrase, at: 0)
        // Keep only most recent phrases
        if phrases.count > maxHistory {
            phrases = Array(phrases.prefix(maxHistory))
        }
    }
    
    /// Get phrases from today
    var today: [Phrase] {
        let calendar = Calendar.current
        return phrases.filter { calendar.isDateInToday($0.timestamp) }
    }
    
    /// Get most frequently used symbols
    func mostFrequentSymbols(limit: Int = 20) -> [Symbol] {
        var symbolCounts: [String: (symbol: Symbol, count: Int)] = [:]
        
        for phrase in phrases {
            for symbol in phrase.symbols {
                if let existing = symbolCounts[symbol.label] {
                    symbolCounts[symbol.label] = (symbol, existing.count + 1)
                } else {
                    symbolCounts[symbol.label] = (symbol, 1)
                }
            }
        }
        
        return symbolCounts.values
            .sorted { $0.count > $1.count }
            .prefix(limit)
            .map { $0.symbol }
    }
}

// MARK: - String Extension
extension String {
    func capitalizingFirstLetter() -> String {
        return prefix(1).capitalized + dropFirst()
    }
}
