//
//  UserProfile.swift
//  OpenVoice
//
//  User profile and personalization data
//

import Foundation

struct UserProfile: Identifiable, Codable {
    let id: UUID
    var name: String
    var createdDate: Date
    var customSymbols: [Symbol]
    var phraseHistory: PhraseHistory
    var vocabularyPreferences: VocabularyPreferences
    
    init(id: UUID = UUID(),
         name: String = "User",
         createdDate: Date = Date(),
         customSymbols: [Symbol] = [],
         phraseHistory: PhraseHistory = PhraseHistory(),
         vocabularyPreferences: VocabularyPreferences = VocabularyPreferences()) {
        self.id = id
        self.name = name
        self.createdDate = createdDate
        self.customSymbols = customSymbols
        self.phraseHistory = phraseHistory
        self.vocabularyPreferences = vocabularyPreferences
    }
    
    // MARK: - Persistence
    
    static func loadDefault() -> UserProfile {
        guard let data = UserDefaults.standard.data(forKey: "DefaultUserProfile"),
              let profile = try? JSONDecoder().decode(UserProfile.self, from: data) else {
            return UserProfile()
        }
        return profile
    }
    
    func save() {
        if let data = try? JSONEncoder().encode(self) {
            UserDefaults.standard.set(data, forKey: "DefaultUserProfile")
        }
    }
}

struct VocabularyPreferences: Codable {
    var favoriteSymbols: [UUID] = []
    var hiddenCategories: [SymbolCategory] = []
    var customCategories: [CustomCategory] = []
    
    struct CustomCategory: Codable, Identifiable {
        let id: UUID
        var name: String
        var symbolIDs: [UUID]
        var icon: String
        
        init(id: UUID = UUID(), name: String, symbolIDs: [UUID] = [], icon: String = "folder") {
            self.id = id
            self.name = name
            self.symbolIDs = symbolIDs
            self.icon = icon
        }
    }
}

// MARK: - Calibration Manager

class CalibrationManager {
    static let shared = CalibrationManager()
    private init() {}
    
    var isCalibrated: Bool {
        get { UserDefaults.standard.bool(forKey: "EyeTrackingCalibrated") }
        set { UserDefaults.standard.set(newValue, forKey: "EyeTrackingCalibrated") }
    }
    
    var calibrationData: CalibrationData? {
        get {
            guard let data = UserDefaults.standard.data(forKey: "CalibrationData"),
                  let calibration = try? JSONDecoder().decode(CalibrationData.self, from: data) else {
                return nil
            }
            return calibration
        }
        set {
            if let data = try? JSONEncoder().encode(newValue) {
                UserDefaults.standard.set(data, forKey: "CalibrationData")
            }
        }
    }
}

struct CalibrationData: Codable {
    var points: [CalibrationPoint]
    var calibrationDate: Date
    
    struct CalibrationPoint: Codable {
        var screenPoint: CGPoint
        var gazePoint: CGPoint
        var accuracy: Double
    }
}
