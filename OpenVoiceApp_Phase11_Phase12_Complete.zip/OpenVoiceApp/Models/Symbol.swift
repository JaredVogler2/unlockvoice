//
//  Symbol.swift
//  OpenVoice
//
//  Core symbol model for AAC communication
//

import Foundation
import SwiftUI

/// Represents a single AAC symbol (image + label)
struct Symbol: Identifiable, Codable, Hashable {
    let id: UUID
    var label: String // Text displayed and spoken
    var imageName: String // Asset name or file path
    var category: SymbolCategory
    var tags: [String]
    var frequency: Int // Usage frequency for sorting
    
    // Custom image data (for user-created symbols)
    var customImageData: Data?
    
    init(id: UUID = UUID(),
         label: String,
         imageName: String,
         category: SymbolCategory = .general,
         tags: [String] = [],
         frequency: Int = 0,
         customImageData: Data? = nil) {
        self.id = id
        self.label = label
        self.imageName = imageName
        self.category = category
        self.tags = tags
        self.frequency = frequency
        self.customImageData = customImageData
    }
}

/// Symbol categories for organization
enum SymbolCategory: String, Codable, CaseIterable {
    case people = "People"
    case food = "Food"
    case activities = "Activities"
    case feelings = "Feelings"
    case places = "Places"
    case things = "Things"
    case actions = "Actions"
    case descriptors = "Descriptors"
    case questions = "Questions"
    case general = "General"
    case custom = "Custom"
    
    var icon: String {
        switch self {
        case .people: return "person.2.fill"
        case .food: return "fork.knife"
        case .activities: return "figure.run"
        case .feelings: return "face.smiling"
        case .places: return "house.fill"
        case .things: return "cube.fill"
        case .actions: return "hand.point.up.fill"
        case .descriptors: return "textformat"
        case .questions: return "questionmark.circle"
        case .general: return "square.grid.2x2"
        case .custom: return "star.fill"
        }
    }
    
    var color: Color {
        switch self {
        case .people: return .blue
        case .food: return .green
        case .activities: return .orange
        case .feelings: return .yellow
        case .places: return .purple
        case .things: return .gray
        case .actions: return .red
        case .descriptors: return .pink
        case .questions: return .cyan
        case .general: return .primary
        case .custom: return .mint
        }
    }
}

/// Extension for creating sample/default symbols
extension Symbol {
    static let sampleSymbols: [Symbol] = [
        Symbol(label: "I", imageName: "person.fill", category: .people, tags: ["pronoun", "self"]),
        Symbol(label: "want", imageName: "hand.raised.fill", category: .actions, tags: ["desire"]),
        Symbol(label: "eat", imageName: "fork.knife", category: .actions, tags: ["food"]),
        Symbol(label: "drink", imageName: "drop.fill", category: .actions, tags: ["beverage"]),
        Symbol(label: "help", imageName: "hand.raised.fingers.spread.fill", category: .actions, tags: ["request"]),
        Symbol(label: "yes", imageName: "checkmark.circle.fill", category: .general, tags: ["affirmative"]),
        Symbol(label: "no", imageName: "xmark.circle.fill", category: .general, tags: ["negative"]),
        Symbol(label: "happy", imageName: "face.smiling.fill", category: .feelings, tags: ["emotion", "positive"]),
        Symbol(label: "sad", imageName: "cloud.rain.fill", category: .feelings, tags: ["emotion", "negative"]),
        Symbol(label: "tired", imageName: "bed.double.fill", category: .feelings, tags: ["state"]),
        Symbol(label: "play", imageName: "gamecontroller.fill", category: .activities, tags: ["fun"]),
        Symbol(label: "music", imageName: "music.note", category: .activities, tags: ["entertainment"]),
        Symbol(label: "home", imageName: "house.fill", category: .places, tags: ["location"]),
        Symbol(label: "bathroom", imageName: "toilet.fill", category: .places, tags: ["location", "essential"]),
        Symbol(label: "more", imageName: "plus.circle.fill", category: .descriptors, tags: ["quantity"]),
        Symbol(label: "stop", imageName: "hand.raised.slash.fill", category: .actions, tags: ["command"]),
    ]
}
