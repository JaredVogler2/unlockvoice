//
//  AppSettings.swift
//  OpenVoice
//
//  Centralized app settings and preferences
//  Phase 3: Enhanced with speech settings
//

import Foundation
import AVFoundation

struct AppSettings: Codable {
    // MARK: - Speech Settings
    var speechRate: Float = 0.5 // Range: 0.0 (slowest) to 1.0 (fastest)
    var speechPitch: Float = 1.0 // Range: 0.5 to 2.0
    var speechVolume: Float = 1.0 // Range: 0.0 to 1.0
    var selectedVoice: String = "com.apple.ttsbundle.Samantha-compact" // Default English voice
    
    // MARK: - Grid Settings
    var gridColumns: Int = 4 // Number of columns in symbol grid
    var symbolSize: SymbolSize = .medium
    var showLabels: Bool = true
    var labelPosition: LabelPosition = .bottom
    
    // MARK: - Phrase Bar Settings
    var phraseBarHeight: CGFloat = 80
    var showPredictions: Bool = true
    var maxPhraseLength: Int = 20 // Max words in a phrase
    
    // MARK: - Accessibility Settings
    var dwellTime: Double = 1.0 // Seconds for eye-tracking dwell selection (legacy, use eyeTracking.dwellTime)
    var highContrast: Bool = false
    var largeText: Bool = false
    var hapticFeedback: Bool = true
    var soundEffects: Bool = true
    
    // MARK: - Eye Tracking Settings (Phase 4)
    var eyeTracking: EyeTrackingSettings = EyeTrackingSettings()
    
    // MARK: - Advanced Speech Settings
    var enablePronunciationDictionary: Bool = true
    var saveToHistory: Bool = true
    var historyLimit: Int = 100
    var autoSpeak: Bool = false // Auto-speak when phrase is complete
    var speakOnSymbolSelect: Bool = false // Speak each symbol as selected
    
    // MARK: - UI Preferences
    var colorScheme: ColorSchemePreference = .system
    var primaryColor: String = "blue"
    var animations: Bool = true
    var compactMode: Bool = false
    
    // MARK: - Persistence
    
    private static let settingsKey = "AppSettings"
    
    static func load() -> AppSettings {
        guard let data = UserDefaults.standard.data(forKey: settingsKey),
              let settings = try? JSONDecoder().decode(AppSettings.self, from: data) else {
            return AppSettings()
        }
        return settings
    }
    
    func save() {
        if let data = try? JSONEncoder().encode(self) {
            UserDefaults.standard.set(data, forKey: AppSettings.settingsKey)
        }
    }
    
    // MARK: - Convenience Methods
    
    /// Reset all settings to defaults
    mutating func resetToDefaults() {
        self = AppSettings()
    }
    
    /// Get formatted speech rate for display (e.g., "50%")
    var speechRatePercentage: String {
        "\(Int(speechRate * 100))%"
    }
    
    /// Get formatted pitch for display (e.g., "Normal", "Low", "High")
    var pitchDescription: String {
        switch speechPitch {
        case ..<0.8: return "Low"
        case 0.8..<1.2: return "Normal"
        default: return "High"
        }
    }
}

// MARK: - Supporting Types

enum SymbolSize: String, Codable, CaseIterable {
    case small = "Small"
    case medium = "Medium"
    case large = "Large"
    case extraLarge = "Extra Large"
    
    var dimension: CGFloat {
        switch self {
        case .small: return 60
        case .medium: return 80
        case .large: return 100
        case .extraLarge: return 120
        }
    }
}

enum LabelPosition: String, Codable, CaseIterable {
    case top = "Top"
    case bottom = "Bottom"
    case hidden = "Hidden"
}

enum ColorSchemePreference: String, Codable, CaseIterable {
    case light = "Light"
    case dark = "Dark"
    case system = "System"
}

// MARK: - Settings Manager (Observable)

import Combine

class SettingsManager: ObservableObject {
    static let shared = SettingsManager()
    
    @Published var settings: AppSettings {
        didSet {
            settings.save()
        }
    }
    
    private init() {
        self.settings = AppSettings.load()
    }
    
    // MARK: - Quick Access Methods
    
    func updateSpeechRate(_ rate: Float) {
        settings.speechRate = max(0.0, min(1.0, rate))
    }
    
    func updateSpeechPitch(_ pitch: Float) {
        settings.speechPitch = max(0.5, min(2.0, pitch))
    }
    
    func updateVoice(_ voiceIdentifier: String) {
        settings.selectedVoice = voiceIdentifier
    }
    
    func toggleHapticFeedback() {
        settings.hapticFeedback.toggle()
    }
    
    func toggleHighContrast() {
        settings.highContrast.toggle()
    }
    
    // MARK: - Voice Helpers
    
    func getCurrentVoice() -> AVSpeechSynthesisVoice? {
        AVSpeechSynthesisVoice(identifier: settings.selectedVoice)
    }
    
    func getAvailableVoices() -> [AVSpeechSynthesisVoice] {
        AVSpeechSynthesisVoice.speechVoices()
            .filter { $0.language.starts(with: "en") }
            .sorted { $0.name < $1.name }
    }
}

// MARK: - Eye Tracking Settings (Phase 4)

struct EyeTrackingSettings: Codable {
    var enabled: Bool = false
    var dwellTime: TimeInterval = 1.0
    var movementTolerance: CGFloat = 30
    var smoothingFrames: Int = 3
    var dwellPreset: String = "normal"
    
    // Feedback
    var visualFeedback: Bool = true
    var hapticFeedback: Bool = true
    var soundFeedback: Bool = false
    
    // UI
    var showGazeCursor: Bool = true
    var showTrackingQuality: Bool = true
    
    // Advanced
    var requireStableGaze: Bool = true
    var debugMode: Bool = false
}
