# 🎨 PHASE 11: AI IMAGE GENERATION - START HERE

## 🌟 Welcome to Phase 11!

**Phase 11 brings AI-powered custom symbol creation to OpenVoice!**

Instead of searching for symbols or taking photos, users can now **describe what they want** and have AI generate beautiful, custom symbols instantly.

---

## 🎯 What You'll Build

### Core Features
1. **Text-to-Image Generation** - Describe a symbol, get an image
2. **Style Control** - Simple icon, flat design, realistic, etc.
3. **Background Options** - White, transparent, colored
4. **Batch Generation** - Create multiple variations at once
5. **Quality Options** - Fast (20 steps) vs Quality (50 steps)
6. **Symbol Refinement** - Regenerate until perfect

### Example Usage
```
User: "Generate a symbol for 'beach vacation'"
AI: Creates a beautiful icon showing beach, umbrella, and waves
User: "Make it more colorful"
AI: Regenerates with vibrant colors
User: "Perfect! Save to library"
```

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│              iOS Application                         │
│                                                      │
│  ┌────────────────────────────────────────────┐   │
│  │     ImageGenerationService.swift            │   │
│  │     • Request generation                    │   │
│  │     • Style selection                       │   │
│  │     • Progress tracking                     │   │
│  │     • Image caching                         │   │
│  └─────────────────┬──────────────────────────┘   │
│                    │                                │
│  ┌─────────────────────────────────────────────┐  │
│  │     SymbolGeneratorView.swift               │  │
│  │     • Prompt input                          │  │
│  │     • Preview gallery                       │  │
│  │     • Style picker                          │  │
│  │     • Save to library                       │  │
│  └─────────────────────────────────────────────┘  │
└────────────────────┼────────────────────────────────┘
                     │ REST API
                     │ (HTTP/JSON + binary)
                     ▼
┌─────────────────────────────────────────────────────┐
│         Python Backend (FastAPI)                     │
│                                                      │
│  ┌─────────────────────────────────────────────┐  │
│  │      image_router.py (API Endpoints)         │  │
│  │      • POST /api/v1/image/generate           │  │
│  │      • POST /api/v1/image/batch              │  │
│  │      • POST /api/v1/image/refine             │  │
│  │      • GET  /api/v1/image/styles             │  │
│  └─────────────────┬───────────────────────────┘  │
│                    │                                │
│                    ▼                                │
│  ┌─────────────────────────────────────────────┐  │
│  │      stable_diffusion_engine.py             │  │
│  │      • Stable Diffusion XL integration      │  │
│  │      • Prompt engineering                   │  │
│  │      • Style templates                      │  │
│  │      • Image post-processing                │  │
│  │      • Model management                     │  │
│  └─────────────────┬───────────────────────────┘  │
│                    │                                │
│                    ▼                                │
│  ┌─────────────────────────────────────────────┐  │
│  │    Stable Diffusion XL 1.0 (SDXL)          │  │
│  │    • 1024x1024 generation                   │  │
│  │    • 8GB VRAM requirement                   │  │
│  │    • 20-50 inference steps                  │  │
│  │    • Multiple style presets                 │  │
│  └─────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start Guide

### Prerequisites
- ✅ Phase 10 complete (Python backend running)
- ✅ Apple Silicon Mac (M1/M2/M3) with 16GB+ RAM
- ✅ 20GB free disk space (for model)
- ✅ Python 3.10+
- ✅ iOS 15.0+ device/simulator

### Installation (30 minutes)

#### Step 1: Install Dependencies
```bash
cd OpenVoiceApp/PythonBackend

# Install Stable Diffusion requirements
pip install -r requirements_phase11.txt --break-system-packages

# This installs:
# - diffusers (Stable Diffusion)
# - transformers (Model support)
# - torch (PyTorch with MPS support)
# - accelerate (Speed optimization)
# - safetensors (Model format)
# - Pillow (Image processing)
```

#### Step 2: Download Model (One-time, ~10 minutes)
```bash
# The model will auto-download on first use
# Or pre-download with:
python -c "from diffusers import StableDiffusionXLPipeline; \
           StableDiffusionXLPipeline.from_pretrained('stabilityai/stable-diffusion-xl-base-1.0')"
```

#### Step 3: Start Backend
```bash
# Terminal 1: Start FastAPI server
uvicorn src.main:app --reload --host 0.0.0.0 --port 8000

# You should see:
# ✅ Image generation service initialized
# ✅ Stable Diffusion XL loaded
```

#### Step 4: Test Image Generation
```bash
# Terminal 2: Test generation
curl -X POST http://localhost:8000/api/v1/image/generate \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "beach vacation",
    "style": "simple_icon",
    "steps": 20
  }' \
  --output test_symbol.png

# Check test_symbol.png was created
open test_symbol.png
```

#### Step 5: Add iOS Files
```swift
// Add these files to your Xcode project:
Services/ImageGenerationService.swift
Views/SymbolGeneratorView.swift
ViewModels/ImageGeneratorViewModel.swift
Models/GeneratedImage.swift
```

#### Step 6: Build and Run
```bash
# In Xcode:
# 1. Add new files to project
# 2. Update ContentView.swift to include SymbolGeneratorView
# 3. Build (Cmd+B)
# 4. Run (Cmd+R)
```

---

## 🎨 Using Image Generation

### Basic Generation

```swift
// 1. Simple generation
let service = ImageGenerationService.shared
let image = try await service.generate(
    prompt: "happy face emoji",
    style: .simpleIcon
)

// 2. With options
let image = try await service.generate(
    prompt: "red apple",
    style: .flatDesign,
    steps: 30,
    background: .white
)

// 3. Batch generation (4 variations)
let images = try await service.generateBatch(
    prompt: "ocean waves",
    style: .simpleIcon,
    count: 4
)
```

### UI Usage

1. **Open Symbol Generator**
   - Tap "Create Symbol" button
   - Select "AI Generate" option

2. **Enter Description**
   - Type what you want: "chocolate cake"
   - Choose style: Simple Icon, Flat Design, Realistic
   - Tap "Generate"

3. **Review Results**
   - See generated image preview
   - Tap "Regenerate" if needed
   - Tap "More Options" for variations

4. **Save to Library**
   - Tap "Save Symbol"
   - Enter label (auto-filled)
   - Choose category
   - Done!

---

## 📊 Performance Specs

### Generation Times
| Device | Quality | Steps | Time | Status |
|--------|---------|-------|------|--------|
| M3 Max | Fast | 20 | ~15s | ⚡ Excellent |
| M3 Pro | Fast | 20 | ~20s | ✅ Great |
| M2 Pro | Fast | 20 | ~25s | ✅ Good |
| M1 Pro | Fast | 20 | ~35s | ✅ OK |
| M1 Base | Fast | 20 | ~50s | ⚠️ Slow |

| Device | Quality | Steps | Time | Status |
|--------|---------|-------|------|--------|
| M3 Max | High | 50 | ~35s | ✅ Great |
| M2 Pro | High | 50 | ~60s | ✅ Good |
| M1 Pro | High | 50 | ~90s | ⚠️ Slow |

### Resource Usage
- **Model Size**: 6.9GB (SDXL base)
- **VRAM**: 6-8GB during generation
- **RAM**: 8GB+ recommended
- **Disk**: 20GB for model + cache
- **Power**: ~20W during generation

---

## 🎯 Style Presets

### 1. Simple Icon (Default)
```
Prompt: "simple icon of {subject}, flat design, minimalist, 
         white background, vector style, clean lines"
Best for: AAC symbols, UI elements, quick recognition
Speed: Fastest (20 steps)
```

### 2. Flat Design
```
Prompt: "flat design illustration of {subject}, colorful,
         simple shapes, modern style, white background"
Best for: Colorful symbols, engaging visuals
Speed: Fast (25 steps)
```

### 3. Realistic
```
Prompt: "photorealistic {subject}, high quality, 
         professional photography, studio lighting"
Best for: Real objects, food, people
Speed: Slower (40 steps)
```

### 4. Cartoon
```
Prompt: "cute cartoon {subject}, friendly, simple,
         bright colors, children's illustration style"
Best for: Kids' symbols, fun imagery
Speed: Fast (25 steps)
```

### 5. Line Art
```
Prompt: "simple line drawing of {subject}, black and white,
         clean lines, coloring book style, minimal detail"
Best for: High contrast, printable symbols
Speed: Fastest (15 steps)
```

### 6. Watercolor
```
Prompt: "watercolor painting of {subject}, soft colors,
         artistic, gentle strokes, white background"
Best for: Soft, calming symbols
Speed: Medium (30 steps)
```

---

## 🔧 Configuration

### Backend Settings (`src/config/image_config.py`)

```python
IMAGE_CONFIG = {
    # Model
    "model_name": "stabilityai/stable-diffusion-xl-base-1.0",
    "model_variant": "fp16",  # fp16 for speed, fp32 for quality
    
    # Generation
    "default_width": 1024,
    "default_height": 1024,
    "default_steps": 20,
    "min_steps": 15,
    "max_steps": 50,
    
    # Quality
    "guidance_scale": 7.5,  # How closely to follow prompt
    "negative_prompt": "blurry, distorted, ugly, low quality",
    
    # Caching
    "cache_enabled": True,
    "cache_dir": "cache/images",
    "cache_max_size": "5GB",
    
    # Safety
    "safety_checker": True,
    "watermark": False,
}
```

### iOS Settings

```swift
struct ImageGenerationConfig {
    static let apiURL = "http://localhost:8000/api/v1/image"
    static let timeoutSeconds: Double = 120
    static let maxRetries = 3
    static let defaultStyle: ImageStyle = .simpleIcon
    static let defaultSteps = 20
    static let cacheEnabled = true
    static let maxCacheSize: Int64 = 500_000_000 // 500MB
}
```

---

## 🧪 Testing

### Backend Tests
```bash
cd PythonBackend

# Test image generation
pytest tests/test_image_generation.py -v

# Test specific style
pytest tests/test_image_generation.py::test_simple_icon -v

# Performance benchmark
pytest tests/test_image_generation.py::test_performance -v
```

### iOS Tests
```swift
// Test generation
func testImageGeneration() async throws {
    let service = ImageGenerationService.shared
    let image = try await service.generate(
        prompt: "test symbol",
        style: .simpleIcon
    )
    XCTAssertNotNil(image)
}

// Test caching
func testImageCaching() async throws {
    let service = ImageGenerationService.shared
    
    // First generation
    let start1 = Date()
    let image1 = try await service.generate(prompt: "test")
    let time1 = Date().timeIntervalSince(start1)
    
    // Second generation (should be cached)
    let start2 = Date()
    let image2 = try await service.generate(prompt: "test")
    let time2 = Date().timeIntervalSince(start2)
    
    XCTAssertLessThan(time2, time1 * 0.1) // 10x faster
}
```

---

## 📝 API Reference

### Generate Single Image
```
POST /api/v1/image/generate
```

**Request:**
```json
{
  "prompt": "beach vacation",
  "style": "simple_icon",
  "steps": 20,
  "width": 1024,
  "height": 1024,
  "background": "white",
  "seed": null
}
```

**Response:**
```json
{
  "image": "base64_encoded_image_data...",
  "metadata": {
    "prompt": "simple icon of beach vacation, flat design...",
    "style": "simple_icon",
    "steps": 20,
    "seed": 42,
    "generation_time": 15.2,
    "size": [1024, 1024]
  }
}
```

### Generate Batch
```
POST /api/v1/image/batch
```

**Request:**
```json
{
  "prompt": "apple",
  "style": "simple_icon",
  "count": 4,
  "steps": 20
}
```

**Response:**
```json
{
  "images": [
    {"image": "base64...", "seed": 42},
    {"image": "base64...", "seed": 43},
    {"image": "base64...", "seed": 44},
    {"image": "base64...", "seed": 45}
  ],
  "metadata": {
    "total_time": 60.8,
    "average_time": 15.2
  }
}
```

---

## 🔍 Troubleshooting

### Issue: Model Download Fails
```bash
# Solution: Manual download
huggingface-cli download stabilityai/stable-diffusion-xl-base-1.0

# Or use different mirror
export HF_ENDPOINT=https://hf-mirror.com
```

### Issue: Generation Too Slow
```python
# Solution 1: Reduce steps
steps = 15  # Instead of 20

# Solution 2: Use smaller model
model_name = "stabilityai/stable-diffusion-2-1"  # Faster

# Solution 3: Enable MPS acceleration
device = "mps"  # Mac GPU acceleration
```

### Issue: Out of Memory
```python
# Solution 1: Reduce resolution
width, height = 512, 512  # Instead of 1024

# Solution 2: Clear cache
import torch
torch.mps.empty_cache()

# Solution 3: Use model offloading
pipe.enable_model_cpu_offload()
```

### Issue: Poor Quality Images
```python
# Solution 1: Increase steps
steps = 40  # Instead of 20

# Solution 2: Improve prompt
prompt = "high quality icon of apple, professional, detailed"

# Solution 3: Adjust guidance
guidance_scale = 9.0  # Stronger prompt following
```

---

## 📚 Best Practices

### Prompt Engineering for Symbols

**Good Prompts:**
```
✅ "simple icon of red apple, flat design, white background"
✅ "cartoon cat face, friendly, cute, minimal"
✅ "line drawing of house, black and white, clean"
```

**Bad Prompts:**
```
❌ "apple"  (too vague)
❌ "give me a really nice beautiful amazing apple symbol"  (too wordy)
❌ "apple banana orange"  (conflicting subjects)
```

### Style Selection

- **Simple Icon**: Best for most AAC symbols
- **Flat Design**: When you want color and vibrancy
- **Realistic**: For food, objects that need recognition
- **Cartoon**: For children's apps
- **Line Art**: For high contrast, accessibility

### Performance Optimization

1. **Use caching**: Same prompt = instant retrieval
2. **Batch generate**: Create variations in one request
3. **Start with fast**: Use 20 steps, only increase if needed
4. **Progressive loading**: Show low-res preview while generating
5. **Background generation**: Generate during idle time

---

## 🎯 Success Criteria

| Metric | Target | Status |
|--------|--------|--------|
| Generation speed | <30s | ⏱️ Test |
| Image quality | 8/10+ | 🎨 Test |
| Success rate | >95% | 📊 Test |
| User satisfaction | >4.5/5 | 👥 Test |
| Model size | <10GB | ✅ 6.9GB |
| Memory usage | <10GB | 📊 Test |

---

## 🚀 What's Next?

After completing Phase 11, you'll have:
- ✅ AI-powered symbol generation
- ✅ Multiple style options
- ✅ Fast, on-device processing
- ✅ Unlimited custom symbols
- ✅ Production-ready image pipeline

**Next Phase**: Phase 12 - App Store Release! 🎉

---

## 📖 Additional Resources

### Documentation
- [Stable Diffusion Docs](https://stability.ai/docs)
- [Diffusers Library](https://huggingface.co/docs/diffusers)
- [SDXL Paper](https://arxiv.org/abs/2307.01952)

### Tutorials
- [Prompt Engineering Guide](https://promptingguide.com)
- [Image Generation Best Practices](https://huggingface.co/docs/diffusers/using-diffusers/sdxl)
- [MPS Acceleration](https://pytorch.org/docs/stable/notes/mps.html)

### Community
- [Stable Diffusion Discord](https://discord.gg/stablediffusion)
- [Hugging Face Forums](https://discuss.huggingface.co/)
- [OpenVoice Discord](https://discord.gg/openvoice)

---

**Ready to start? Let's make some symbols!** 🎨✨

---

*Phase 11: Image Generation - START HERE*  
*Version: 1.0.0*  
*Date: October 13, 2025*  
*Status: 🚀 READY TO BUILD*
