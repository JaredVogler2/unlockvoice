//
//  CalibrationView.swift
//  OpenVoice
//
//  Eye tracking calibration interface
//  Full implementation in Phase 4
//

import SwiftUI

struct CalibrationView: View {
    @Binding var isPresented: Bool
    @EnvironmentObject var appState: AppState
    @State private var currentStep = 0
    
    // Calibration points (9-point calibration)
    private let calibrationPoints: [CGPoint] = [
        CGPoint(x: 0.1, y: 0.1),   // Top-left
        CGPoint(x: 0.5, y: 0.1),   // Top-center
        CGPoint(x: 0.9, y: 0.1),   // Top-right
        CGPoint(x: 0.1, y: 0.5),   // Middle-left
        CGPoint(x: 0.5, y: 0.5),   // Center
        CGPoint(x: 0.9, y: 0.5),   // Middle-right
        CGPoint(x: 0.1, y: 0.9),   // Bottom-left
        CGPoint(x: 0.5, y: 0.9),   // Bottom-center
        CGPoint(x: 0.9, y: 0.9)    // Bottom-right
    ]
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                // Header
                HStack {
                    Button("Cancel") {
                        isPresented = false
                    }
                    .foregroundColor(.white)
                    
                    Spacer()
                    
                    Text("Calibration \(currentStep + 1)/\(calibrationPoints.count)")
                        .foregroundColor(.white)
                        .fontWeight(.medium)
                    
                    Spacer()
                    
                    Color.clear.frame(width: 80) // Spacer for symmetry
                }
                .padding()
                
                Spacer()
                
                // Phase 4: Will show calibration target at current point
                // For now, show placeholder
                VStack(spacing: 20) {
                    Text("Eye Tracking Calibration")
                        .font(.title)
                        .foregroundColor(.white)
                    
                    Text("Phase 4: Coming Soon")
                        .font(.headline)
                        .foregroundColor(.white.opacity(0.7))
                    
                    Text("This will implement ARKit-based eye tracking with 9-point calibration")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.5))
                        .multilineTextAlignment(.center)
                        .padding()
                }
                
                Spacer()
                
                // Instructions
                Text("Look at each target when it appears")
                    .font(.headline)
                    .foregroundColor(.white.opacity(0.8))
                    .padding()
            }
        }
    }
}

// MARK: - Calibration Target (for Phase 4)

struct CalibrationTarget: View {
    let position: CGPoint
    @State private var scale: CGFloat = 0.5
    
    var body: some View {
        Circle()
            .fill(
                RadialGradient(
                    colors: [.white, .blue],
                    center: .center,
                    startRadius: 0,
                    endRadius: 30
                )
            )
            .frame(width: 60, height: 60)
            .scaleEffect(scale)
            .animation(
                .easeInOut(duration: 1.0).repeatForever(autoreverses: true),
                value: scale
            )
            .onAppear {
                scale = 1.0
            }
    }
}

// MARK: - Preview

struct CalibrationView_Previews: PreviewProvider {
    static var previews: some View {
        CalibrationView(isPresented: .constant(true))
            .environmentObject(AppState())
    }
}
