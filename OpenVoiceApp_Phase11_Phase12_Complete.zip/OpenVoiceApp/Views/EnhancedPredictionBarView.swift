//
//  EnhancedPredictionBarView.swift
//  OpenVoice - Phase 6
//
//  Enhanced prediction UI with ML confidence visualization
//

import SwiftUI

struct EnhancedPredictionBarView: View {
    @ObservedObject var viewModel: PredictionViewModel
    let onSelectPrediction: (MLPrediction) -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header with ML indicator
            HStack {
                Image(systemName: "brain")
                    .foregroundColor(.purple)
                Text("Smart Predictions")
                    .font(.caption)
                    .fontWeight(.semibold)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                if viewModel.isLoading {
                    ProgressView()
                        .scaleEffect(0.7)
                }
                
                if let lastUpdate = viewModel.lastUpdateTime {
                    Text(timeAgo(lastUpdate))
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
            }
            .padding(.horizontal)
            .padding(.top, 8)
            
            // Predictions Grid
            if viewModel.predictions.isEmpty {
                emptyStateView
            } else {
                predictionGrid
            }
        }
        .background(Color(.systemBackground))
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(Color(.systemGray5)),
            alignment: .top
        )
    }
    
    // MARK: - Prediction Grid
    private var predictionGrid: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(viewModel.predictions) { prediction in
                    PredictionCard(
                        prediction: prediction,
                        onSelect: {
                            onSelectPrediction(prediction)
                        }
                    )
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 12)
        }
    }
    
    // MARK: - Empty State
    private var emptyStateView: some View {
        VStack(spacing: 8) {
            Image(systemName: "wand.and.stars")
                .font(.title)
                .foregroundColor(.gray)
            Text("Start building a phrase")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 24)
    }
    
    // MARK: - Helper Methods
    private func timeAgo(_ date: Date) -> String {
        let seconds = Date().timeIntervalSince(date)
        if seconds < 1 {
            return "now"
        } else if seconds < 60 {
            return "\(Int(seconds))s ago"
        } else {
            return "\(Int(seconds / 60))m ago"
        }
    }
}

// MARK: - Prediction Card
struct PredictionCard: View {
    let prediction: MLPrediction
    let onSelect: () -> Void
    
    @State private var isPressed = false
    
    var body: some View {
        Button(action: {
            withAnimation(.easeInOut(duration: 0.1)) {
                isPressed = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                withAnimation(.easeInOut(duration: 0.1)) {
                    isPressed = false
                }
                onSelect()
            }
        }) {
            VStack(alignment: .leading, spacing: 6) {
                // Main label with source icon
                HStack(spacing: 6) {
                    Image(systemName: sourceIcon)
                        .font(.caption2)
                        .foregroundColor(confidenceColor)
                    
                    Text(prediction.label)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.primary)
                }
                
                // Confidence bar
                GeometryReader { geometry in
                    ZStack(alignment: .leading) {
                        // Background
                        RoundedRectangle(cornerRadius: 2)
                            .fill(Color(.systemGray6))
                        
                        // Progress
                        RoundedRectangle(cornerRadius: 2)
                            .fill(confidenceColor)
                            .frame(width: geometry.size.width * CGFloat(prediction.confidence))
                    }
                }
                .frame(height: 4)
                
                // Confidence percentage
                HStack {
                    Text(confidenceText)
                        .font(.caption2)
                        .fontWeight(.medium)
                        .foregroundColor(confidenceColor)
                    
                    Spacer()
                    
                    Text(prediction.category)
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .frame(width: 140)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(.secondarySystemBackground))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(confidenceColor.opacity(0.3), lineWidth: 1)
                    )
            )
            .scaleEffect(isPressed ? 0.95 : 1.0)
            .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    // MARK: - Computed Properties
    private var confidenceColor: Color {
        switch prediction.confidence {
        case 0.8...1.0:
            return .green
        case 0.5..<0.8:
            return .orange
        default:
            return .gray
        }
    }
    
    private var confidenceText: String {
        String(format: "%.0f%%", prediction.confidence * 100)
    }
    
    private var sourceIcon: String {
        switch prediction.source {
        case .nGram:
            return "link"
        case .contextual:
            return "clock"
        case .frequency:
            return "chart.bar"
        case .hybrid:
            return "sparkles"
        }
    }
}

// MARK: - Preview
#if DEBUG
struct EnhancedPredictionBarView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            Spacer()
            EnhancedPredictionBarView(
                viewModel: PredictionViewModel.preview,
                onSelectPrediction: { prediction in
                    print("Selected: \(prediction.label)")
                }
            )
        }
        .previewLayout(.sizeThatFits)
    }
}
#endif
