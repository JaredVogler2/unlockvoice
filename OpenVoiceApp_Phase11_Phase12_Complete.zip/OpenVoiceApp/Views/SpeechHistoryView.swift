//
//  SpeechHistoryView.swift
//  OpenVoice
//
//  View and replay speech history
//  Phase 3: Speech Enhancement
//

import SwiftUI

struct SpeechHistoryView: View {
    @ObservedObject private var speechService = SpeechService.shared
    @Environment(\.dismiss) var dismiss
    @State private var selectedFilter: HistoryFilter = .all
    @State private var searchText = ""
    
    enum HistoryFilter: String, CaseIterable {
        case all = "All"
        case today = "Today"
        case thisWeek = "This Week"
        case thisMonth = "This Month"
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Search bar
                if !speechService.speechHistory.isEmpty {
                    SearchBar(text: $searchText)
                        .padding()
                }
                
                // Filter picker
                if !speechService.speechHistory.isEmpty {
                    Picker("Filter", selection: $selectedFilter) {
                        ForEach(HistoryFilter.allCases, id: \.self) { filter in
                            Text(filter.rawValue).tag(filter)
                        }
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal)
                    .padding(.bottom, 8)
                }
                
                // History list
                if filteredHistory.isEmpty {
                    EmptyHistoryView()
                } else {
                    List {
                        ForEach(filteredHistory) { item in
                            HistoryItemRow(item: item) {
                                speechService.replayHistoryItem(item)
                            }
                        }
                        .onDelete(perform: deleteItems)
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Speech History")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Close") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button(role: .destructive) {
                            showClearConfirmation()
                        } label: {
                            Label("Clear All History", systemImage: "trash")
                        }
                        
                        Button {
                            exportHistory()
                        } label: {
                            Label("Export History", systemImage: "square.and.arrow.up")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
        }
    }
    
    private var filteredHistory: [SpeechHistoryItem] {
        var history = speechService.speechHistory
        
        // Apply time filter
        let calendar = Calendar.current
        let now = Date()
        
        switch selectedFilter {
        case .today:
            history = history.filter { calendar.isDateInToday($0.timestamp) }
        case .thisWeek:
            history = history.filter {
                calendar.dateComponents([.weekOfYear], from: $0.timestamp, to: now).weekOfYear == 0
            }
        case .thisMonth:
            history = history.filter {
                calendar.dateComponents([.month], from: $0.timestamp, to: now).month == 0
            }
        case .all:
            break
        }
        
        // Apply search filter
        if !searchText.isEmpty {
            history = history.filter {
                $0.originalText.localizedCaseInsensitiveContains(searchText)
            }
        }
        
        return history
    }
    
    private func deleteItems(at offsets: IndexSet) {
        // Note: This removes from filtered list, need to map to actual indices
        // For simplicity, we'll just clear specific items
        for index in offsets {
            if let item = filteredHistory[safe: index] {
                speechService.speechHistory.removeAll { $0.id == item.id }
            }
        }
    }
    
    private func showClearConfirmation() {
        // Would use .confirmationDialog in real app
        speechService.clearHistory()
    }
    
    private func exportHistory() {
        // Export history to text file
        let text = filteredHistory.map { item in
            """
            \(item.timestamp.formatted())
            \(item.originalText)
            ---
            """
        }.joined(separator: "\n\n")
        
        // In real app, would use UIActivityViewController
        print("Export: \(text)")
    }
}

// MARK: - History Item Row

struct HistoryItemRow: View {
    let item: SpeechHistoryItem
    let onReplay: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            // Play button
            Button(action: onReplay) {
                Image(systemName: "play.circle.fill")
                    .font(.title2)
                    .foregroundColor(.blue)
            }
            .buttonStyle(.plain)
            
            // Content
            VStack(alignment: .leading, spacing: 4) {
                Text(item.originalText)
                    .font(.body)
                    .lineLimit(3)
                
                HStack(spacing: 12) {
                    Label(item.timestamp.formatted(date: .omitted, time: .shortened), systemImage: "clock")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    if item.originalText != item.processedText {
                        Image(systemName: "wand.and.stars")
                            .font(.caption)
                            .foregroundColor(.purple)
                    }
                    
                    Text(item.voice)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Empty State

struct EmptyHistoryView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "waveform")
                .font(.system(size: 60))
                .foregroundColor(.secondary)
            
            Text("No Speech History")
                .font(.title2)
                .fontWeight(.medium)
            
            Text("Phrases you speak will appear here, so you can replay them later")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
        .padding()
    }
}

// MARK: - Array Extension for Safe Access

extension Array {
    subscript(safe index: Index) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}

// MARK: - Preview

struct SpeechHistoryView_Previews: PreviewProvider {
    static var previews: some View {
        SpeechHistoryView()
    }
}
