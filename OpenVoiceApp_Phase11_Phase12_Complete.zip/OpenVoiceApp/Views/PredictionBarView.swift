//
//  PredictionBarView.swift
//  OpenVoice
//
//  AI-powered word prediction bar
//

import SwiftUI

struct PredictionBarView: View {
    @StateObject private var viewModel = PredictionViewModel()
    @ObservedObject private var phraseManager = PhraseManager.shared
    
    var body: some View {
        VStack(spacing: 0) {
            Divider()
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    if viewModel.predictions.isEmpty {
                        Text("Predictions will appear here")
                            .foregroundColor(.secondary)
                            .italic()
                            .font(.subheadline)
                            .padding()
                    } else {
                        ForEach(viewModel.predictions) { prediction in
                            PredictionButton(prediction: prediction) {
                                selectPrediction(prediction)
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
            }
            .frame(height: 60)
            .background(Color(UIColor.tertiarySystemGroupedBackground))
        }
        .onChange(of: phraseManager.currentPhrase.symbols) { _ in
            viewModel.updatePredictions(for: phraseManager.currentPhrase)
        }
    }
    
    private func selectPrediction(_ prediction: Prediction) {
        // Find the symbol that matches this prediction
        // Phase 6-8: This will be more sophisticated with ML
        if let symbol = Symbol.sampleSymbols.first(where: { $0.label == prediction.text }) {
            phraseManager.addSymbol(symbol)
            HapticManager.shared.impact(.light)
        }
    }
}

// MARK: - Prediction Button

struct PredictionButton: View {
    let prediction: Prediction
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 2) {
                Text(prediction.text)
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                
                // Confidence indicator
                if prediction.confidence > 0 {
                    ConfidenceBar(confidence: prediction.confidence)
                        .frame(width: 40, height: 2)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(UIColor.secondarySystemGroupedBackground))
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Confidence Bar

struct ConfidenceBar: View {
    let confidence: Double
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                
                Rectangle()
                    .fill(confidenceColor)
                    .frame(width: geometry.size.width * CGFloat(confidence))
            }
            .cornerRadius(1)
        }
    }
    
    private var confidenceColor: Color {
        if confidence > 0.7 { return .green }
        if confidence > 0.4 { return .orange }
        return .red
    }
}

// MARK: - Preview

struct PredictionBarView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            Spacer()
            PredictionBarView()
        }
    }
}
