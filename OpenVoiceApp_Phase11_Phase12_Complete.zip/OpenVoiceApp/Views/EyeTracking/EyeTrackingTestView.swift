//
//  EyeTrackingTestView.swift
//  OpenVoice
//
//  Test interface for eye tracking accuracy
//  Phase 4: ARKit Eye Tracking
//

import SwiftUI
import ARKit

struct EyeTrackingTestView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var eyeTracking = EyeTrackingManager.shared
    @State private var sceneView = ARSCNView()
    @State private var testTargets: [TestTarget] = []
    @State private var currentTargetIndex = 0
    @State private var hits = 0
    @State private var misses = 0
    @State private var testInProgress = false
    
    var body: some View {
        ZStack {
            // AR Scene
            ARSceneViewRepresentable(sceneView: $sceneView)
                .ignoresSafeArea()
            
            // Gaze indicator
            if eyeTracking.isTracking {
                GazeIndicatorView(eyeTracking: eyeTracking)
            }
            
            // Test UI
            if !testInProgress {
                instructionsOverlay
            } else {
                testTargetsOverlay
            }
            
            // Results
            if testInProgress {
                resultsOverlay
            }
            
            // Header
            VStack {
                headerBar
                Spacer()
            }
        }
        .onAppear {
            setupTest()
        }
        .onDisappear {
            eyeTracking.stopTracking()
        }
    }
    
    // MARK: - Header
    
    private var headerBar: some View {
        HStack {
            Button(action: { dismiss() }) {
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding()
                    .background(Circle().fill(Color.black.opacity(0.5)))
            }
            
            Spacer()
            
            if testInProgress {
                VStack(spacing: 4) {
                    Text("Test in Progress")
                        .font(.headline)
                    Text("\(hits + misses)/\(testTargets.count)")
                        .font(.caption)
                }
                .foregroundColor(.white)
                .padding()
                .background(Capsule().fill(Color.black.opacity(0.5)))
            }
            
            Spacer()
            
            // Placeholder for symmetry
            Color.clear
                .frame(width: 44, height: 44)
                .padding()
        }
        .padding(.top)
    }
    
    // MARK: - Instructions
    
    private var instructionsOverlay: some View {
        VStack(spacing: 24) {
            Spacer()
            
            VStack(spacing: 16) {
                Image(systemName: "target")
                    .font(.system(size: 60))
                    .foregroundColor(.blue)
                
                Text("Eye Tracking Test")
                    .font(.title)
                    .fontWeight(.bold)
                
                Text("Look at each target to select it")
                    .font(.headline)
                    .foregroundColor(.secondary)
                
                Text("This will test your eye tracking accuracy")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color(UIColor.systemBackground))
                    .shadow(radius: 10)
            )
            .padding()
            
            Button(action: startTest) {
                HStack {
                    Image(systemName: "play.fill")
                    Text("Start Test")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: 300)
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(12)
            }
            .padding(.bottom, 50)
        }
    }
    
    // MARK: - Test Targets
    
    private var testTargetsOverlay: some View {
        ZStack {
            // Draw all test targets
            ForEach(testTargets) { target in
                TestTargetView(
                    target: target,
                    isActive: target.id == testTargets[safe: currentTargetIndex]?.id,
                    gazePoint: eyeTracking.gazePoint,
                    onHit: { handleHit(target) },
                    onMiss: { handleMiss() }
                )
            }
        }
    }
    
    // MARK: - Results
    
    private var resultsOverlay: some View {
        VStack {
            Spacer()
            
            HStack(spacing: 40) {
                VStack {
                    Text("\(hits)")
                        .font(.system(size: 40, weight: .bold))
                        .foregroundColor(.green)
                    Text("Hits")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                VStack {
                    Text("\(misses)")
                        .font(.system(size: 40, weight: .bold))
                        .foregroundColor(.red)
                    Text("Misses")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                VStack {
                    let accuracy = hits + misses > 0 ? Double(hits) / Double(hits + misses) * 100 : 0
                    Text(String(format: "%.0f%%", accuracy))
                        .font(.system(size: 40, weight: .bold))
                        .foregroundColor(.blue)
                    Text("Accuracy")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color(UIColor.systemBackground).opacity(0.9))
                    .shadow(radius: 10)
            )
            .padding(.bottom, 30)
        }
    }
    
    // MARK: - Methods
    
    private func setupTest() {
        eyeTracking.startTracking(with: sceneView)
        generateTestTargets()
    }
    
    private func generateTestTargets() {
        let screenSize = UIScreen.main.bounds.size
        let margin: CGFloat = 100
        let spacing = (screenSize.width - 2 * margin) / 3
        
        testTargets = []
        var id = 0
        
        // Create a grid of test targets
        for row in 0..<3 {
            for col in 0..<3 {
                let x = margin + CGFloat(col) * spacing
                let y = margin + 100 + CGFloat(row) * spacing
                
                testTargets.append(TestTarget(
                    id: id,
                    position: CGPoint(x: x, y: y)
                ))
                id += 1
            }
        }
        
        testTargets.shuffle()
    }
    
    private func startTest() {
        testInProgress = true
        currentTargetIndex = 0
        hits = 0
        misses = 0
    }
    
    private func handleHit(_ target: TestTarget) {
        guard testInProgress else { return }
        
        hits += 1
        HapticManager.shared.success()
        
        nextTarget()
    }
    
    private func handleMiss() {
        guard testInProgress else { return }
        
        misses += 1
        HapticManager.shared.error()
        
        nextTarget()
    }
    
    private func nextTarget() {
        currentTargetIndex += 1
        
        if currentTargetIndex >= testTargets.count {
            // Test complete
            finishTest()
        }
    }
    
    private func finishTest() {
        testInProgress = false
        
        // Show results for a moment
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            dismiss()
        }
    }
}

// MARK: - Test Target Model

struct TestTarget: Identifiable {
    let id: Int
    let position: CGPoint
    var isHit = false
}

// MARK: - Test Target View

struct TestTargetView: View {
    let target: TestTarget
    let isActive: Bool
    let gazePoint: CGPoint
    let onHit: () -> Void
    let onMiss: () -> Void
    
    @State private var dwellProgress: Double = 0
    @State private var isDwelling = false
    @State private var lastGazeTime = Date()
    
    private let targetSize: CGFloat = 80
    private let dwellThreshold: TimeInterval = 1.0
    
    var body: some View {
        ZStack {
            // Background circle
            Circle()
                .fill(isActive ? Color.blue.opacity(0.3) : Color.gray.opacity(0.1))
                .frame(width: targetSize, height: targetSize)
            
            // Progress ring
            if isDwelling {
                Circle()
                    .trim(from: 0, to: dwellProgress)
                    .stroke(Color.green, lineWidth: 4)
                    .frame(width: targetSize - 10, height: targetSize - 10)
                    .rotationEffect(.degrees(-90))
            }
            
            // Center dot
            Circle()
                .fill(isActive ? Color.blue : Color.gray)
                .frame(width: 20, height: 20)
        }
        .position(target.position)
        .opacity(isActive ? 1.0 : 0.3)
        .onChange(of: gazePoint) { _, newPoint in
            if isActive {
                checkGaze(newPoint)
            }
        }
    }
    
    private func checkGaze(_ point: CGPoint) {
        let distance = sqrt(
            pow(point.x - target.position.x, 2) +
            pow(point.y - target.position.y, 2)
        )
        
        if distance < targetSize / 2 {
            // Gazing at target
            if !isDwelling {
                isDwelling = true
                lastGazeTime = Date()
            }
            
            let elapsed = Date().timeIntervalSince(lastGazeTime)
            dwellProgress = min(1.0, elapsed / dwellThreshold)
            
            if dwellProgress >= 1.0 {
                onHit()
                isDwelling = false
                dwellProgress = 0
            }
        } else {
            // Not gazing
            if isDwelling {
                // Lost gaze before completing dwell
                isDwelling = false
                dwellProgress = 0
            }
        }
    }
}

// MARK: - Array Extension

extension Array {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

// MARK: - Preview

struct EyeTrackingTestView_Previews: PreviewProvider {
    static var previews: some View {
        EyeTrackingTestView()
    }
}
