//
//  EyeTrackingSettingsView.swift
//  OpenVoice
//
//  Settings for eye tracking configuration
//  Phase 4: ARKit Eye Tracking
//

import SwiftUI

struct EyeTrackingSettingsView: View {
    @EnvironmentObject var appSettings: AppSettings
    @StateObject private var eyeTracking = EyeTrackingManager.shared
    
    @State private var showCalibration = false
    @State private var showDebugMode = false
    @State private var showTestView = false
    
    var body: some View {
        List {
            // Status Section
            Section {
                StatusRow(
                    label: "Eye Tracking",
                    status: eyeTracking.isTracking ? "Active" : "Inactive",
                    color: eyeTracking.isTracking ? .green : .gray
                )
                
                StatusRow(
                    label: "Tracking Quality",
                    status: eyeTracking.faceTrackingQuality.rawValue,
                    color: eyeTracking.faceTrackingQuality.color
                )
                
                StatusRow(
                    label: "Calibration",
                    status: eyeTracking.isCalibrated ? "Calibrated" : "Not Calibrated",
                    color: eyeTracking.isCalibrated ? .green : .orange
                )
            } header: {
                Text("Status")
            }
            
            // Calibration Section
            Section {
                Button(action: { showCalibration = true }) {
                    Label("Calibrate Eye Tracking", systemImage: "eye.circle")
                }
                
                if eyeTracking.isCalibrated {
                    Button(action: { eyeTracking.clearCalibration() }) {
                        Label("Clear Calibration", systemImage: "trash")
                            .foregroundColor(.red)
                    }
                }
                
                Button(action: { showTestView = true }) {
                    Label("Test Eye Tracking", systemImage: "eye.fill")
                }
            } header: {
                Text("Calibration")
            } footer: {
                Text("Calibrate for best accuracy. Recalibrate if eye tracking seems inaccurate.")
            }
            
            // Dwell Settings Section
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Dwell Time")
                        Spacer()
                        Text(String(format: "%.1fs", appSettings.eyeTracking.dwellTime))
                            .foregroundColor(.secondary)
                    }
                    
                    Slider(
                        value: $appSettings.eyeTracking.dwellTime,
                        in: 0.3...3.0,
                        step: 0.1
                    )
                }
                
                Picker("Preset", selection: $appSettings.eyeTracking.dwellPreset) {
                    Text("Fast (0.5s)").tag("fast")
                    Text("Normal (1.0s)").tag("normal")
                    Text("Slow (1.5s)").tag("slow")
                    Text("Accessible (2.0s)").tag("accessible")
                }
                .onChange(of: appSettings.eyeTracking.dwellPreset) { _, newValue in
                    applyDwellPreset(newValue)
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Movement Tolerance")
                        Spacer()
                        Text("\(Int(appSettings.eyeTracking.movementTolerance))pt")
                            .foregroundColor(.secondary)
                    }
                    
                    Slider(
                        value: $appSettings.eyeTracking.movementTolerance,
                        in: 10...100,
                        step: 5
                    )
                }
            } header: {
                Text("Dwell Selection")
            } footer: {
                Text("Dwell time controls how long you need to look at a symbol to select it. Movement tolerance affects how precisely you need to focus.")
            }
            
            // Feedback Settings
            Section {
                Toggle("Visual Feedback", isOn: $appSettings.eyeTracking.visualFeedback)
                Toggle("Haptic Feedback", isOn: $appSettings.eyeTracking.hapticFeedback)
                Toggle("Sound Feedback", isOn: $appSettings.eyeTracking.soundFeedback)
            } header: {
                Text("Feedback")
            } footer: {
                Text("Choose how you receive feedback when dwelling on symbols.")
            }
            
            // Advanced Settings
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Gaze Smoothing")
                        Spacer()
                        Text("\(appSettings.eyeTracking.smoothingFrames)")
                            .foregroundColor(.secondary)
                    }
                    
                    Slider(
                        value: Binding(
                            get: { Double(appSettings.eyeTracking.smoothingFrames) },
                            set: { appSettings.eyeTracking.smoothingFrames = Int($0) }
                        ),
                        in: 1...10,
                        step: 1
                    )
                }
                
                Toggle("Show Gaze Cursor", isOn: $appSettings.eyeTracking.showGazeCursor)
                Toggle("Debug Mode", isOn: $showDebugMode)
            } header: {
                Text("Advanced")
            } footer: {
                Text("Gaze smoothing reduces jitter. Higher values = smoother but slightly slower response.")
            }
            
            // Information
            Section {
                NavigationLink("How Eye Tracking Works") {
                    EyeTrackingInfoView()
                }
                
                NavigationLink("Troubleshooting") {
                    EyeTrackingTroubleshootingView()
                }
            } header: {
                Text("Help")
            }
        }
        .navigationTitle("Eye Tracking")
        .sheet(isPresented: $showCalibration) {
            CalibrationView()
        }
        .sheet(isPresented: $showTestView) {
            EyeTrackingTestView()
        }
        .onChange(of: appSettings.eyeTracking.dwellTime) { _, newValue in
            eyeTracking.updateSettings(
                dwellTime: newValue,
                smoothing: appSettings.eyeTracking.smoothingFrames
            )
        }
        .onChange(of: appSettings.eyeTracking.smoothingFrames) { _, newValue in
            eyeTracking.updateSettings(
                dwellTime: appSettings.eyeTracking.dwellTime,
                smoothing: newValue
            )
        }
    }
    
    private func applyDwellPreset(_ preset: String) {
        switch preset {
        case "fast":
            appSettings.eyeTracking.dwellTime = 0.5
        case "normal":
            appSettings.eyeTracking.dwellTime = 1.0
        case "slow":
            appSettings.eyeTracking.dwellTime = 1.5
        case "accessible":
            appSettings.eyeTracking.dwellTime = 2.0
            appSettings.eyeTracking.movementTolerance = 50
        default:
            break
        }
    }
}

// MARK: - Supporting Views

struct StatusRow: View {
    let label: String
    let status: String
    let color: Color
    
    var body: some View {
        HStack {
            Text(label)
            Spacer()
            HStack(spacing: 6) {
                Circle()
                    .fill(color)
                    .frame(width: 8, height: 8)
                Text(status)
                    .foregroundColor(.secondary)
            }
        }
    }
}

struct EyeTrackingInfoView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Section {
                    Text("How It Works")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("OpenVoice uses ARKit face tracking to detect where you're looking on the screen. This allows hands-free communication by simply looking at symbols.")
                        .fixedSize(horizontal: false, vertical: true)
                }
                
                Section {
                    Text("Requirements")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    VStack(alignment: .leading, spacing: 12) {
                        BulletPoint("iPhone X or newer (TrueDepth camera)")
                        BulletPoint("Good lighting conditions")
                        BulletPoint("Face positioned 30-60cm from device")
                        BulletPoint("Eyes visible (no sunglasses)")
                    }
                }
                
                Section {
                    Text("Best Practices")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    VStack(alignment: .leading, spacing: 12) {
                        BulletPoint("Calibrate in the same position you'll use the app")
                        BulletPoint("Keep your head relatively still")
                        BulletPoint("Ensure good, even lighting")
                        BulletPoint("Recalibrate if accuracy decreases")
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Eye Tracking Info")
    }
}

struct EyeTrackingTroubleshootingView: View {
    var body: some View {
        List {
            Section("Poor Tracking Quality") {
                TroubleshootItem(
                    problem: "Red or Orange Status",
                    solution: "Improve lighting, ensure face is visible and centered"
                )
            }
            
            Section("Inaccurate Selection") {
                TroubleshootItem(
                    problem: "Selecting wrong symbols",
                    solution: "Recalibrate eye tracking, adjust dwell time"
                )
            }
            
            Section("Eye Tracking Not Working") {
                TroubleshootItem(
                    problem: "No gaze cursor appears",
                    solution: "Check device compatibility, restart app, grant camera permissions"
                )
            }
            
            Section("Frequent Interruptions") {
                TroubleshootItem(
                    problem: "Tracking keeps stopping",
                    solution: "Keep face visible, avoid tilting head, check lighting"
                )
            }
        }
        .navigationTitle("Troubleshooting")
    }
}

struct BulletPoint: View {
    let text: String
    
    init(_ text: String) {
        self.text = text
    }
    
    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Text("•")
            Text(text)
        }
    }
}

struct TroubleshootItem: View {
    let problem: String
    let solution: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(problem)
                .fontWeight(.semibold)
            Text(solution)
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
    }
}

// MARK: - Preview

struct EyeTrackingSettingsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            EyeTrackingSettingsView()
                .environmentObject(AppSettings())
        }
    }
}
