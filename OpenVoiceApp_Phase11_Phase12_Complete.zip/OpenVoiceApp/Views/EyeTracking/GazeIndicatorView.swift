//
//  GazeIndicatorView.swift
//  OpenVoice
//
//  Visual indicator showing where the user is looking
//  Phase 4: ARKit Eye Tracking
//

import SwiftUI

/// Overlay view showing gaze point and dwell progress
struct GazeIndicatorView: View {
    @ObservedObject var eyeTracking: EyeTrackingManager
    @State private var showDebugInfo = false
    
    var body: some View {
        ZStack {
            // Main gaze indicator
            if eyeTracking.isTracking {
                GazeCursor(
                    isDwelling: eyeTracking.isDwelling,
                    progress: eyeTracking.dwellProgress
                )
                .position(eyeTracking.gazePoint)
                .animation(.easeOut(duration: 0.1), value: eyeTracking.gazePoint)
            }
            
            // Tracking quality indicator (top-right corner)
            VStack {
                HStack {
                    Spacer()
                    TrackingQualityBadge(quality: eyeTracking.faceTrackingQuality)
                        .padding()
                }
                Spacer()
            }
            
            // Debug info (if enabled)
            if showDebugInfo {
                DebugOverlay(eyeTracking: eyeTracking)
            }
        }
        .allowsHitTesting(false)  // Don't block touches
    }
}

/// The actual gaze cursor
struct GazeCursor: View {
    let isDwelling: Bool
    let progress: Double
    
    private let cursorSize: CGFloat = 40
    private let ringSize: CGFloat = 60
    
    var body: some View {
        ZStack {
            // Outer ring (dwell progress)
            if isDwelling {
                Circle()
                    .trim(from: 0, to: progress)
                    .stroke(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .leading,
                            endPoint: .trailing
                        ),
                        style: StrokeStyle(lineWidth: 4, lineCap: .round)
                    )
                    .frame(width: ringSize, height: ringSize)
                    .rotationEffect(.degrees(-90))
                    .animation(.linear(duration: 0.1), value: progress)
            }
            
            // Inner dot
            Circle()
                .fill(isDwelling ? Color.purple : Color.blue.opacity(0.8))
                .frame(width: cursorSize, height: cursorSize)
                .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 2)
            
            // Center dot
            Circle()
                .fill(Color.white)
                .frame(width: 8, height: 8)
        }
        .scaleEffect(isDwelling ? 1.2 : 1.0)
        .animation(.spring(response: 0.3), value: isDwelling)
    }
}

/// Tracking quality badge
struct TrackingQualityBadge: View {
    let quality: TrackingQuality
    @State private var isExpanded = false
    
    var body: some View {
        Button(action: { isExpanded.toggle() }) {
            HStack(spacing: 6) {
                Image(systemName: quality.icon)
                    .foregroundColor(quality.color)
                
                if isExpanded {
                    Text(quality.rawValue)
                        .font(.caption)
                        .foregroundColor(.primary)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                Capsule()
                    .fill(Color(UIColor.systemBackground).opacity(0.9))
                    .shadow(radius: 3)
            )
        }
        .animation(.spring(), value: isExpanded)
    }
}

/// Debug information overlay
struct DebugOverlay: View {
    @ObservedObject var eyeTracking: EyeTrackingManager
    
    var body: some View {
        VStack {
            Spacer()
            
            VStack(alignment: .leading, spacing: 8) {
                DebugRow(label: "Gaze", value: formatPoint(eyeTracking.gazePoint))
                DebugRow(label: "Quality", value: eyeTracking.faceTrackingQuality.rawValue)
                DebugRow(label: "Dwelling", value: eyeTracking.isDwelling ? "Yes" : "No")
                DebugRow(label: "Progress", value: "\(Int(eyeTracking.dwellProgress * 100))%")
                DebugRow(label: "Calibrated", value: eyeTracking.isCalibrated ? "Yes" : "No")
            }
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.black.opacity(0.7))
            )
            .foregroundColor(.white)
            .font(.system(.caption, design: .monospaced))
            .padding()
        }
    }
    
    private func formatPoint(_ point: CGPoint) -> String {
        "(\(Int(point.x)), \(Int(point.y)))"
    }
}

struct DebugRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label + ":")
                .fontWeight(.semibold)
            Spacer()
            Text(value)
        }
    }
}

// MARK: - Preview

struct GazeIndicatorView_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            Color.gray.opacity(0.2)
            
            GazeIndicatorView(eyeTracking: EyeTrackingManager.shared)
        }
    }
}
