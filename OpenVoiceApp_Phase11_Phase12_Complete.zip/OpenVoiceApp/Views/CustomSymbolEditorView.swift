//
//  CustomSymbolEditorView.swift
//  OpenVoice
//
//  Create and edit custom symbols from photos
//

import SwiftUI
import PhotosUI

struct CustomSymbolEditorView: View {
    @Environment(\.dismiss) var dismiss
    @StateObject private var viewModel = CustomSymbolEditorViewModel()
    
    @State private var showImagePicker = false
    @State private var showCamera = false
    @State private var sourceType: UIImagePickerController.SourceType = .photoLibrary
    
    var symbolToEdit: Symbol? = nil
    
    var body: some View {
        NavigationView {
            Form {
                // Image Section
                Section {
                    if let image = viewModel.selectedImage {
                        ZStack(alignment: .topTrailing) {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFit()
                                .frame(maxHeight: 200)
                                .cornerRadius(12)
                            
                            Button(action: {
                                viewModel.selectedImage = nil
                            }) {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .background(Circle().fill(Color.black.opacity(0.6)))
                            }
                            .padding(8)
                        }
                    } else {
                        VStack(spacing: 16) {
                            Image(systemName: "photo.on.rectangle.angled")
                                .font(.system(size: 60))
                                .foregroundColor(.secondary)
                            
                            Text("Add a photo for this symbol")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            
                            HStack(spacing: 16) {
                                Button(action: {
                                    sourceType = .camera
                                    showCamera = true
                                }) {
                                    Label("Camera", systemImage: "camera.fill")
                                }
                                .disabled(!UIImagePickerController.isSourceTypeAvailable(.camera))
                                
                                Button(action: {
                                    sourceType = .photoLibrary
                                    showImagePicker = true
                                }) {
                                    Label("Photos", systemImage: "photo.fill")
                                }
                            }
                            .buttonStyle(.bordered)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 32)
                    }
                } header: {
                    Text("Image")
                }
                
                // Label Section
                Section {
                    TextField("Enter label", text: $viewModel.label)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                    
                    if !viewModel.label.isEmpty {
                        HStack {
                            Text("Preview:")
                            Spacer()
                            Text(viewModel.label)
                                .fontWeight(.medium)
                        }
                    }
                } header: {
                    Text("Label")
                } footer: {
                    Text("This is the word that will be spoken when the symbol is selected")
                }
                
                // Category Section
                Section {
                    Picker("Category", selection: $viewModel.selectedCategory) {
                        ForEach(SymbolCategory.allCases, id: \.self) { category in
                            HStack {
                                Image(systemName: category.icon)
                                Text(category.rawValue)
                            }
                            .tag(category)
                        }
                    }
                } header: {
                    Text("Category")
                }
                
                // Tags Section
                Section {
                    TextField("Add tags (comma separated)", text: $viewModel.tagsText)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                    
                    if !viewModel.tags.isEmpty {
                        FlowLayout(spacing: 8) {
                            ForEach(viewModel.tags, id: \.self) { tag in
                                Text(tag)
                                    .font(.caption)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(
                                        Capsule()
                                            .fill(Color(UIColor.secondarySystemGroupedBackground))
                                    )
                            }
                        }
                    }
                } header: {
                    Text("Tags (Optional)")
                } footer: {
                    Text("Tags help with searching. E.g., 'food, breakfast, cereal'")
                }
                
                // Preview Section
                if viewModel.canSave {
                    Section {
                        HStack {
                            Spacer()
                            VStack(spacing: 12) {
                                Text("Preview")
                                    .font(.headline)
                                    .foregroundColor(.secondary)
                                
                                SymbolButton(
                                    symbol: viewModel.previewSymbol,
                                    size: .medium
                                ) {
                                    // Preview only
                                }
                            }
                            Spacer()
                        }
                    }
                }
            }
            .navigationTitle(symbolToEdit == nil ? "New Symbol" : "Edit Symbol")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        viewModel.save()
                        dismiss()
                    }
                    .disabled(!viewModel.canSave)
                }
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(image: $viewModel.selectedImage, sourceType: sourceType)
            }
            .sheet(isPresented: $showCamera) {
                ImagePicker(image: $viewModel.selectedImage, sourceType: .camera)
            }
            .onAppear {
                if let symbol = symbolToEdit {
                    viewModel.loadSymbol(symbol)
                }
            }
        }
    }
}

// MARK: - Flow Layout (for tags)

struct FlowLayout: Layout {
    var spacing: CGFloat = 8
    
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let result = FlowLayoutResult(
            in: proposal.replacingUnspecifiedDimensions().width,
            subviews: subviews,
            spacing: spacing
        )
        return result.size
    }
    
    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let result = FlowLayoutResult(
            in: bounds.width,
            subviews: subviews,
            spacing: spacing
        )
        for (index, subview) in subviews.enumerated() {
            subview.place(at: CGPoint(x: bounds.minX + result.positions[index].x,
                                     y: bounds.minY + result.positions[index].y),
                         proposal: .unspecified)
        }
    }
    
    struct FlowLayoutResult {
        var size: CGSize
        var positions: [CGPoint]
        
        init(in maxWidth: CGFloat, subviews: Subviews, spacing: CGFloat) {
            var currentX: CGFloat = 0
            var currentY: CGFloat = 0
            var lineHeight: CGFloat = 0
            var positions: [CGPoint] = []
            
            for subview in subviews {
                let size = subview.sizeThatFits(.unspecified)
                
                if currentX + size.width > maxWidth && currentX > 0 {
                    currentX = 0
                    currentY += lineHeight + spacing
                    lineHeight = 0
                }
                
                positions.append(CGPoint(x: currentX, y: currentY))
                lineHeight = max(lineHeight, size.height)
                currentX += size.width + spacing
            }
            
            self.positions = positions
            self.size = CGSize(width: maxWidth, height: currentY + lineHeight)
        }
    }
}

// MARK: - Image Picker

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.dismiss) var dismiss
    
    var sourceType: UIImagePickerController.SourceType = .photoLibrary
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.delegate = context.coordinator
        picker.allowsEditing = true
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: ImagePicker
        
        init(_ parent: ImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let editedImage = info[.editedImage] as? UIImage {
                parent.image = editedImage
            } else if let originalImage = info[.originalImage] as? UIImage {
                parent.image = originalImage
            }
            
            parent.dismiss()
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.dismiss()
        }
    }
}

// MARK: - Preview

struct CustomSymbolEditorView_Previews: PreviewProvider {
    static var previews: some View {
        CustomSymbolEditorView()
    }
}
