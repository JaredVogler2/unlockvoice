//
//  SymbolGridView.swift
//  OpenVoice
//
//  Main symbol grid for communication
//

import SwiftUI

struct SymbolGridView: View {
    @StateObject private var viewModel = SymbolGridViewModel()
    @EnvironmentObject var appState: AppState
    @State private var showSymbolBrowser = false
    @State private var showQuickCategories = true
    
    var body: some View {
        ZStack {
            // Background
            Color(UIColor.systemGroupedBackground)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Quick Category Filter (Phase 2)
                if showQuickCategories {
                    QuickCategoryBar(selectedCategory: $viewModel.selectedCategory)
                        .padding(.vertical, 8)
                }
                
                // Symbol Grid
                ScrollView {
                    LazyVGrid(columns: gridColumns, spacing: 16) {
                        // Browse button
                        BrowseLibraryButton {
                            showSymbolBrowser = true
                        }
                        
                        // Symbols
                        ForEach(viewModel.visibleSymbols) { symbol in
                            SymbolButton(
                                symbol: symbol,
                                size: appState.settings.symbolSize
                            ) {
                                viewModel.selectSymbol(symbol)
                            }
                        }
                    }
                    .padding()
                }
            }
            
            // Gaze indicator overlay (Phase 4)
            if appState.settings.eyeTrackingEnabled && appState.settings.gazeIndicatorEnabled {
                GazeIndicatorView()
            }
        }
        .sheet(isPresented: $showSymbolBrowser) {
            SymbolBrowserView { symbol in
                viewModel.selectSymbol(symbol)
            }
            .environmentObject(appState)
        }
        .onAppear {
            viewModel.loadSymbols()
        }
    }
    
    private var gridColumns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 16),
              count: appState.settings.gridColumns)
    }
}

// MARK: - Quick Category Bar

struct QuickCategoryBar: View {
    @Binding var selectedCategory: SymbolCategory?
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                // All
                CategoryButton(
                    icon: "square.grid.2x2",
                    label: "All",
                    color: .blue,
                    isSelected: selectedCategory == nil
                ) {
                    selectedCategory = nil
                }
                
                // Favorites
                CategoryButton(
                    icon: "star.fill",
                    label: "Favorites",
                    color: .yellow,
                    isSelected: false
                ) {
                    // Will be implemented with favorites filter
                }
                
                // Common categories
                ForEach([SymbolCategory.actions, .feelings, .food, .people], id: \.self) { category in
                    CategoryButton(
                        icon: category.icon,
                        label: category.rawValue,
                        color: category.color,
                        isSelected: selectedCategory == category
                    ) {
                        selectedCategory = category
                    }
                }
            }
            .padding(.horizontal)
        }
        .background(Color(UIColor.secondarySystemGroupedBackground))
    }
}

struct CategoryButton: View {
    let icon: String
    let label: String
    let color: Color
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 18))
                    .foregroundColor(isSelected ? color : .secondary)
                
                Text(label)
                    .font(.caption2)
                    .foregroundColor(isSelected ? .primary : .secondary)
            }
            .frame(width: 60, height: 60)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(isSelected ? color.opacity(0.15) : Color.clear)
            )
        }
    }
}

// MARK: - Browse Library Button

struct BrowseLibraryButton: View {
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.blue.opacity(0.1))
                    
                    VStack(spacing: 8) {
                        Image(systemName: "rectangle.grid.3x2.fill")
                            .font(.title)
                            .foregroundColor(.blue)
                        
                        Text("Browse")
                            .font(.caption)
                            .fontWeight(.medium)
                    }
                }
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .strokeBorder(Color.blue.opacity(0.5), lineWidth: 2)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.blue.opacity(0.05))
                        )
                )
                
                Text("Library")
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.blue)
            }
        }
        .buttonStyle(ScaleButtonStyle())
    }
}

// MARK: - Symbol Button

struct SymbolButton: View {
    let symbol: Symbol
    let size: SymbolSize
    let action: () -> Void
    
    @State private var isPressed = false
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                // Symbol image
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color(UIColor.secondarySystemGroupedBackground))
                    
                    if let customImageData = symbol.customImageData,
                       let uiImage = UIImage(data: customImageData) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFit()
                            .padding(8)
                    } else {
                        Image(systemName: symbol.imageName)
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(symbol.category.color)
                            .padding(16)
                    }
                }
                .frame(width: size.dimension, height: size.dimension)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .strokeBorder(symbol.category.color.opacity(0.3), lineWidth: 2)
                )
                
                // Label
                Text(symbol.label)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
        }
        .buttonStyle(ScaleButtonStyle())
        .accessibilityLabel(symbol.label)
        .accessibilityHint("Tap to add to phrase")
    }
}

// MARK: - Button Style

struct ScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .animation(.easeInOut(duration: 0.1), value: configuration.isPressed)
    }
}

// MARK: - Gaze Indicator (Placeholder for Phase 4)

struct GazeIndicatorView: View {
    @State private var gazePosition: CGPoint = .zero
    
    var body: some View {
        Circle()
            .fill(Color.blue.opacity(0.3))
            .frame(width: 30, height: 30)
            .position(gazePosition)
            .allowsHitTesting(false)
        // Phase 4: Will be connected to ARKit eye tracking
    }
}

// MARK: - Preview

struct SymbolGridView_Previews: PreviewProvider {
    static var previews: some View {
        SymbolGridView()
            .environmentObject(AppState())
    }
}
