//
//  SymbolBrowserView.swift
//  OpenVoice
//
//  Browse and search the complete symbol library
//

import SwiftUI

struct SymbolBrowserView: View {
    @StateObject private var viewModel = SymbolBrowserViewModel()
    @ObservedObject private var library = SymbolLibraryService.shared
    @Environment(\.dismiss) var dismiss
    
    var onSymbolSelected: ((Symbol) -> Void)?
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Search Bar
                SearchBar(text: $viewModel.searchQuery)
                    .padding()
                
                // Category Filter
                if viewModel.searchQuery.isEmpty {
                    CategoryScrollView(selectedCategory: $viewModel.selectedCategory)
                        .padding(.bottom, 8)
                }
                
                // Results
                if library.isLoading {
                    LoadingView()
                } else {
                    SymbolResultsView(
                        symbols: viewModel.filteredSymbols,
                        onSymbolTapped: handleSymbolSelection
                    )
                }
            }
            .navigationTitle("Symbol Library")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Close") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: CustomSymbolEditorView()) {
                        Image(systemName: "plus.circle.fill")
                    }
                }
            }
        }
        .onAppear {
            viewModel.updateFilteredSymbols()
        }
    }
    
    private func handleSymbolSelection(_ symbol: Symbol) {
        onSymbolSelected?(symbol)
        SymbolLibraryService.shared.markAsUsed(symbol)
        HapticManager.shared.impact(.medium)
        dismiss()
    }
}

// MARK: - Search Bar

struct SearchBar: View {
    @Binding var text: String
    @State private var isEditing = false
    
    var body: some View {
        HStack {
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)
                
                TextField("Search symbols...", text: $text)
                    .textFieldStyle(PlainTextFieldStyle())
                    .onTapGesture {
                        isEditing = true
                    }
                
                if !text.isEmpty {
                    Button(action: { text = "" }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .padding(8)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(10)
            
            if isEditing {
                Button("Cancel") {
                    text = ""
                    isEditing = false
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                }
                .transition(.move(edge: .trailing))
            }
        }
        .animation(.default, value: isEditing)
    }
}

// MARK: - Category Scroll View

struct CategoryScrollView: View {
    @Binding var selectedCategory: SymbolCategory?
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                // All category
                CategoryChip(
                    category: nil,
                    isSelected: selectedCategory == nil
                ) {
                    selectedCategory = nil
                }
                
                // Individual categories
                ForEach(SymbolCategory.allCases, id: \.self) { category in
                    CategoryChip(
                        category: category,
                        isSelected: selectedCategory == category
                    ) {
                        selectedCategory = category
                    }
                }
            }
            .padding(.horizontal)
        }
    }
}

struct CategoryChip: View {
    let category: SymbolCategory?
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: category?.icon ?? "square.grid.2x2")
                    .font(.system(size: 14))
                
                Text(category?.rawValue ?? "All")
                    .font(.subheadline)
                    .fontWeight(.medium)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(isSelected ? (category?.color ?? .blue) : Color(UIColor.secondarySystemGroupedBackground))
            )
            .foregroundColor(isSelected ? .white : .primary)
        }
    }
}

// MARK: - Symbol Results View

struct SymbolResultsView: View {
    let symbols: [Symbol]
    let onSymbolTapped: (Symbol) -> Void
    
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        if symbols.isEmpty {
            EmptyStateView()
        } else {
            ScrollView {
                LazyVGrid(columns: gridColumns, spacing: 16) {
                    ForEach(symbols) { symbol in
                        SymbolBrowserButton(
                            symbol: symbol,
                            size: appState.settings.symbolSize
                        ) {
                            onSymbolTapped(symbol)
                        }
                    }
                }
                .padding()
            }
        }
    }
    
    private var gridColumns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 16), count: 3)
    }
}

// MARK: - Symbol Browser Button

struct SymbolBrowserButton: View {
    let symbol: Symbol
    let size: SymbolSize
    let action: () -> Void
    
    @ObservedObject private var library = SymbolLibraryService.shared
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                // Symbol image
                ZStack(alignment: .topTrailing) {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color(UIColor.secondarySystemGroupedBackground))
                        .overlay(
                            Group {
                                if let customImageData = symbol.customImageData,
                                   let uiImage = UIImage(data: customImageData) {
                                    Image(uiImage: uiImage)
                                        .resizable()
                                        .scaledToFit()
                                        .padding(8)
                                } else {
                                    Image(systemName: symbol.imageName)
                                        .resizable()
                                        .scaledToFit()
                                        .foregroundColor(symbol.category.color)
                                        .padding(16)
                                }
                            }
                        )
                    
                    // Favorite indicator
                    if library.isFavorite(symbol) {
                        Image(systemName: "star.fill")
                            .font(.system(size: 12))
                            .foregroundColor(.yellow)
                            .padding(4)
                    }
                }
                .frame(height: size.dimension)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .strokeBorder(symbol.category.color.opacity(0.3), lineWidth: 2)
                )
                
                // Label
                Text(symbol.label)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                    .multilineTextAlignment(.center)
            }
        }
        .buttonStyle(ScaleButtonStyle())
        .contextMenu {
            Button(action: { library.toggleFavorite(symbol) }) {
                Label(
                    library.isFavorite(symbol) ? "Remove from Favorites" : "Add to Favorites",
                    systemImage: library.isFavorite(symbol) ? "star.slash" : "star"
                )
            }
        }
    }
}

// MARK: - Empty State

struct EmptyStateView: View {
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 60))
                .foregroundColor(.secondary)
            
            Text("No symbols found")
                .font(.title3)
                .fontWeight(.medium)
            
            Text("Try adjusting your search or category filter")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .padding()
    }
}

// MARK: - Loading View

struct LoadingView: View {
    var body: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.5)
            
            Text("Loading symbols...")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
    }
}

// MARK: - Preview

struct SymbolBrowserView_Previews: PreviewProvider {
    static var previews: some View {
        SymbolBrowserView()
            .environmentObject(AppState())
    }
}
