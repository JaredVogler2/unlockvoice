//
//  PhraseBarView.swift
//  OpenVoice
//
//  Displays the current phrase being built and provides controls
//

import SwiftUI

struct PhraseBarView: View {
    @ObservedObject private var phraseManager = PhraseManager.shared
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        VStack(spacing: 0) {
            // Phrase display area
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    if phraseManager.currentPhrase.isEmpty {
                        Text("Tap symbols to build a phrase")
                            .foregroundColor(.secondary)
                            .italic()
                            .padding()
                    } else {
                        ForEach(Array(phraseManager.currentPhrase.symbols.enumerated()), id: \.element.id) { index, symbol in
                            SymbolChip(symbol: symbol) {
                                // Remove symbol on tap
                                removeSymbol(at: index)
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 12)
            }
            .frame(height: 80)
            .background(Color(UIColor.systemBackground))
            
            Divider()
            
            // Control buttons
            HStack(spacing: 16) {
                // Clear button
                Button(action: {
                    phraseManager.clearPhrase()
                    HapticManager.shared.impact(.light)
                }) {
                    Label("Clear", systemImage: "xmark.circle.fill")
                        .font(.subheadline)
                        .foregroundColor(.red)
                }
                .disabled(phraseManager.currentPhrase.isEmpty)
                
                Spacer()
                
                // Backspace button
                Button(action: {
                    phraseManager.removeLastSymbol()
                    HapticManager.shared.impact(.light)
                }) {
                    Label("Delete", systemImage: "delete.left.fill")
                        .font(.subheadline)
                }
                .disabled(phraseManager.currentPhrase.isEmpty)
                
                Spacer()
                
                // Speak button
                Button(action: {
                    phraseManager.speakPhrase()
                    HapticManager.shared.impact(.medium)
                }) {
                    Label("Speak", systemImage: "speaker.wave.3.fill")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(phraseManager.currentPhrase.isEmpty ? Color.gray : Color.blue)
                        .cornerRadius(12)
                }
                .disabled(phraseManager.currentPhrase.isEmpty)
            }
            .padding()
            .background(Color(UIColor.secondarySystemGroupedBackground))
        }
        .accessibilityElement(children: .contain)
    }
    
    private func removeSymbol(at index: Int) {
        // For now, removing arbitrary symbols is complex
        // In Phase 2, we'll add this capability
        phraseManager.removeLastSymbol()
    }
}

// MARK: - Symbol Chip

struct SymbolChip: View {
    let symbol: Symbol
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 6) {
                Image(systemName: symbol.imageName)
                    .font(.system(size: 16))
                    .foregroundColor(symbol.category.color)
                
                Text(symbol.label)
                    .font(.subheadline)
                    .fontWeight(.medium)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(UIColor.tertiarySystemGroupedBackground))
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .strokeBorder(symbol.category.color.opacity(0.3), lineWidth: 1)
                    )
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Preview

struct PhraseBarView_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            PhraseBarView()
                .environmentObject(AppState())
            Spacer()
        }
    }
}
