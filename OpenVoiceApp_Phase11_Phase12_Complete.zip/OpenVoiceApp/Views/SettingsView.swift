//
//  SettingsView.swift
//  OpenVoice
//
//  App settings and configuration
//

import SwiftUI
import AVFoundation

struct SettingsView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            Form {
                // Display Settings
                Section("Display") {
                    Picker("Symbol Size", selection: $appState.settings.symbolSize) {
                        ForEach(SymbolSize.allCases, id: \.self) { size in
                            Text(size.rawValue).tag(size)
                        }
                    }
                    
                    Stepper("Grid Columns: \(appState.settings.gridColumns)",
                           value: $appState.settings.gridColumns,
                           in: 2...6)
                    
                    Toggle("High Contrast", isOn: $appState.settings.highContrast)
                    
                    Toggle("Reduce Motion", isOn: $appState.settings.reduceMotion)
                }
                
                // Eye Tracking Settings
                Section("Eye Tracking") {
                    Toggle("Enable Eye Tracking", isOn: $appState.settings.eyeTrackingEnabled)
                    
                    if appState.settings.eyeTrackingEnabled {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Dwell Time: \(String(format: "%.1f", appState.settings.dwellTime))s")
                                .font(.subheadline)
                            
                            Slider(value: $appState.settings.dwellTime, in: 0.3...2.0, step: 0.1)
                        }
                        
                        Toggle("Show Gaze Indicator", isOn: $appState.settings.gazeIndicatorEnabled)
                        
                        NavigationLink("Calibration") {
                            CalibrationInfoView()
                        }
                    }
                }
                
                // Speech Settings
                Section("Speech") {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Speech Rate: \(Int(appState.settings.speechRate * 100))%")
                            .font(.subheadline)
                        
                        Slider(value: $appState.settings.speechRate, in: 0.2...1.0)
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Pitch: \(Int(appState.settings.speechPitch * 100))%")
                            .font(.subheadline)
                        
                        Slider(value: $appState.settings.speechPitch, in: 0.5...2.0)
                    }
                    
                    NavigationLink("Voice Selection") {
                        VoiceSelectionView()
                    }
                    
                    Button("Test Speech") {
                        SpeechService.shared.speak("Hello, this is OpenVoice.")
                    }
                }
                
                // Phase 3: Speech Enhancement
                Section("Speech Enhancement") {
                    NavigationLink {
                        PhraseTemplatesView()
                    } label: {
                        Label("Quick Phrases", systemImage: "text.bubble.fill")
                    }
                    
                    NavigationLink {
                        PronunciationDictionaryView()
                    } label: {
                        Label("Pronunciation Dictionary", systemImage: "text.word.spacing")
                    }
                    
                    NavigationLink {
                        SpeechHistoryView()
                    } label: {
                        Label("Speech History", systemImage: "clock.arrow.circlepath")
                    }
                }
                
                // Predictions
                Section("Predictions") {
                    Toggle("Show Predictions", isOn: $appState.settings.showPredictions)
                }
                
                // Accessibility
                Section("Accessibility") {
                    Toggle("Haptic Feedback", isOn: $appState.settings.hapticFeedback)
                }
                
                // About
                Section("About") {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.3.0 (Phase 3)")
                            .foregroundColor(.secondary)
                    }
                    
                    Link("Open Source License (GPL v3.0)", destination: URL(string: "https://www.gnu.org/licenses/gpl-3.0.html")!)
                    
                    Link("Privacy Policy", destination: URL(string: "https://openvoice.app/privacy")!)
                    
                    Link("Support & Feedback", destination: URL(string: "https://github.com/openvoice/feedback")!)
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        appState.saveSettings()
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Voice Selection View

struct VoiceSelectionView: View {
    @EnvironmentObject var appState: AppState
    @State private var voices: [AVSpeechSynthesisVoice] = []
    
    var body: some View {
        List(voices, id: \.identifier) { voice in
            Button(action: {
                appState.settings.selectedVoice = voice.identifier
                voice.preview()
            }) {
                HStack {
                    VStack(alignment: .leading) {
                        Text(voice.name)
                            .font(.headline)
                        Text(voice.language)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    if voice.identifier == appState.settings.selectedVoice {
                        Image(systemName: "checkmark")
                            .foregroundColor(.blue)
                    }
                }
            }
        }
        .navigationTitle("Select Voice")
        .onAppear {
            voices = SpeechService.shared.getAvailableVoices()
        }
    }
}

// MARK: - Calibration Info View

struct CalibrationInfoView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "eye.fill")
                .font(.system(size: 60))
                .foregroundColor(.blue)
            
            Text("Eye Tracking Calibration")
                .font(.title2)
                .fontWeight(.bold)
            
            VStack(alignment: .leading, spacing: 12) {
                InfoRow(icon: "1.circle.fill", text: "Look at each point when it appears")
                InfoRow(icon: "2.circle.fill", text: "Keep your head still during calibration")
                InfoRow(icon: "3.circle.fill", text: "Ensure good lighting conditions")
                InfoRow(icon: "4.circle.fill", text: "Calibration takes about 2 minutes")
            }
            .padding()
            
            if appState.isCalibrated {
                Text("✓ Eye tracking is calibrated")
                    .foregroundColor(.green)
                    .fontWeight(.medium)
                
                Text("Last calibrated: \(formattedCalibrationDate)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else {
                Text("⚠️ Eye tracking is not calibrated")
                    .foregroundColor(.orange)
                    .fontWeight(.medium)
            }
            
            Spacer()
            
            // Calibration button will be functional in Phase 4
            Button(action: {
                // Phase 4: Launch calibration
            }) {
                Text(appState.isCalibrated ? "Recalibrate" : "Start Calibration")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(12)
            }
            .padding()
            .disabled(true) // Will be enabled in Phase 4
            .opacity(0.5)
        }
        .padding()
        .navigationTitle("Calibration")
    }
    
    private var formattedCalibrationDate: String {
        guard let data = CalibrationManager.shared.calibrationData else {
            return "Never"
        }
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: data.calibrationDate)
    }
}

struct InfoRow: View {
    let icon: String
    let text: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(.blue)
                .frame(width: 24)
            Text(text)
                .font(.subheadline)
            Spacer()
        }
    }
}

// MARK: - Preview

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
            .environmentObject(AppState())
    }
}
