//
//  PhraseTemplatesView.swift
//  OpenVoice
//
//  Quick access to common phrase templates
//  Phase 3: Speech Enhancement
//

import SwiftUI

struct PhraseTemplatesView: View {
    @Environment(\.dismiss) var dismiss
    @State private var templates: [PhraseTemplate] = []
    @State private var showAddTemplate = false
    @State private var selectedCategory: TemplateCategory = .greetings
    
    var onTemplateSelected: ((PhraseTemplate) -> Void)?
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Category picker
                Picker("Category", selection: $selectedCategory) {
                    ForEach(TemplateCategory.allCases, id: \.self) { category in
                        Text(category.rawValue).tag(category)
                    }
                }
                .pickerStyle(.segmented)
                .padding()
                
                // Templates grid
                ScrollView {
                    LazyVGrid(columns: [
                        GridItem(.flexible()),
                        GridItem(.flexible())
                    ], spacing: 16) {
                        ForEach(filteredTemplates) { template in
                            TemplateCard(template: template) {
                                selectTemplate(template)
                            }
                        }
                    }
                    .padding()
                }
            }
            .navigationTitle("Quick Phrases")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Close") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showAddTemplate = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                }
            }
            .sheet(isPresented: $showAddTemplate) {
                AddTemplateView { newTemplate in
                    templates.append(newTemplate)
                    saveTemplates()
                }
            }
            .onAppear {
                loadTemplates()
            }
        }
    }
    
    private var filteredTemplates: [PhraseTemplate] {
        templates.filter { $0.category == selectedCategory }
    }
    
    private func selectTemplate(_ template: PhraseTemplate) {
        onTemplateSelected?(template)
        
        // Also speak it
        SpeechService.shared.speak(template.text)
        HapticManager.shared.impact(.medium)
        
        dismiss()
    }
    
    private func loadTemplates() {
        if let data = UserDefaults.standard.data(forKey: "PhraseTemplates"),
           let savedTemplates = try? JSONDecoder().decode([PhraseTemplate].self, from: data) {
            templates = savedTemplates
        } else {
            templates = PhraseTemplate.defaultTemplates
            saveTemplates()
        }
    }
    
    private func saveTemplates() {
        if let data = try? JSONEncoder().encode(templates) {
            UserDefaults.standard.set(data, forKey: "PhraseTemplates")
        }
    }
}

// MARK: - Template Card

struct TemplateCard: View {
    let template: PhraseTemplate
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: template.icon)
                        .font(.title2)
                        .foregroundColor(template.category.color)
                    
                    Spacer()
                }
                
                Text(template.text)
                    .font(.body)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Spacer()
            }
            .padding()
            .frame(height: 120)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(template.category.color.opacity(0.1))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .strokeBorder(template.category.color.opacity(0.3), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Add Template View

struct AddTemplateView: View {
    @Environment(\.dismiss) var dismiss
    @State private var text = ""
    @State private var category: TemplateCategory = .custom
    @State private var icon = "star.fill"
    
    var onSave: (PhraseTemplate) -> Void
    
    private let availableIcons = [
        "star.fill", "heart.fill", "hand.wave.fill", "face.smiling.fill",
        "exclamationmark.circle.fill", "questionmark.circle.fill",
        "house.fill", "person.fill", "fork.knife", "bed.double.fill"
    ]
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    TextEditor(text: $text)
                        .frame(height: 100)
                } header: {
                    Text("Phrase Text")
                } footer: {
                    Text("Enter the phrase you want to save as a quick template")
                }
                
                Section {
                    Picker("Category", selection: $category) {
                        ForEach(TemplateCategory.allCases, id: \.self) { cat in
                            Text(cat.rawValue).tag(cat)
                        }
                    }
                } header: {
                    Text("Category")
                }
                
                Section {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 16) {
                            ForEach(availableIcons, id: \.self) { iconName in
                                Button {
                                    icon = iconName
                                } label: {
                                    Image(systemName: iconName)
                                        .font(.title2)
                                        .foregroundColor(icon == iconName ? .blue : .gray)
                                        .frame(width: 50, height: 50)
                                        .background(
                                            RoundedRectangle(cornerRadius: 8)
                                                .fill(icon == iconName ? Color.blue.opacity(0.1) : Color.clear)
                                        )
                                }
                            }
                        }
                    }
                } header: {
                    Text("Icon")
                }
                
                if !text.isEmpty {
                    Section {
                        Button("Test Phrase") {
                            SpeechService.shared.speak(text)
                        }
                    }
                }
            }
            .navigationTitle("New Template")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveTemplate()
                    }
                    .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
    
    private func saveTemplate() {
        let template = PhraseTemplate(
            text: text.trimmingCharacters(in: .whitespacesAndNewlines),
            category: category,
            icon: icon
        )
        
        onSave(template)
        dismiss()
    }
}

// MARK: - Models

struct PhraseTemplate: Identifiable, Codable {
    let id: UUID
    var text: String
    var category: TemplateCategory
    var icon: String
    var usageCount: Int
    
    init(id: UUID = UUID(), text: String, category: TemplateCategory, icon: String, usageCount: Int = 0) {
        self.id = id
        self.text = text
        self.category = category
        self.icon = icon
        self.usageCount = usageCount
    }
    
    // Default templates
    static let defaultTemplates: [PhraseTemplate] = [
        // Greetings
        PhraseTemplate(text: "Hello!", category: .greetings, icon: "hand.wave.fill"),
        PhraseTemplate(text: "Good morning", category: .greetings, icon: "sun.max.fill"),
        PhraseTemplate(text: "How are you?", category: .greetings, icon: "face.smiling.fill"),
        PhraseTemplate(text: "Nice to see you", category: .greetings, icon: "person.2.fill"),
        
        // Requests
        PhraseTemplate(text: "Can you help me?", category: .requests, icon: "hand.raised.fill"),
        PhraseTemplate(text: "I need assistance", category: .requests, icon: "exclamationmark.circle.fill"),
        PhraseTemplate(text: "Please wait", category: .requests, icon: "hand.raised.slash.fill"),
        PhraseTemplate(text: "Can I have that?", category: .requests, icon: "hand.point.up.left.fill"),
        
        // Responses
        PhraseTemplate(text: "Yes, please", category: .responses, icon: "checkmark.circle.fill"),
        PhraseTemplate(text: "No, thank you", category: .responses, icon: "xmark.circle.fill"),
        PhraseTemplate(text: "I don't know", category: .responses, icon: "questionmark.circle.fill"),
        PhraseTemplate(text: "Maybe later", category: .responses, icon: "clock.fill"),
        
        // Feelings
        PhraseTemplate(text: "I feel happy", category: .feelings, icon: "face.smiling.fill"),
        PhraseTemplate(text: "I'm tired", category: .feelings, icon: "zzz"),
        PhraseTemplate(text: "I don't feel well", category: .feelings, icon: "bandage.fill"),
        PhraseTemplate(text: "I'm hungry", category: .feelings, icon: "fork.knife"),
        
        // Social
        PhraseTemplate(text: "Thank you very much", category: .social, icon: "heart.fill"),
        PhraseTemplate(text: "I'm sorry", category: .social, icon: "exclamationmark.bubble.fill"),
        PhraseTemplate(text: "Excuse me", category: .social, icon: "hand.wave"),
        PhraseTemplate(text: "Goodbye, see you later", category: .social, icon: "hand.wave"),
        
        // Emergency
        PhraseTemplate(text: "I need help now!", category: .emergency, icon: "exclamationmark.triangle.fill"),
        PhraseTemplate(text: "Please call someone", category: .emergency, icon: "phone.fill"),
        PhraseTemplate(text: "Something is wrong", category: .emergency, icon: "exclamationmark.circle.fill"),
        PhraseTemplate(text: "I need the bathroom", category: .emergency, icon: "toilet.fill"),
    ]
}

enum TemplateCategory: String, Codable, CaseIterable {
    case greetings = "Greetings"
    case requests = "Requests"
    case responses = "Responses"
    case feelings = "Feelings"
    case social = "Social"
    case emergency = "Emergency"
    case custom = "Custom"
    
    var color: Color {
        switch self {
        case .greetings: return .blue
        case .requests: return .orange
        case .responses: return .green
        case .feelings: return .purple
        case .social: return .pink
        case .emergency: return .red
        case .custom: return .gray
        }
    }
}

// MARK: - Preview

struct PhraseTemplatesView_Previews: PreviewProvider {
    static var previews: some View {
        PhraseTemplatesView()
    }
}
