//
//  AnalyticsDashboardView.swift
//  OpenVoiceApp
//
//  Phase 5: Data Persistence
//  Analytics and usage insights dashboard
//

import SwiftUI

struct AnalyticsDashboardView: View {
    @StateObject private var analytics = AnalyticsService.shared
    @State private var stats: UsageStatistics?
    @State private var trends: UsageTrends?
    @State private var categoryBreakdown: [(category: String, count: Int, percentage: Double)] = []
    @State private var selectedTimeRange: TimeRange = .week
    
    enum TimeRange: String, CaseIterable {
        case day = "Today"
        case week = "Week"
        case month = "Month"
        case all = "All Time"
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Header
                headerSection
                
                // Quick Stats
                quickStatsSection
                
                // Time Range Selector
                timeRangeSelector
                
                // Usage Trends
                if let trends = trends {
                    trendsSection(trends)
                }
                
                // Most Used Symbols
                mostUsedSection
                
                // Category Breakdown
                categorySection
                
                // Storage Info
                storageSection
            }
            .padding()
        }
        .navigationTitle("Usage Analytics")
        .navigationBarTitleDisplayMode(.large)
        .onAppear {
            loadAnalytics()
        }
    }
    
    // MARK: - Header Section
    
    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Your Communication Insights")
                .font(.title2)
                .fontWeight(.bold)
            
            Text("All data stays on your device")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    // MARK: - Quick Stats
    
    private var quickStatsSection: some View {
        Group {
            if let stats = stats {
                LazyVGrid(columns: [
                    GridItem(.flexible()),
                    GridItem(.flexible())
                ], spacing: 15) {
                    StatCard(
                        title: "Total Phrases",
                        value: "\(stats.totalPhrases)",
                        icon: "bubble.left.and.bubble.right",
                        color: .blue
                    )
                    
                    StatCard(
                        title: "Total Sessions",
                        value: "\(stats.totalSessions)",
                        icon: "clock",
                        color: .green
                    )
                    
                    StatCard(
                        title: "Unique Symbols",
                        value: "\(stats.uniqueSymbolsUsed)",
                        icon: "square.grid.3x3",
                        color: .orange
                    )
                    
                    StatCard(
                        title: "Time Spent",
                        value: stats.formattedTotalTime,
                        icon: "timer",
                        color: .purple
                    )
                }
            }
        }
    }
    
    // MARK: - Time Range Selector
    
    private var timeRangeSelector: some View {
        Picker("Time Range", selection: $selectedTimeRange) {
            ForEach(TimeRange.allCases, id: \.self) { range in
                Text(range.rawValue).tag(range)
            }
        }
        .pickerStyle(.segmented)
        .onChange(of: selectedTimeRange) { _ in
            loadTrends()
        }
    }
    
    // MARK: - Trends Section
    
    private func trendsSection(_ trends: UsageTrends) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Usage Trends")
                    .font(.headline)
                
                Spacer()
                
                TrendBadge(direction: trends.trendDirection)
            }
            
            // Simple bar chart
            if !trends.dailyPhrases.isEmpty {
                HStack(alignment: .bottom, spacing: 4) {
                    ForEach(Array(trends.dailyPhrases.enumerated()), id: \.offset) { index, count in
                        BarView(value: count, maxValue: trends.dailyPhrases.max() ?? 1)
                            .frame(maxWidth: .infinity)
                    }
                }
                .frame(height: 120)
            }
            
            Text("\(trends.dailyPhrases.reduce(0, +)) phrases in the last \(trends.dailyPhrases.count) days")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
    
    // MARK: - Most Used Section
    
    private var mostUsedSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Most Used Symbols")
                .font(.headline)
            
            if analytics.mostUsedSymbols.isEmpty {
                Text("No usage data yet")
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                ForEach(Array(analytics.mostUsedSymbols.prefix(10)), id: \.id) { usage in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(usage.label ?? "Unknown")
                                .font(.subheadline)
                                .fontWeight(.medium)
                            
                            if let category = usage.category {
                                Text(category)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        
                        Spacer()
                        
                        VStack(alignment: .trailing) {
                            Text("\(usage.usageCount)")
                                .font(.title3)
                                .fontWeight(.bold)
                            
                            Text("times")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding(.vertical, 8)
                    
                    if usage.id != analytics.mostUsedSymbols.prefix(10).last?.id {
                        Divider()
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
    
    // MARK: - Category Section
    
    private var categorySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Usage by Category")
                .font(.headline)
            
            if categoryBreakdown.isEmpty {
                Text("No category data yet")
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                ForEach(categoryBreakdown, id: \.category) { item in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(item.category)
                                .font(.subheadline)
                            
                            Spacer()
                            
                            Text(String(format: "%.1f%%", item.percentage))
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        
                        GeometryReader { geometry in
                            ZStack(alignment: .leading) {
                                Rectangle()
                                    .fill(Color(.systemGray5))
                                    .frame(height: 8)
                                    .cornerRadius(4)
                                
                                Rectangle()
                                    .fill(Color.blue)
                                    .frame(width: geometry.size.width * CGFloat(item.percentage / 100), height: 8)
                                    .cornerRadius(4)
                            }
                        }
                        .frame(height: 8)
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
    
    // MARK: - Storage Section
    
    private var storageSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Storage")
                .font(.headline)
            
            if let stats = stats {
                VStack(spacing: 12) {
                    StorageRow(
                        label: "Custom Symbols",
                        value: "\(stats.customSymbolsCreated) symbols",
                        detail: stats.formattedStorage
                    )
                    
                    StorageRow(
                        label: "Conversations",
                        value: "\(stats.totalPhrases) phrases",
                        detail: "Saved"
                    )
                    
                    StorageRow(
                        label: "Sessions",
                        value: "\(stats.totalSessions) sessions",
                        detail: stats.formattedTotalTime
                    )
                }
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
    
    // MARK: - Data Loading
    
    private func loadAnalytics() {
        stats = analytics.getUsageStatistics()
        loadTrends()
        categoryBreakdown = analytics.getCategoryBreakdown()
    }
    
    private func loadTrends() {
        let days: Int
        switch selectedTimeRange {
        case .day:
            days = 1
        case .week:
            days = 7
        case .month:
            days = 30
        case .all:
            days = 365
        }
        
        trends = analytics.getUsageTrends(days: days)
    }
}

// MARK: - Supporting Views

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(color)
                Spacer()
            }
            
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

struct TrendBadge: View {
    let direction: UsageTrends.TrendDirection
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: iconName)
            Text(label)
        }
        .font(.caption)
        .foregroundColor(color)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(color.opacity(0.1))
        .cornerRadius(6)
    }
    
    private var iconName: String {
        switch direction {
        case .increasing:
            return "arrow.up.right"
        case .decreasing:
            return "arrow.down.right"
        case .stable:
            return "arrow.right"
        }
    }
    
    private var label: String {
        switch direction {
        case .increasing:
            return "Increasing"
        case .decreasing:
            return "Decreasing"
        case .stable:
            return "Stable"
        }
    }
    
    private var color: Color {
        switch direction {
        case .increasing:
            return .green
        case .decreasing:
            return .red
        case .stable:
            return .blue
        }
    }
}

struct BarView: View {
    let value: Int
    let maxValue: Int
    
    var body: some View {
        VStack {
            Spacer()
            
            Rectangle()
                .fill(Color.blue)
                .frame(height: CGFloat(value) / CGFloat(maxValue) * 100)
                .cornerRadius(4, corners: [.topLeft, .topRight])
        }
    }
}

struct StorageRow: View {
    let label: String
    let value: String
    let detail: String
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(label)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Text(value)
                    .font(.body)
                    .fontWeight(.medium)
            }
            
            Spacer()
            
            Text(detail)
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}

// Helper for rounded corners
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}

// MARK: - Preview

struct AnalyticsDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AnalyticsDashboardView()
        }
    }
}
