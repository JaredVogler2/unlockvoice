//
//  PronunciationDictionaryView.swift
//  OpenVoice
//
//  Manage custom word pronunciations
//  Phase 3: Speech Enhancement
//

import SwiftUI

struct PronunciationDictionaryView: View {
    @ObservedObject private var speechService = SpeechService.shared
    @Environment(\.dismiss) var dismiss
    @State private var showAddPronunciation = false
    @State private var pronunciations: [String: String] = [:]
    
    var body: some View {
        NavigationView {
            List {
                // Info section
                Section {
                    InfoBanner()
                } header: {
                    Text("About")
                }
                
                // Pronunciations list
                Section {
                    if pronunciations.isEmpty {
                        EmptyPronunciationsView()
                    } else {
                        ForEach(pronunciations.sorted(by: { $0.key < $1.key }), id: \.key) { word, pronunciation in
                            PronunciationRow(
                                word: word,
                                pronunciation: pronunciation,
                                onTest: {
                                    testPronunciation(word: word)
                                },
                                onDelete: {
                                    deletePronunciation(word: word)
                                }
                            )
                        }
                    }
                } header: {
                    Text("Custom Pronunciations")
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Pronunciation")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Close") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showAddPronunciation = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                }
            }
            .sheet(isPresented: $showAddPronunciation) {
                AddPronunciationView()
            }
            .onAppear {
                loadPronunciations()
            }
        }
    }
    
    private func loadPronunciations() {
        pronunciations = speechService.getAllPronunciations()
    }
    
    private func testPronunciation(word: String) {
        // Test the pronunciation
        let testPhrase = "This is how \(word) sounds"
        speechService.speak(testPhrase)
    }
    
    private func deletePronunciation(word: String) {
        speechService.removePronunciation(word: word)
        pronunciations.removeValue(forKey: word)
    }
}

// MARK: - Info Banner

struct InfoBanner: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Image(systemName: "info.circle.fill")
                    .font(.title2)
                    .foregroundColor(.blue)
                
                Text("Custom Pronunciations")
                    .font(.headline)
            }
            
            Text("Add custom pronunciations for names, acronyms, or words that don't sound right. The speech engine will use your pronunciation instead of the default.")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            VStack(alignment: .leading, spacing: 8) {
                ExampleRow(word: "AAC", pronunciation: "A A C")
                ExampleRow(word: "iOS", pronunciation: "eye oh ess")
                ExampleRow(word: "iPad", pronunciation: "eye pad")
            }
            .padding(.top, 4)
        }
        .padding(.vertical, 8)
    }
}

struct ExampleRow: View {
    let word: String
    let pronunciation: String
    
    var body: some View {
        HStack(spacing: 8) {
            Text("•")
                .foregroundColor(.secondary)
            
            Text(word)
                .fontWeight(.medium)
            
            Text("→")
                .foregroundColor(.secondary)
            
            Text(pronunciation)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .font(.caption)
    }
}

// MARK: - Pronunciation Row

struct PronunciationRow: View {
    let word: String
    let pronunciation: String
    let onTest: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(word)
                    .font(.body)
                    .fontWeight(.medium)
                
                Text(pronunciation)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button(action: onTest) {
                Image(systemName: "speaker.wave.2.fill")
                    .foregroundColor(.blue)
            }
            .buttonStyle(.plain)
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: true) {
            Button(role: .destructive, action: onDelete) {
                Label("Delete", systemImage: "trash")
            }
        }
        .contextMenu {
            Button(action: onTest) {
                Label("Test Pronunciation", systemImage: "speaker.wave.2")
            }
            
            Button(role: .destructive, action: onDelete) {
                Label("Delete", systemImage: "trash")
            }
        }
    }
}

// MARK: - Empty State

struct EmptyPronunciationsView: View {
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "text.word.spacing")
                .font(.system(size: 40))
                .foregroundColor(.secondary)
            
            Text("No custom pronunciations yet")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Text("Tap + to add your first pronunciation")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 32)
    }
}

// MARK: - Add Pronunciation View

struct AddPronunciationView: View {
    @Environment(\.dismiss) var dismiss
    @ObservedObject private var speechService = SpeechService.shared
    
    @State private var word = ""
    @State private var pronunciation = ""
    @State private var showingAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section {
                    TextField("Word", text: $word)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    
                    TextField("How to say it", text: $pronunciation)
                        .autocorrectionDisabled()
                } header: {
                    Text("Pronunciation Details")
                } footer: {
                    Text("Enter the word as it appears, then write how it should sound. Example: 'AAC' → 'A A C'")
                }
                
                if !word.isEmpty && !pronunciation.isEmpty {
                    Section {
                        Button("Test Pronunciation") {
                            testPronunciation()
                        }
                        
                        Button("Save") {
                            savePronunciation()
                        }
                        .disabled(!canSave)
                    }
                }
                
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Tips:")
                            .fontWeight(.semibold)
                        
                        Text("• Use phonetic spelling (how it sounds)")
                        Text("• Add spaces to slow down (A A C)")
                        Text("• Try different spellings if needed")
                        Text("• Test before saving")
                    }
                    .font(.caption)
                    .foregroundColor(.secondary)
                }
            }
            .navigationTitle("Add Pronunciation")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        savePronunciation()
                    }
                    .disabled(!canSave)
                }
            }
            .alert("Pronunciation Added", isPresented: $showingAlert) {
                Button("OK") {
                    dismiss()
                }
            } message: {
                Text(alertMessage)
            }
        }
    }
    
    private var canSave: Bool {
        !word.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !pronunciation.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    private func testPronunciation() {
        let testPhrase = "This is how \(word) sounds: \(word)"
        
        // Temporarily add pronunciation
        speechService.addPronunciation(word: word, pronunciation: pronunciation)
        speechService.speak(testPhrase)
        
        // Remove if not saved (will be added back when they hit Save)
        // For now, just leave it - they can delete if they don't like it
    }
    
    private func savePronunciation() {
        let trimmedWord = word.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPronunciation = pronunciation.trimmingCharacters(in: .whitespacesAndNewlines)
        
        speechService.addPronunciation(word: trimmedWord, pronunciation: trimmedPronunciation)
        
        alertMessage = "'\(trimmedWord)' will now be pronounced as '\(trimmedPronunciation)'"
        showingAlert = true
        
        HapticManager.shared.impact(.medium)
    }
}

// MARK: - Preview

struct PronunciationDictionaryView_Previews: PreviewProvider {
    static var previews: some View {
        PronunciationDictionaryView()
    }
}
