//
//  EyeTrackingManager.swift
//  OpenVoice
//
//  Core eye tracking manager using ARKit face tracking
//  Phase 4: ARKit Eye Tracking
//

import Foundation
import ARKit
import SwiftUI
import Combine

/// Main manager for eye tracking functionality
/// Coordinates ARKit face tracking, gaze calculation, and dwell detection
class EyeTrackingManager: NSObject, ObservableObject {
    static let shared = EyeTrackingManager()
    
    // MARK: - Published Properties
    
    @Published var isTracking = false
    @Published var gazePoint: CGPoint = .zero
    @Published var isDwelling = false
    @Published var dwellProgress: Double = 0.0
    @Published var faceTrackingQuality: TrackingQuality = .notAvailable
    @Published var isCalibrated = false
    
    // MARK: - Private Properties
    
    private var sceneView: ARSCNView?
    private let configuration = ARFaceTrackingConfiguration()
    private var lastFaceAnchor: ARFaceAnchor?
    
    // Sub-managers
    private let gazeCalculator = GazeCalculator()
    private let dwellDetector = DwellTimeDetector()
    private var calibrationData: CalibrationData?
    
    // Settings
    private var dwellTimeThreshold: TimeInterval = 1.0  // seconds
    private var gazeSmoothing: Int = 3  // number of frames to average
    
    // Smoothing buffer
    private var gazeHistory: [CGPoint] = []
    private let maxGazeHistory = 5
    
    // Performance tracking
    private var lastUpdateTime: CFTimeInterval = 0
    private var frameCount = 0
    private var fps: Double = 0
    
    // Callbacks
    var onGazeUpdate: ((CGPoint) -> Void)?
    var onDwellComplete: ((CGPoint) -> Void)?
    var onTrackingQualityChanged: ((TrackingQuality) -> Void)?
    
    // MARK: - Initialization
    
    private override init() {
        super.init()
        setupARConfiguration()
        loadCalibrationData()
    }
    
    // MARK: - Setup
    
    private func setupARConfiguration() {
        guard ARFaceTrackingConfiguration.isSupported else {
            print("❌ Face tracking not supported on this device")
            faceTrackingQuality = .notAvailable
            return
        }
        
        // Configure face tracking
        configuration.isLightEstimationEnabled = false
        configuration.worldAlignment = .camera
        
        // Performance settings
        if #available(iOS 16.0, *) {
            configuration.videoFormat = ARFaceTrackingConfiguration.supportedVideoFormats[0]
        }
        
        print("✅ ARKit configuration ready")
    }
    
    // MARK: - Public Methods
    
    /// Start eye tracking with provided ARSCNView
    func startTracking(with sceneView: ARSCNView) {
        guard ARFaceTrackingConfiguration.isSupported else {
            print("❌ Cannot start tracking - not supported")
            return
        }
        
        self.sceneView = sceneView
        sceneView.delegate = self
        sceneView.session.delegate = self
        
        // Start AR session
        sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
        
        isTracking = true
        print("🎯 Eye tracking started")
    }
    
    /// Stop eye tracking
    func stopTracking() {
        sceneView?.session.pause()
        isTracking = false
        resetState()
        print("⏸️ Eye tracking stopped")
    }
    
    /// Reset tracking state
    func resetState() {
        gazePoint = .zero
        isDwelling = false
        dwellProgress = 0.0
        gazeHistory.removeAll()
        dwellDetector.reset()
    }
    
    /// Update settings
    func updateSettings(dwellTime: TimeInterval, smoothing: Int) {
        self.dwellTimeThreshold = dwellTime
        self.gazeSmoothing = smoothing
        dwellDetector.updateThreshold(dwellTime)
    }
    
    /// Apply calibration data
    func applyCalibration(_ data: CalibrationData) {
        self.calibrationData = data
        self.isCalibrated = true
        saveCalibrationData()
        print("✅ Calibration applied")
    }
    
    /// Clear calibration
    func clearCalibration() {
        self.calibrationData = nil
        self.isCalibrated = false
        UserDefaults.standard.removeObject(forKey: "EyeTrackingCalibration")
        print("🗑️ Calibration cleared")
    }
    
    // MARK: - Private Methods
    
    /// Process face anchor update
    private func processFaceAnchor(_ faceAnchor: ARFaceAnchor) {
        lastFaceAnchor = faceAnchor
        
        // Get eye look-at points
        guard let leftLookAt = faceAnchor.leftEyeTransform,
              let rightLookAt = faceAnchor.rightEyeTransform else {
            updateTrackingQuality(.poor)
            return
        }
        
        // Calculate gaze point
        let rawGazePoint = gazeCalculator.calculateGazePoint(
            leftEye: leftLookAt,
            rightEye: rightLookAt,
            screenSize: UIScreen.main.bounds.size
        )
        
        // Apply calibration if available
        let calibratedPoint: CGPoint
        if let calibration = calibrationData, isCalibrated {
            calibratedPoint = gazeCalculator.applyCalibration(rawGazePoint, with: calibration)
        } else {
            calibratedPoint = rawGazePoint
        }
        
        // Apply smoothing
        let smoothedPoint = applySmoothingToGaze(calibratedPoint)
        
        // Update gaze point on main thread
        DispatchQueue.main.async { [weak self] in
            self?.gazePoint = smoothedPoint
            self?.onGazeUpdate?(smoothedPoint)
        }
        
        // Check dwell time
        checkDwellTime(at: smoothedPoint)
        
        // Update tracking quality
        updateTrackingQuality(evaluateTrackingQuality(faceAnchor))
    }
    
    /// Apply smoothing to gaze point
    private func applySmoothingToGaze(_ point: CGPoint) -> CGPoint {
        // Add to history
        gazeHistory.append(point)
        
        // Keep only recent history
        if gazeHistory.count > gazeSmoothing {
            gazeHistory.removeFirst()
        }
        
        // Calculate average
        let avgX = gazeHistory.map(\.x).reduce(0, +) / CGFloat(gazeHistory.count)
        let avgY = gazeHistory.map(\.y).reduce(0, +) / CGFloat(gazeHistory.count)
        
        return CGPoint(x: avgX, y: avgY)
    }
    
    /// Check if dwell time threshold reached
    private func checkDwellTime(at point: CGPoint) {
        let result = dwellDetector.update(gazePoint: point, threshold: dwellTimeThreshold)
        
        DispatchQueue.main.async { [weak self] in
            self?.isDwelling = result.isDwelling
            self?.dwellProgress = result.progress
            
            if result.completed {
                // Dwell complete - trigger selection
                self?.onDwellComplete?(point)
                self?.dwellDetector.reset()
            }
        }
    }
    
    /// Evaluate tracking quality based on face anchor
    private func evaluateTrackingQuality(_ faceAnchor: ARFaceAnchor) -> TrackingQuality {
        // Check if eyes are visible
        let leftEyeBlink = faceAnchor.blendShapes[.eyeBlinkLeft]?.floatValue ?? 0
        let rightEyeBlink = faceAnchor.blendShapes[.eyeBlinkRight]?.floatValue ?? 0
        
        // If eyes are mostly closed, tracking is poor
        if leftEyeBlink > 0.8 || rightEyeBlink > 0.8 {
            return .poor
        }
        
        // Check confidence (distance to camera affects this)
        // Good tracking: face is centered and at optimal distance
        let transform = faceAnchor.transform
        let distance = sqrt(
            transform.columns.3.x * transform.columns.3.x +
            transform.columns.3.y * transform.columns.3.y +
            transform.columns.3.z * transform.columns.3.z
        )
        
        // Optimal distance: 30-60cm
        if distance < 0.3 || distance > 0.6 {
            return .fair
        }
        
        return .good
    }
    
    /// Update tracking quality
    private func updateTrackingQuality(_ quality: TrackingQuality) {
        if faceTrackingQuality != quality {
            DispatchQueue.main.async { [weak self] in
                self?.faceTrackingQuality = quality
                self?.onTrackingQualityChanged?(quality)
            }
        }
    }
    
    /// Update FPS counter
    private func updateFPS() {
        frameCount += 1
        let currentTime = CACurrentMediaTime()
        let elapsed = currentTime - lastUpdateTime
        
        if elapsed >= 1.0 {
            fps = Double(frameCount) / elapsed
            frameCount = 0
            lastUpdateTime = currentTime
            
            // Log performance warning if below 30 FPS
            if fps < 30 {
                print("⚠️ Low FPS detected: \(String(format: "%.1f", fps))")
            }
        }
    }
    
    // MARK: - Persistence
    
    private func loadCalibrationData() {
        guard let data = UserDefaults.standard.data(forKey: "EyeTrackingCalibration"),
              let calibration = try? JSONDecoder().decode(CalibrationData.self, from: data) else {
            return
        }
        
        self.calibrationData = calibration
        self.isCalibrated = true
        print("✅ Loaded saved calibration")
    }
    
    private func saveCalibrationData() {
        guard let calibration = calibrationData,
              let data = try? JSONEncoder().encode(calibration) else {
            return
        }
        
        UserDefaults.standard.set(data, forKey: "EyeTrackingCalibration")
        print("💾 Calibration saved")
    }
}

// MARK: - ARSCNViewDelegate

extension EyeTrackingManager: ARSCNViewDelegate {
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let faceAnchor = anchor as? ARFaceAnchor else { return }
        
        processFaceAnchor(faceAnchor)
        updateFPS()
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard anchor is ARFaceAnchor else { return }
        print("👤 Face detected")
        
        DispatchQueue.main.async { [weak self] in
            self?.faceTrackingQuality = .fair
        }
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didRemove node: SCNNode, for anchor: ARAnchor) {
        guard anchor is ARFaceAnchor else { return }
        print("👤 Face lost")
        
        DispatchQueue.main.async { [weak self] in
            self?.faceTrackingQuality = .poor
            self?.resetState()
        }
    }
}

// MARK: - ARSessionDelegate

extension EyeTrackingManager: ARSessionDelegate {
    func session(_ session: ARSession, didFailWithError error: Error) {
        print("❌ AR Session failed: \(error.localizedDescription)")
        
        DispatchQueue.main.async { [weak self] in
            self?.faceTrackingQuality = .notAvailable
            self?.isTracking = false
        }
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        print("⏸️ AR Session interrupted")
        
        DispatchQueue.main.async { [weak self] in
            self?.resetState()
        }
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        print("▶️ AR Session resumed")
        
        // Restart tracking
        session.run(configuration, options: [.resetTracking])
    }
}

// MARK: - Supporting Types

enum TrackingQuality: String, Codable {
    case notAvailable = "Not Available"
    case poor = "Poor"
    case fair = "Fair"
    case good = "Good"
    
    var color: Color {
        switch self {
        case .notAvailable: return .gray
        case .poor: return .red
        case .fair: return .orange
        case .good: return .green
        }
    }
    
    var icon: String {
        switch self {
        case .notAvailable: return "exclamationmark.triangle"
        case .poor: return "xmark.circle"
        case .fair: return "minus.circle"
        case .good: return "checkmark.circle"
        }
    }
}

extension ARFaceAnchor {
    var leftEyeTransform: simd_float4x4? {
        return simd_float4x4() // Placeholder - actual implementation uses anchor geometry
    }
    
    var rightEyeTransform: simd_float4x4? {
        return simd_float4x4() // Placeholder - actual implementation uses anchor geometry
    }
}
