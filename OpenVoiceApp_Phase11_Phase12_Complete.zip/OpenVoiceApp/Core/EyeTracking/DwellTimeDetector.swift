//
//  DwellTimeDetector.swift
//  OpenVoice
//
//  Detects when user dwells on a point long enough to trigger selection
//  Phase 4: ARKit Eye Tracking
//

import Foundation
import CoreGraphics

/// Detects dwell-time based selections for eye tracking
class DwellTimeDetector {
    
    // MARK: - Properties
    
    private var dwellStartTime: Date?
    private var dwellPoint: CGPoint?
    private var threshold: TimeInterval = 1.0  // seconds
    private let movementTolerance: CGFloat = 30  // points
    
    // History for stability check
    private var recentGazePoints: [GazeDataPoint] = []
    private let historyDuration: TimeInterval = 0.5  // Keep 0.5s of history
    
    // MARK: - Public Methods
    
    /// Update with new gaze point
    /// - Parameters:
    ///   - gazePoint: Current gaze location
    ///   - threshold: Dwell time threshold in seconds
    /// - Returns: Dwell detection result
    func update(gazePoint: CGPoint, threshold: TimeInterval) -> DwellResult {
        self.threshold = threshold
        
        // Add to history
        addToHistory(point: gazePoint)
        
        // Check if gaze is stable
        let isStable = isGazeStable()
        
        if !isStable {
            // Movement detected - reset dwell
            reset()
            return DwellResult(isDwelling: false, progress: 0, completed: false)
        }
        
        // Check if we're dwelling on a new point or continuing
        if let currentDwellPoint = dwellPoint {
            // Check if still looking at same point
            let distance = self.distance(from: gazePoint, to: currentDwellPoint)
            
            if distance > movementTolerance {
                // Moved to new point - restart dwell
                startDwell(at: gazePoint)
                return DwellResult(isDwelling: true, progress: 0, completed: false)
            }
        } else {
            // Start new dwell
            startDwell(at: gazePoint)
            return DwellResult(isDwelling: true, progress: 0, completed: false)
        }
        
        // Calculate progress
        guard let startTime = dwellStartTime else {
            return DwellResult(isDwelling: false, progress: 0, completed: false)
        }
        
        let elapsed = Date().timeIntervalSince(startTime)
        let progress = min(1.0, elapsed / threshold)
        
        // Check if threshold reached
        let completed = elapsed >= threshold
        
        return DwellResult(
            isDwelling: true,
            progress: progress,
            completed: completed
        )
    }
    
    /// Update dwell time threshold
    func updateThreshold(_ threshold: TimeInterval) {
        self.threshold = threshold
    }
    
    /// Reset dwell state
    func reset() {
        dwellStartTime = nil
        dwellPoint = nil
    }
    
    /// Clear history
    func clearHistory() {
        recentGazePoints.removeAll()
    }
    
    // MARK: - Private Methods
    
    /// Start tracking dwell at point
    private func startDwell(at point: CGPoint) {
        dwellStartTime = Date()
        dwellPoint = point
    }
    
    /// Add gaze point to history
    private func addToHistory(point: CGPoint) {
        let dataPoint = GazeDataPoint(point: point, timestamp: Date())
        recentGazePoints.append(dataPoint)
        
        // Remove old points beyond history duration
        let cutoffTime = Date().addingTimeInterval(-historyDuration)
        recentGazePoints.removeAll { $0.timestamp < cutoffTime }
    }
    
    /// Check if gaze is stable (not moving too much)
    private func isGazeStable() -> Bool {
        guard recentGazePoints.count >= 3 else {
            return false  // Not enough data
        }
        
        // Calculate variance of recent points
        let points = recentGazePoints.map { $0.point }
        
        // Calculate mean
        let meanX = points.map { $0.x }.reduce(0, +) / CGFloat(points.count)
        let meanY = points.map { $0.y }.reduce(0, +) / CGFloat(points.count)
        let mean = CGPoint(x: meanX, y: meanY)
        
        // Calculate variance
        let variance = points.map { point in
            let dx = point.x - mean.x
            let dy = point.y - mean.y
            return dx * dx + dy * dy
        }.reduce(0, +) / CGFloat(points.count)
        
        let standardDeviation = sqrt(variance)
        
        // Stable if standard deviation is below tolerance
        return standardDeviation < movementTolerance / 2
    }
    
    /// Calculate distance between two points
    private func distance(from point1: CGPoint, to point2: CGPoint) -> CGFloat {
        let dx = point2.x - point1.x
        let dy = point2.y - point1.y
        return sqrt(dx * dx + dy * dy)
    }
}

// MARK: - Supporting Types

/// Result of dwell detection
struct DwellResult {
    let isDwelling: Bool
    let progress: Double  // 0.0 to 1.0
    let completed: Bool
}

/// Single gaze data point with timestamp
private struct GazeDataPoint {
    let point: CGPoint
    let timestamp: Date
}

// MARK: - Dwell Animation Helper

/// Helper for animating dwell progress
class DwellAnimator {
    private var displayLink: CADisplayLink?
    private var startTime: CFTimeInterval = 0
    private var duration: TimeInterval = 0
    
    var onUpdate: ((Double) -> Void)?
    var onComplete: (() -> Void)?
    
    func start(duration: TimeInterval) {
        self.duration = duration
        self.startTime = CACurrentMediaTime()
        
        displayLink?.invalidate()
        displayLink = CADisplayLink(target: self, selector: #selector(update))
        displayLink?.add(to: .main, forMode: .common)
    }
    
    func stop() {
        displayLink?.invalidate()
        displayLink = nil
    }
    
    @objc private func update() {
        let elapsed = CACurrentMediaTime() - startTime
        let progress = min(1.0, elapsed / duration)
        
        onUpdate?(progress)
        
        if progress >= 1.0 {
            stop()
            onComplete?()
        }
    }
}

// MARK: - Dwell Settings

/// Configuration for dwell detection
struct DwellSettings: Codable {
    var dwellTime: TimeInterval = 1.0  // seconds
    var movementTolerance: CGFloat = 30  // points
    var requireStableGaze: Bool = true
    var visualFeedback: Bool = true
    var hapticFeedback: Bool = true
    var soundFeedback: Bool = false
    
    // Presets
    static let fast = DwellSettings(dwellTime: 0.5)
    static let normal = DwellSettings(dwellTime: 1.0)
    static let slow = DwellSettings(dwellTime: 1.5)
    static let accessible = DwellSettings(dwellTime: 2.0, movementTolerance: 50)
    
    var description: String {
        "\(String(format: "%.1f", dwellTime))s dwell, \(Int(movementTolerance))pt tolerance"
    }
}
