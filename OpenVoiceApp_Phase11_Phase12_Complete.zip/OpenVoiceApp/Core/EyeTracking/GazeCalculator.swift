//
//  GazeCalculator.swift
//  OpenVoice
//
//  Calculates gaze point from eye transforms and projects to screen coordinates
//  Phase 4: ARKit Eye Tracking
//

import Foundation
import ARKit
import simd

/// Handles conversion from 3D eye tracking data to 2D screen coordinates
class GazeCalculator {
    
    // MARK: - Properties
    
    private let defaultDistanceToScreen: Float = 0.4  // 40cm in meters
    
    // MARK: - Public Methods
    
    /// Calculate gaze point from left and right eye transforms
    /// - Parameters:
    ///   - leftEye: Transform matrix for left eye
    ///   - rightEye: Transform matrix for right eye
    ///   - screenSize: Size of the screen in points
    /// - Returns: Gaze point in screen coordinates
    func calculateGazePoint(leftEye: simd_float4x4, rightEye: simd_float4x4, screenSize: CGSize) -> CGPoint {
        // Extract look-at vectors from transforms
        let leftLookAt = extractLookAtVector(from: leftEye)
        let rightLookAt = extractLookAtVector(from: rightEye)
        
        // Average the two eye vectors
        let avgLookAt = (leftLookAt + rightLookAt) / 2.0
        
        // Project to screen
        let screenPoint = projectToScreen(vector: avgLookAt, screenSize: screenSize)
        
        return screenPoint
    }
    
    /// Apply calibration correction to gaze point
    /// - Parameters:
    ///   - point: Raw gaze point
    ///   - calibration: Calibration data
    /// - Returns: Calibrated gaze point
    func applyCalibration(_ point: CGPoint, with calibration: CalibrationData) -> CGPoint {
        // Apply offset
        var calibratedPoint = CGPoint(
            x: point.x + calibration.offset.x,
            y: point.y + calibration.offset.y
        )
        
        // Apply scale
        calibratedPoint = CGPoint(
            x: calibratedPoint.x * CGFloat(calibration.scale.x),
            y: calibratedPoint.y * CGFloat(calibration.scale.y)
        )
        
        // Apply rotation if needed (for advanced calibration)
        if calibration.rotation != 0 {
            calibratedPoint = rotatePoint(calibratedPoint, by: calibration.rotation)
        }
        
        return calibratedPoint
    }
    
    // MARK: - Private Methods
    
    /// Extract look-at vector from transform matrix
    private func extractLookAtVector(from transform: simd_float4x4) -> simd_float3 {
        // The look-at vector is typically the -Z axis of the transform
        let lookAtVector = simd_float3(
            -transform.columns.2.x,
            -transform.columns.2.y,
            -transform.columns.2.z
        )
        
        return simd_normalize(lookAtVector)
    }
    
    /// Project 3D vector to 2D screen coordinates
    private func projectToScreen(vector: simd_float3, screenSize: CGSize) -> CGPoint {
        // Simple projection assuming screen is perpendicular to camera
        // For more accurate projection, would need camera intrinsics
        
        // Calculate intersection with virtual screen plane
        let t = defaultDistanceToScreen / max(abs(vector.z), 0.001)  // Avoid division by zero
        
        let intersectX = vector.x * t
        let intersectY = vector.y * t
        
        // Convert to screen coordinates
        // Screen center is (0,0) in camera space
        // Map to screen coordinates with center at screenSize/2
        
        let screenX = (CGFloat(intersectX) + 0.5) * screenSize.width
        let screenY = (0.5 - CGFloat(intersectY)) * screenSize.height  // Invert Y
        
        // Clamp to screen bounds
        let clampedX = max(0, min(screenSize.width, screenX))
        let clampedY = max(0, min(screenSize.height, screenY))
        
        return CGPoint(x: clampedX, y: clampedY)
    }
    
    /// Rotate point around screen center
    private func rotatePoint(_ point: CGPoint, by angle: Double) -> CGPoint {
        let screenCenter = CGPoint(
            x: UIScreen.main.bounds.width / 2,
            y: UIScreen.main.bounds.height / 2
        )
        
        // Translate to origin
        let translated = CGPoint(
            x: point.x - screenCenter.x,
            y: point.y - screenCenter.y
        )
        
        // Rotate
        let cosAngle = cos(angle)
        let sinAngle = sin(angle)
        
        let rotated = CGPoint(
            x: translated.x * cosAngle - translated.y * sinAngle,
            y: translated.x * sinAngle + translated.y * cosAngle
        )
        
        // Translate back
        return CGPoint(
            x: rotated.x + screenCenter.x,
            y: rotated.y + screenCenter.y
        )
    }
    
    /// Calculate distance between two points
    func distance(from point1: CGPoint, to point2: CGPoint) -> CGFloat {
        let dx = point2.x - point1.x
        let dy = point2.y - point1.y
        return sqrt(dx * dx + dy * dy)
    }
    
    /// Check if gaze point is within bounds of a rect
    func isGazing(at point: CGPoint, rect: CGRect, tolerance: CGFloat = 20) -> Bool {
        let expandedRect = rect.insetBy(dx: -tolerance, dy: -tolerance)
        return expandedRect.contains(point)
    }
    
    /// Calculate angle between two vectors (in degrees)
    func angleBetweenVectors(_ v1: simd_float3, _ v2: simd_float3) -> Float {
        let dot = simd_dot(v1, v2)
        let magnitudes = simd_length(v1) * simd_length(v2)
        
        guard magnitudes > 0 else { return 0 }
        
        let cosAngle = max(-1, min(1, dot / magnitudes))  // Clamp to [-1, 1]
        return acos(cosAngle) * 180.0 / Float.pi
    }
}

/// Calibration data for gaze correction
struct CalibrationData: Codable {
    var offset: CGPoint
    var scale: CGPoint
    var rotation: Double  // in radians
    var points: [CalibrationPoint]
    var accuracy: Double  // average error in points
    var timestamp: Date
    
    init(offset: CGPoint = .zero, 
         scale: CGPoint = CGPoint(x: 1, y: 1), 
         rotation: Double = 0,
         points: [CalibrationPoint] = [],
         accuracy: Double = 0,
         timestamp: Date = Date()) {
        self.offset = offset
        self.scale = scale
        self.rotation = rotation
        self.points = points
        self.accuracy = accuracy
        self.timestamp = timestamp
    }
    
    var isValid: Bool {
        return points.count >= 9 && accuracy < 100  // Less than 100 points error
    }
    
    var qualityDescription: String {
        if accuracy < 30 { return "Excellent" }
        if accuracy < 50 { return "Good" }
        if accuracy < 80 { return "Fair" }
        return "Poor"
    }
}

/// Single calibration point data
struct CalibrationPoint: Codable {
    let targetPoint: CGPoint
    var gazePoints: [CGPoint]
    
    var averageGaze: CGPoint {
        guard !gazePoints.isEmpty else { return .zero }
        
        let sumX = gazePoints.reduce(0) { $0 + $1.x }
        let sumY = gazePoints.reduce(0) { $0 + $1.y }
        
        return CGPoint(
            x: sumX / CGFloat(gazePoints.count),
            y: sumY / CGFloat(gazePoints.count)
        )
    }
    
    var error: CGFloat {
        let avg = averageGaze
        let dx = avg.x - targetPoint.x
        let dy = avg.y - targetPoint.y
        return sqrt(dx * dx + dy * dy)
    }
}

// MARK: - CGPoint Extensions for Math

extension CGPoint: Codable {
    enum CodingKeys: String, CodingKey {
        case x, y
    }
    
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let x = try container.decode(CGFloat.self, forKey: .x)
        let y = try container.decode(CGFloat.self, forKey: .y)
        self.init(x: x, y: y)
    }
    
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(x, forKey: .x)
        try container.encode(y, forKey: .y)
    }
    
    static func + (lhs: CGPoint, rhs: CGPoint) -> CGPoint {
        return CGPoint(x: lhs.x + rhs.x, y: lhs.y + rhs.y)
    }
    
    static func - (lhs: CGPoint, rhs: CGPoint) -> CGPoint {
        return CGPoint(x: lhs.x - rhs.x, y: lhs.y - rhs.y)
    }
    
    static func * (lhs: CGPoint, rhs: CGFloat) -> CGPoint {
        return CGPoint(x: lhs.x * rhs, y: lhs.y * rhs)
    }
    
    static func / (lhs: CGPoint, rhs: CGFloat) -> CGPoint {
        return CGPoint(x: lhs.x / rhs, y: lhs.y / rhs)
    }
}
