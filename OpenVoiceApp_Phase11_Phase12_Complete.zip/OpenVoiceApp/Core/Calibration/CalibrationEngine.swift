//
//  CalibrationEngine.swift
//  OpenVoice
//
//  9-point calibration system for eye tracking accuracy
//  Phase 4: ARKit Eye Tracking
//

import Foundation
import SwiftUI
import Combine

/// Manages the calibration process for eye tracking
class CalibrationEngine: ObservableObject {
    
    // MARK: - Published Properties
    
    @Published var isCalibrating = false
    @Published var currentPointIndex = 0
    @Published var collectedPoints: [CalibrationPoint] = []
    @Published var calibrationResult: CalibrationData?
    @Published var progress: Double = 0.0
    
    // MARK: - Properties
    
    private let screenSize: CGSize
    private var calibrationPoints: [CGPoint] = []
    private var currentGazeData: [CGPoint] = []
    private let samplesPerPoint = 30  // Number of gaze samples to collect per calibration point
    private var sampleCount = 0
    
    // Callbacks
    var onCalibrationComplete: ((CalibrationData) -> Void)?
    var onCalibrationFailed: ((String) -> Void)?
    var onPointComplete: ((Int) -> Void)?
    
    // MARK: - Initialization
    
    init(screenSize: CGSize = UIScreen.main.bounds.size) {
        self.screenSize = screenSize
        setupCalibrationPoints()
    }
    
    // MARK: - Setup
    
    /// Generate 9 calibration points in a 3x3 grid
    private func setupCalibrationPoints() {
        let margin: CGFloat = 100  // Points from edge
        let centerX = screenSize.width / 2
        let centerY = screenSize.height / 2
        
        // Define 9 points: 4 corners + 4 edges + center
        calibrationPoints = [
            // Top row
            CGPoint(x: margin, y: margin),                      // Top-left
            CGPoint(x: centerX, y: margin),                      // Top-center
            CGPoint(x: screenSize.width - margin, y: margin),    // Top-right
            
            // Middle row
            CGPoint(x: margin, y: centerY),                      // Middle-left
            CGPoint(x: centerX, y: centerY),                      // Center
            CGPoint(x: screenSize.width - margin, y: centerY),   // Middle-right
            
            // Bottom row
            CGPoint(x: margin, y: screenSize.height - margin),                    // Bottom-left
            CGPoint(x: centerX, y: screenSize.height - margin),                    // Bottom-center
            CGPoint(x: screenSize.width - margin, y: screenSize.height - margin)   // Bottom-right
        ]
    }
    
    // MARK: - Public Methods
    
    /// Start calibration process
    func startCalibration() {
        isCalibrating = true
        currentPointIndex = 0
        collectedPoints = []
        currentGazeData = []
        sampleCount = 0
        progress = 0.0
        
        print("🎯 Calibration started")
    }
    
    /// Add gaze sample for current calibration point
    func addGazeSample(_ gazePoint: CGPoint) {
        guard isCalibrating else { return }
        guard currentPointIndex < calibrationPoints.count else { return }
        
        currentGazeData.append(gazePoint)
        sampleCount += 1
        
        // Update progress
        let pointProgress = Double(sampleCount) / Double(samplesPerPoint)
        let overallProgress = (Double(currentPointIndex) + pointProgress) / Double(calibrationPoints.count)
        progress = overallProgress
        
        // Check if we have enough samples for this point
        if sampleCount >= samplesPerPoint {
            completeCurrentPoint()
        }
    }
    
    /// Skip current calibration point
    func skipCurrentPoint() {
        guard isCalibrating else { return }
        
        // Use current data even if incomplete
        completeCurrentPoint()
    }
    
    /// Cancel calibration
    func cancelCalibration() {
        isCalibrating = false
        currentPointIndex = 0
        collectedPoints = []
        currentGazeData = []
        sampleCount = 0
        progress = 0.0
        
        print("❌ Calibration cancelled")
    }
    
    /// Get current calibration target point
    func getCurrentTargetPoint() -> CGPoint? {
        guard currentPointIndex < calibrationPoints.count else { return nil }
        return calibrationPoints[currentPointIndex]
    }
    
    /// Get all calibration target points
    func getAllTargetPoints() -> [CGPoint] {
        return calibrationPoints
    }
    
    // MARK: - Private Methods
    
    /// Complete current calibration point and move to next
    private func completeCurrentPoint() {
        let targetPoint = calibrationPoints[currentPointIndex]
        let calibrationPoint = CalibrationPoint(
            targetPoint: targetPoint,
            gazePoints: currentGazeData
        )
        
        collectedPoints.append(calibrationPoint)
        onPointComplete?(currentPointIndex)
        
        print("✅ Point \(currentPointIndex + 1)/9 complete - Error: \(String(format: "%.1f", calibrationPoint.error))pt")
        
        // Move to next point
        currentPointIndex += 1
        currentGazeData = []
        sampleCount = 0
        
        // Check if calibration complete
        if currentPointIndex >= calibrationPoints.count {
            finishCalibration()
        }
    }
    
    /// Finish calibration and calculate transformation
    private func finishCalibration() {
        // Calculate calibration transformation
        guard let calibrationData = calculateCalibration() else {
            let errorMsg = "Failed to calculate calibration transformation"
            print("❌ \(errorMsg)")
            onCalibrationFailed?(errorMsg)
            cancelCalibration()
            return
        }
        
        isCalibrating = false
        calibrationResult = calibrationData
        
        print("🎉 Calibration complete! Accuracy: \(String(format: "%.1f", calibrationData.accuracy))pt (\(calibrationData.qualityDescription))")
        
        onCalibrationComplete?(calibrationData)
    }
    
    /// Calculate calibration transformation from collected points
    private func calculateCalibration() -> CalibrationData? {
        guard collectedPoints.count >= 9 else {
            print("❌ Not enough calibration points: \(collectedPoints.count)")
            return nil
        }
        
        // Calculate offset (average difference between target and gaze)
        var totalOffsetX: CGFloat = 0
        var totalOffsetY: CGFloat = 0
        var totalError: CGFloat = 0
        
        for point in collectedPoints {
            let avg = point.averageGaze
            let offset = CGPoint(
                x: point.targetPoint.x - avg.x,
                y: point.targetPoint.y - avg.y
            )
            
            totalOffsetX += offset.x
            totalOffsetY += offset.y
            totalError += point.error
        }
        
        let avgOffset = CGPoint(
            x: totalOffsetX / CGFloat(collectedPoints.count),
            y: totalOffsetY / CGFloat(collectedPoints.count)
        )
        
        // Calculate scale factors
        let scale = calculateScale(points: collectedPoints)
        
        // Calculate rotation (simplified - could be more sophisticated)
        let rotation = calculateRotation(points: collectedPoints)
        
        // Average error
        let avgError = totalError / CGFloat(collectedPoints.count)
        
        let calibrationData = CalibrationData(
            offset: avgOffset,
            scale: scale,
            rotation: rotation,
            points: collectedPoints,
            accuracy: Double(avgError),
            timestamp: Date()
        )
        
        return calibrationData
    }
    
    /// Calculate scale factors from calibration points
    private func calculateScale(points: [CalibrationPoint]) -> CGPoint {
        // Calculate scale by comparing target vs gaze distances
        var scaleFactors: [CGPoint] = []
        
        // Compare neighboring points
        for i in 0..<points.count - 1 {
            let target1 = points[i].targetPoint
            let target2 = points[i + 1].targetPoint
            let gaze1 = points[i].averageGaze
            let gaze2 = points[i + 1].averageGaze
            
            let targetDist = distance(target1, target2)
            let gazeDist = distance(gaze1, gaze2)
            
            if gazeDist > 0 {
                let scaleFactor = targetDist / gazeDist
                scaleFactors.append(CGPoint(x: scaleFactor, y: scaleFactor))
            }
        }
        
        // Average scale factors
        if scaleFactors.isEmpty {
            return CGPoint(x: 1, y: 1)
        }
        
        let avgScaleX = scaleFactors.map { $0.x }.reduce(0, +) / CGFloat(scaleFactors.count)
        let avgScaleY = scaleFactors.map { $0.y }.reduce(0, +) / CGFloat(scaleFactors.count)
        
        return CGPoint(x: avgScaleX, y: avgScaleY)
    }
    
    /// Calculate rotation angle from calibration points
    private func calculateRotation(points: [CalibrationPoint]) -> Double {
        // Simplified: assume no significant rotation for now
        // Advanced implementation would use linear regression
        return 0.0
    }
    
    /// Calculate distance between two points
    private func distance(_ p1: CGPoint, _ p2: CGPoint) -> CGFloat {
        let dx = p2.x - p1.x
        let dy = p2.y - p1.y
        return sqrt(dx * dx + dy * dy)
    }
    
    // MARK: - Validation
    
    /// Validate calibration quality
    func validateCalibration(_ data: CalibrationData) -> CalibrationQuality {
        let avgError = data.accuracy
        
        if avgError < 30 {
            return .excellent
        } else if avgError < 50 {
            return .good
        } else if avgError < 80 {
            return .fair
        } else {
            return .poor
        }
    }
}

// MARK: - Supporting Types

enum CalibrationQuality: String {
    case excellent = "Excellent"
    case good = "Good"
    case fair = "Fair"
    case poor = "Poor"
    case notCalibrated = "Not Calibrated"
    
    var color: Color {
        switch self {
        case .excellent: return .green
        case .good: return .blue
        case .fair: return .orange
        case .poor: return .red
        case .notCalibrated: return .gray
        }
    }
    
    var icon: String {
        switch self {
        case .excellent: return "star.fill"
        case .good: return "checkmark.circle.fill"
        case .fair: return "exclamationmark.circle.fill"
        case .poor: return "xmark.circle.fill"
        case .notCalibrated: return "questionmark.circle.fill"
        }
    }
    
    var recommendation: String {
        switch self {
        case .excellent:
            return "Your calibration is excellent! You're ready to use eye tracking."
        case .good:
            return "Good calibration. Eye tracking should work well."
        case .fair:
            return "Fair calibration. Consider recalibrating for better accuracy."
        case .poor:
            return "Poor calibration. Please recalibrate for better results."
        case .notCalibrated:
            return "Please complete calibration to use eye tracking."
        }
    }
}

// MARK: - Calibration State

enum CalibrationState {
    case notStarted
    case inProgress(point: Int, total: Int)
    case collecting(samples: Int, required: Int)
    case complete(quality: CalibrationQuality)
    case failed(reason: String)
    
    var description: String {
        switch self {
        case .notStarted:
            return "Not Started"
        case .inProgress(let point, let total):
            return "Point \(point)/\(total)"
        case .collecting(let samples, let required):
            return "Collecting: \(samples)/\(required)"
        case .complete(let quality):
            return "Complete: \(quality.rawValue)"
        case .failed(let reason):
            return "Failed: \(reason)"
        }
    }
}
