# 🔮 PHASE 8: INTEGRATION GUIDE

## Complete Step-by-Step Implementation

This guide walks you through integrating Phase 8's advanced RAG system into your existing OpenVoice backend.

---

## 📋 Prerequisites

Before starting:
- ✅ Phase 7 backend is working
- ✅ Python 3.8+ environment
- ✅ ~500MB disk space
- ✅ 2GB RAM available
- ✅ Docker (optional, recommended)

---

## 🚀 Installation Steps

### Step 1: Install Dependencies

```bash
cd PythonBackend

# Update dependencies
pip install -r requirements.txt

# Or install individually
pip install sentence-transformers==2.2.2
pip install faiss-cpu==1.7.4
pip install numpy==1.24.3
pip install scikit-learn==1.3.2

# For GPU support (optional)
# pip install faiss-gpu==1.7.4
```

**Verification:**
```python
python3 -c "import faiss; print('FAISS:', faiss.__version__)"
python3 -c "from sentence_transformers import SentenceTransformer; print('OK')"
```

### Step 2: Test Embedding Service

```bash
# Create test file
cat > test_embeddings.py << 'EOF'
import asyncio
from src.models.embedding_service import EmbeddingService

async def test():
    service = EmbeddingService()
    await service.initialize()
    
    texts = ["I want water", "I need help", "Hello world"]
    embeddings = await service.embed_texts(texts)
    
    print(f"✅ Generated embeddings: {embeddings.shape}")
    print(f"   Dimension: {embeddings.shape[1]}")
    print(f"   Stats: {service.get_statistics()}")

asyncio.run(test())
EOF

python3 test_embeddings.py
```

**Expected output:**
```
✅ Generated embeddings: (3, 384)
   Dimension: 384
   Stats: {'total_embeddings': 3, ...}
```

### Step 3: Test FAISS RAG

```bash
# Create test file
cat > test_rag.py << 'EOF'
import asyncio
from src.models.rag_engine_v2 import FAISSRAGEngine

async def test():
    rag = FAISSRAGEngine()
    await rag.initialize()
    
    # Add conversations
    await rag.add_conversation({
        'text': 'I want to eat pizza',
        'timestamp': '2024-01-15T10:00:00'
    })
    await rag.add_conversation({
        'text': 'I want to drink water',
        'timestamp': '2024-01-15T11:00:00'
    })
    await rag.add_conversation({
        'text': 'I need help with homework',
        'timestamp': '2024-01-15T12:00:00'
    })
    
    # Search similar
    results = await rag.search_similar('I want', k=5)
    
    print(f"✅ Found {len(results)} similar conversations:")
    for r in results:
        print(f"   - '{r['text']}' (score: {r['score']:.3f})")
    
    # Get predictions
    pred_result = await rag.predict('I want', k=10)
    print(f"\n✅ Predictions: {len(pred_result['predictions'])}")
    for p in pred_result['predictions'][:5]:
        print(f"   - '{p['text']}' (confidence: {p['confidence']:.2f})")
    
    # Save
    await rag.save()
    print("\n✅ Index saved successfully")

asyncio.run(test())
EOF

python3 test_rag.py
```

**Expected output:**
```
✅ Found 2 similar conversations:
   - 'I want to eat pizza' (score: 0.892)
   - 'I want to drink water' (score: 0.876)

✅ Predictions: 3
   - 'to' (confidence: 0.85)
   - 'eat' (confidence: 0.75)
   - 'drink' (confidence: 0.72)

✅ Index saved successfully
```

### Step 4: Start Enhanced Backend

```bash
# Option 1: Docker (Recommended)
cd PythonBackend
docker-compose down
docker-compose build
docker-compose up -d

# Check logs
docker-compose logs -f

# Option 2: Direct Python
cd PythonBackend/src
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

**Expected startup logs:**
```
🚀 Starting OpenVoice Backend...
✅ Phase 7 models loaded successfully
✅ Phase 8: Embedding service initialized
✅ Phase 8: FAISS RAG engine initialized
   Loaded 3 conversations
🎉 All services started successfully!
```

### Step 5: Test API Endpoints

```bash
# Health check
curl http://localhost:8000/health

# Expected:
# {
#   "status": "healthy",
#   "phase_7": {"models_loaded": true},
#   "phase_8": {
#     "embedding_service": true,
#     "rag_engine": true,
#     "conversations_loaded": 3
#   }
# }

# Add conversation
curl -X POST http://localhost:8000/api/v1/conversation/add \
  -H "Content-Type: application/json" \
  -d '{
    "text": "I want to go outside",
    "timestamp": "2024-01-15T14:00:00"
  }'

# Search similar
curl -X POST http://localhost:8000/api/v1/rag/v2/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "I want",
    "k": 5
  }'

# Get predictions
curl -X POST http://localhost:8000/api/v1/rag/v2/predict \
  -H "Content-Type: application/json" \
  -d '{
    "current_phrase": "I want",
    "max_predictions": 10
  }'

# Get statistics
curl http://localhost:8000/api/v1/rag/stats

# Get analytics
curl http://localhost:8000/api/v1/analytics/summary
curl http://localhost:8000/api/v1/analytics/words?n=20
```

---

## 📱 iOS Integration

### Step 1: Update APIService

Add to `Services/APIService.swift`:

```swift
// MARK: - Phase 8: Advanced RAG

func addConversation(text: String, timestamp: Date? = nil) async throws {
    let url = URL(string: "\(baseURL)/api/v1/conversation/add")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    
    let body: [String: Any] = [
        "text": text,
        "timestamp": (timestamp ?? Date()).ISO8601Format()
    ]
    
    request.httpBody = try JSONSerialization.data(withJSONObject: body)
    
    let (data, response) = try await URLSession.shared.data(for: request)
    
    guard let httpResponse = response as? HTTPURLResponse,
          httpResponse.statusCode == 200 else {
        throw APIError.requestFailed
    }
}

func searchSimilarConversations(
    query: String,
    k: Int = 20
) async throws -> [SimilarConversation] {
    let url = URL(string: "\(baseURL)/api/v1/rag/v2/search")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    
    let body: [String: Any] = [
        "query": query,
        "k": k,
        "use_temporal_weighting": true
    ]
    
    request.httpBody = try JSONSerialization.data(withJSONObject: body)
    
    let (data, _) = try await URLSession.shared.data(for: request)
    
    struct Response: Codable {
        let results: [SimilarConversation]
        let latency_ms: Double
    }
    
    let response = try JSONDecoder().decode(Response.self, from: data)
    return response.results
}

func getRAGPredictions(
    currentPhrase: String,
    useSemanticSearch: Bool = true
) async throws -> [Prediction] {
    let url = URL(string: "\(baseURL)/api/v1/rag/v2/predict")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    
    let body: [String: Any] = [
        "current_phrase": currentPhrase,
        "conversation_history": [],
        "k": 20,
        "max_predictions": 10
    ]
    
    request.httpBody = try JSONSerialization.data(withJSONObject: body)
    
    let (data, _) = try await URLSession.shared.data(for: request)
    
    struct Response: Codable {
        let predictions: [Prediction]
        let similar_contexts: [String]
        let num_contexts: Int
    }
    
    let response = try JSONDecoder().decode(Response.self, from: data)
    return response.predictions
}

struct SimilarConversation: Codable {
    let id: Int
    let text: String
    let score: Double
    let timestamp: String
}
```

### Step 2: Update PredictionViewModel

```swift
class PredictionViewModel: ObservableObject {
    @Published var predictions: [MLPrediction] = []
    private let apiService = APIService.shared
    
    func updatePredictionsWithRAG(currentPhrase: [Symbol]) async {
        guard currentPhrase.count > 0 else { return }
        
        // Check if backend is available
        if await apiService.checkHealth() {
            // Try Phase 8 semantic RAG
            do {
                let phraseText = currentPhrase.map { $0.label }.joined(separator: " ")
                let predictions = try await apiService.getRAGPredictions(
                    currentPhrase: phraseText,
                    useSemanticSearch: true
                )
                
                await MainActor.run {
                    self.predictions = predictions.map { pred in
                        MLPrediction(
                            symbolId: pred.text,
                            label: pred.text,
                            confidence: pred.confidence,
                            source: .rag
                        )
                    }
                }
                
                print("✅ Using Phase 8 semantic RAG predictions")
                return
                
            } catch {
                print("⚠️ Phase 8 RAG failed: \(error)")
            }
        }
        
        // Fallback to local CoreML
        await updatePredictionsLocal(currentPhrase)
    }
    
    func saveConversation(_ text: String) {
        Task {
            try? await apiService.addConversation(text: text)
        }
    }
}
```

### Step 3: Update ContentView

```swift
// In your main view where conversations are completed
func speakPhrase() {
    let text = currentPhrase.map { $0.label }.joined(separator: " ")
    
    // Speak
    SpeechService.shared.speak(text)
    
    // Save to RAG
    Task {
        try? await APIService.shared.addConversation(text: text)
    }
    
    // Clear phrase
    currentPhrase = []
}
```

---

## 🧪 Testing

### Unit Tests

```bash
cd PythonBackend

# Run tests
pytest tests/

# With coverage
pytest tests/ --cov=src --cov-report=html
```

### Integration Tests

```python
# tests/test_phase8_integration.py
import pytest
import asyncio
from src.models.embedding_service import EmbeddingService
from src.models.rag_engine_v2 import FAISSRAGEngine

@pytest.mark.asyncio
async def test_embedding_service():
    service = EmbeddingService()
    await service.initialize()
    
    embedding = await service.embed_text("test")
    assert embedding.shape == (384,)
    assert service.is_ready

@pytest.mark.asyncio
async def test_rag_engine():
    rag = FAISSRAGEngine()
    await rag.initialize()
    
    # Add conversation
    success = await rag.add_conversation({
        'text': 'I want water',
        'timestamp': '2024-01-15T10:00:00'
    })
    assert success
    
    # Search
    results = await rag.search_similar('I want', k=1)
    assert len(results) == 1
    assert results[0]['text'] == 'I want water'

@pytest.mark.asyncio
async def test_predictions():
    rag = FAISSRAGEngine()
    await rag.initialize()
    
    # Add training data
    for text in [
        "I want water",
        "I want food",
        "I need help"
    ]:
        await rag.add_conversation({'text': text})
    
    # Get predictions
    result = await rag.predict('I want')
    assert len(result['predictions']) > 0
```

### iOS Tests

```swift
// OpenVoiceTests/APIServiceTests.swift
func testPhase8RAG() async throws {
    let service = APIService.shared
    
    // Add conversation
    try await service.addConversation(text: "I want to play")
    
    // Search
    let similar = try await service.searchSimilarConversations(
        query: "I want",
        k: 5
    )
    
    XCTAssertGreaterThan(similar.count, 0)
    
    // Get predictions
    let predictions = try await service.getRAGPredictions(
        currentPhrase: "I want"
    )
    
    XCTAssertGreaterThan(predictions.count, 0)
}
```

---

## 🐛 Troubleshooting

### Issue: FAISS Installation Fails

**Problem:** `pip install faiss-cpu` fails

**Solutions:**

1. Use conda:
```bash
conda install -c conda-forge faiss-cpu
```

2. Install specific version:
```bash
pip install faiss-cpu==1.7.4 --no-cache-dir
```

3. On Apple Silicon Mac:
```bash
pip install faiss-cpu --no-binary :all:
```

### Issue: Out of Memory

**Problem:** Backend crashes with memory error

**Solutions:**

1. Reduce conversation limit:
```python
# In rag_engine_v2.py
rag = FAISSRAGEngine(max_conversations=10000)  # from 100000
```

2. Use memory-mapped index:
```python
# After loading
index = faiss.read_index('faiss.index', faiss.IO_FLAG_MMAP)
```

3. Increase Docker memory:
```yaml
# docker-compose.yml
services:
  backend:
    mem_limit: 4g
```

### Issue: Slow Embeddings

**Problem:** Embedding generation too slow

**Solutions:**

1. Use GPU:
```bash
pip install faiss-gpu
```

```python
# In embedding_service.py
SentenceTransformer(model_name, device='cuda')
```

2. Increase batch size:
```python
service = EmbeddingService(batch_size=64)  # from 32
```

3. Use smaller model:
```python
service = EmbeddingService(model_name='all-MiniLM-L12-v2')
```

### Issue: Low Prediction Accuracy

**Problem:** RAG predictions not relevant

**Solutions:**

1. Lower similarity threshold:
```python
rag = FAISSRAGEngine(similarity_threshold=0.6)  # from 0.7
```

2. Increase search results:
```python
results = await rag.search_similar(query, k=50)  # from 20
```

3. Disable temporal weighting:
```python
results = await rag.search_similar(
    query,
    use_temporal_weighting=False
)
```

---

## 📊 Performance Optimization

### Backend

```python
# 1. Increase workers
# docker-compose.yml
CMD ["uvicorn", "src.main:app", "--workers", "4"]

# 2. Enable caching
# Add Redis caching layer

# 3. Batch predictions
# Process multiple requests together

# 4. Use faster index
import faiss
index = faiss.IndexHNSWFlat(384, 32)  # Faster than IndexFlatL2
```

### iOS

```swift
// 1. Background prediction updates
Task.detached(priority: .background) {
    await updatePredictions()
}

// 2. Debounce API calls
var predictionTask: Task<Void, Never>?
predictionTask?.cancel()
predictionTask = Task {
    try? await Task.sleep(nanoseconds: 300_000_000)  // 300ms delay
    await updatePredictions()
}

// 3. Cache predictions locally
let cache = NSCache<NSString, PredictionResult>()
```

---

## 🎉 Verification Checklist

After integration, verify:

- [ ] Backend starts without errors
- [ ] Phase 8 services show as ready in `/health`
- [ ] Can add conversations via API
- [ ] Semantic search returns relevant results
- [ ] Predictions improve over time
- [ ] Index saves and loads correctly
- [ ] iOS app connects successfully
- [ ] Predictions display in prediction bar
- [ ] Analytics endpoints work
- [ ] No memory leaks

---

## 📚 Next Steps

After successful integration:

1. **Monitor Performance**
   - Check `/metrics` regularly
   - Monitor memory usage
   - Track prediction accuracy

2. **Gather Data**
   - Encourage users to try the app
   - Collect conversations
   - Build training dataset

3. **Optimize Models**
   - Analyze usage patterns
   - Fine-tune similarity thresholds
   - Add domain-specific features

4. **Plan Phase 9**
   - BERT sentence formation
   - Advanced grammar
   - Transformer models

---

**Phase 8 Integration Complete!** 🎉

You now have a production-grade semantic RAG system!

Next: `PHASE_8_COMPLETE.md` for summary and celebration! 🚀
