//
//  ContentView.swift
//  OpenVoice
//
//  Main navigation and app structure
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var appState: AppState
    @State private var showSettings = false
    @State private var showCalibration = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Top bar with phrase display
                PhraseBarView()
                
                // Main symbol grid
                SymbolGridView()
                
                // Prediction bar (if enabled)
                if appState.settings.showPredictions {
                    PredictionBarView()
                }
            }
            .navigationTitle("OpenVoice")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    if !appState.isCalibrated && appState.settings.eyeTrackingEnabled {
                        Button(action: { showCalibration = true }) {
                            Label("Calibrate", systemImage: "eye")
                                .foregroundColor(.orange)
                        }
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showSettings = true }) {
                        Label("Settings", systemImage: "gearshape")
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView()
                    .environmentObject(appState)
            }
            .sheet(isPresented: $showCalibration) {
                CalibrationView(isPresented: $showCalibration)
                    .environmentObject(appState)
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(AppState())
    }
}
