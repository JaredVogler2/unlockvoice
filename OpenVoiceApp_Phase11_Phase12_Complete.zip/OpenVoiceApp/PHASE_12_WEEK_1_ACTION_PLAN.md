# 🚀 PHASE 12 - WEEK 1 ACTION PLAN

## 🎯 Week 1 Goal: Working Xcode Project

By end of week, you will have:
- ✅ Xcode project that builds
- ✅ All Swift files imported
- ✅ App runs on simulator
- ✅ Clean architecture

**Time required**: 8-12 hours  
**Can be done in**: 1-2 days of focused work

---

## 📋 DAY 1: Create Xcode Project (2-3 hours)

### Step 1: Create New Project (10 minutes)

1. **Open Xcode**
   ```
   Launch Xcode (install from App Store if needed)
   ```

2. **Create Project**
   ```
   File > New > Project
   
   Platform: iOS
   Template: App
   Click: Next
   ```

3. **Configure Project**
   ```
   Product Name: OpenVoice
   Team: Select your Apple ID (or add account)
   Organization Identifier: com.yourname.openvoice
   Bundle Identifier: (auto-filled, e.g., com.yourname.openvoice.OpenVoice)
   Interface: SwiftUI
   Language: Swift
   Storage: None (we'll add Core Data manually)
   Include Tests: Yes
   
   Click: Next
   ```

4. **Save Location**
   ```
   Choose location: ~/Developer/OpenVoice
   Create Git repository: Yes
   Click: Create
   ```

5. **Initial Test**
   ```
   Press Cmd+R to run
   Should see "Hello, world!" on simulator
   If it works, you're good! ✅
   ```

---

### Step 2: Set Up Project Structure (20 minutes)

1. **Delete Default Files**
   ```
   In Xcode Project Navigator (left sidebar):
   - Right-click ContentView.swift > Delete > Move to Trash
   - We'll replace with our own
   ```

2. **Create Folder Groups**
   ```
   Right-click "OpenVoice" folder > New Group
   Create these groups:
   
   OpenVoice/
   ├── App/
   ├── Models/
   ├── Views/
   ├── ViewModels/
   ├── Services/
   ├── Core/
   └── Resources/
   ```

3. **Set Deployment Target**
   ```
   Click "OpenVoice" (top of navigator)
   Under "Deployment Info":
   - iOS Deployment Target: 15.0
   - iPhone: Check all
   - iPad: Check all
   - Orientation: Portrait, Landscape Left, Landscape Right
   ```

---

### Step 3: Configure Info.plist (15 minutes)

1. **Open Info.plist**
   ```
   In Project Navigator: OpenVoice/Info.plist
   (Might be in Supporting Files or root)
   ```

2. **Add Privacy Permissions**
   ```
   Click "+" to add new keys:
   
   Key: Privacy - Camera Usage Description
   Value: OpenVoice uses the camera for eye tracking to enable hands-free communication.
   
   Key: Privacy - Photo Library Usage Description  
   Value: OpenVoice needs access to import photos as custom communication symbols.
   
   Key: Privacy - Photo Library Additions Usage Description
   Value: OpenVoice needs access to save custom symbols to your photo library.
   
   Key: Privacy - Face ID Usage Description
   Value: OpenVoice uses face tracking for precise eye gaze detection.
   ```

3. **Add Background Modes**
   ```
   Key: Required background modes
   Type: Array
   Add item: audio
   (Allows speech to continue in background)
   ```

4. **Set App Category**
   ```
   Key: Application Category Type
   Value: public.app-category.medical
   ```

---

### Step 4: Add Core Frameworks (10 minutes)

1. **Add Framework Dependencies**
   ```
   Click "OpenVoice" project (top)
   Select "OpenVoice" target
   Go to "Frameworks, Libraries, and Embedded Content"
   Click "+" and add:
   
   - AVFoundation.framework
   - ARKit.framework
   - CoreData.framework
   - CoreML.framework
   - Vision.framework
   - Photos.framework
   ```

---

## 📋 DAY 2: Import Swift Files (3-4 hours)

### Step 5: Prepare Source Files (30 minutes)

1. **Extract Your Project**
   ```bash
   # Unzip the phase 11 package
   cd ~/Downloads
   unzip OpenVoiceApp_Phase11_Complete.zip
   cd OpenVoiceApp
   ```

2. **Review File Structure**
   ```bash
   # See what we have
   find . -name "*.swift" -type f
   
   # Should see 45 Swift files
   ```

3. **Copy to Organized Location**
   ```bash
   # Create working directory
   mkdir -p ~/Desktop/OpenVoice_Source
   
   # Copy Swift files organized by type
   cp -r Models/ ~/Desktop/OpenVoice_Source/
   cp -r Views/ ~/Desktop/OpenVoice_Source/
   cp -r ViewModels/ ~/Desktop/OpenVoice_Source/
   cp -r Services/ ~/Desktop/OpenVoice_Source/
   cp -r Core/ ~/Desktop/OpenVoice_Source/
   cp -r ML/ ~/Desktop/OpenVoice_Source/
   cp Info.plist ~/Desktop/OpenVoice_Source/
   cp OpenVoiceApp.swift ~/Desktop/OpenVoice_Source/
   cp ContentView.swift ~/Desktop/OpenVoice_Source/
   ```

---

### Step 6: Import Files into Xcode (60 minutes)

**Important**: Add files one group at a time to avoid overwhelming errors

1. **Add App Files First**
   ```
   Drag these into App/ group:
   - OpenVoiceApp.swift
   - ContentView.swift
   
   In dialog:
   ☑ Copy items if needed
   ☑ Create groups
   ☑ Add to target: OpenVoice
   Click: Finish
   ```

2. **Add Models**
   ```
   Drag Models/ folder into Models/ group:
   - Symbol.swift
   - Phrase.swift
   - UserProfile.swift
   - AppSettings.swift
   - GeneratedImage.swift (if exists)
   
   Same options as above
   ```

3. **Add Services**
   ```
   Drag Services/ folder into Services/ group:
   - SpeechService.swift
   - SymbolLibraryService.swift
   - HapticManager.swift
   - APIService.swift
   - LocalLLMService.swift
   - ImageGenerationService.swift (if exists)
   - Persistence/ folder (all CoreData files)
   ```

4. **Add ViewModels**
   ```
   Drag ViewModels/ folder:
   - SymbolGridViewModel.swift
   - PredictionViewModel.swift
   - SymbolBrowserViewModel.swift
   - CustomSymbolEditorViewModel.swift
   - ImageGeneratorViewModel.swift (if exists)
   ```

5. **Add Views**
   ```
   Drag Views/ folder:
   - All view files
   - Components/ subfolder
   - EyeTracking/ subfolder
   - Analytics/ subfolder
   ```

6. **Add Core**
   ```
   Drag Core/ folder:
   - EyeTracking/ subfolder
   - Calibration/ subfolder
   ```

7. **Add ML**
   ```
   Drag ML/ folder:
   - MLPredictionService.swift
   - Training/ subfolder
   - Models/ subfolder (if .mlmodel files exist)
   ```

---

### Step 7: Fix Build Errors (60 minutes)

**Expected errors**: Import statements, missing Core Data model, etc.

1. **Build the Project**
   ```
   Press Cmd+B
   
   You'll see errors - this is NORMAL
   We'll fix them systematically
   ```

2. **Common Error #1: Core Data Model Missing**
   ```
   Error: "Cannot find type 'NSManagedObject' in scope"
   
   Fix:
   File > New > File
   Choose: Core Data > Data Model
   Name: OpenVoice.xcdatamodeld
   Save in: OpenVoice/Resources/
   
   Add entities:
   - ConversationEntity
   - SymbolUsageEntity
   - SessionEntity
   - UserSymbolEntity
   
   (Copy attributes from Models/CoreData/ files)
   ```

3. **Common Error #2: Bundle Resources**
   ```
   Error: "Cannot find 'Bundle.main.url' for resource"
   
   Fix:
   Add to Build Phases > Copy Bundle Resources:
   - Any .json files
   - Any .mlmodel files
   - Info.plist
   ```

4. **Common Error #3: SwiftUI Previews**
   ```
   Error: "Cannot preview in current scheme"
   
   Fix:
   Comment out all #Preview blocks temporarily:
   // #Preview {
   //     ContentView()
   // }
   ```

5. **Fix Import Statements**
   ```swift
   // If you see errors about missing imports, add:
   import SwiftUI
   import AVFoundation
   import ARKit
   import CoreData
   import CoreML
   import Combine
   import Photos
   ```

---

## 📋 DAY 3: Create Basic Assets (2-3 hours)

### Step 8: Create Assets Catalog (30 minutes)

1. **Create Assets.xcassets**
   ```
   File > New > File
   Choose: Asset Catalog
   Name: Assets
   Save in: OpenVoice/Resources/
   ```

2. **Create App Icon Set**
   ```
   In Assets.xcassets:
   Right-click > App Icons & Launch Images > New iOS App Icon
   
   You'll see slots for all icon sizes
   (We'll fill these in Week 2)
   ```

3. **Create Color Set**
   ```
   Right-click Assets.xcassets > New Color Set
   Name: AccentColor
   
   Set to blue or your brand color
   This is used throughout the app
   ```

4. **Create Symbol Folder**
   ```
   Right-click Assets.xcassets > New Folder
   Name: Symbols
   
   This will hold symbol images in Week 2
   ```

---

### Step 9: Test Build (15 minutes)

1. **Clean Build**
   ```
   Product > Clean Build Folder (Cmd+Shift+K)
   Product > Build (Cmd+B)
   ```

2. **Fix Remaining Errors**
   ```
   Go through each error:
   - Missing imports? Add them
   - Missing files? Check they're added to target
   - Core Data issues? Verify model is in target
   ```

3. **Run on Simulator**
   ```
   Select simulator: iPhone 15 Pro
   Press Cmd+R
   
   App should launch!
   May have UI issues - that's OK for now
   ```

---

### Step 10: Make Backend Optional (60 minutes)

**CRITICAL**: App must work without Python backend

1. **Update LocalLLMService.swift**
   ```swift
   // Find LocalLLMService class
   // Add at top:
   
   class LocalLLMService {
       static let shared = LocalLLMService()
       
       // Add this property
       @Published var isAvailable: Bool = false
       
       private var healthCheckTimer: Timer?
       
       init() {
           // Check if backend is running
           checkBackendAvailability()
           
           // Check periodically
           healthCheckTimer = Timer.scheduledTimer(
               withTimeInterval: 30.0,
               repeats: true
           ) { [weak self] _ in
               self?.checkBackendAvailability()
           }
       }
       
       private func checkBackendAvailability() {
           Task {
               do {
                   let url = URL(string: "\(baseURL)/health")!
                   let (_, response) = try await URLSession.shared.data(from: url)
                   
                   if let httpResponse = response as? HTTPURLResponse,
                      httpResponse.statusCode == 200 {
                       await MainActor.run {
                           self.isAvailable = true
                       }
                   } else {
                       await MainActor.run {
                           self.isAvailable = false
                       }
                   }
               } catch {
                   await MainActor.run {
                       self.isAvailable = false
                   }
               }
           }
       }
       
       // Update enhance method to check availability
       func enhance(symbols: [String]) async throws -> EnhancedCommunication {
           guard isAvailable else {
               // Fallback: just join symbols with proper grammar
               return EnhancedCommunication(
                   sentence: symbols.joined(separator: " ").capitalized + ".",
                   suggestions: [],
                   intent: .statement,
                   urgency: .normal,
                   confidence: 0.5
               )
           }
           
           // Original implementation when backend available
           // ... existing code ...
       }
   }
   ```

2. **Update Settings to Show Backend Status**
   ```swift
   // In SettingsView.swift, add:
   
   Section("Advanced Features") {
       HStack {
           Text("LLM Backend")
           Spacer()
           if LocalLLMService.shared.isAvailable {
               Text("Connected")
                   .foregroundColor(.green)
           } else {
               Text("Not Available")
                   .foregroundColor(.gray)
           }
       }
       
       if !LocalLLMService.shared.isAvailable {
           Text("For advanced LLM features, run the Python backend. See documentation for setup.")
               .font(.caption)
               .foregroundColor(.secondary)
       }
   }
   ```

3. **Test Without Backend**
   ```
   Make sure Python backend is NOT running
   Run app (Cmd+R)
   Test symbol selection and speech
   Should work perfectly without LLM features
   ```

---

## 📋 Checklist: Week 1 Complete

By end of Week 1, you should have:

- [ ] Xcode project created and configured
- [ ] All 45 Swift files imported
- [ ] Info.plist configured with permissions
- [ ] Frameworks added (AVFoundation, ARKit, etc.)
- [ ] Assets.xcassets created with placeholders
- [ ] Core Data model created
- [ ] Project builds without errors (Cmd+B succeeds)
- [ ] App runs on simulator
- [ ] Backend made optional (app works standalone)
- [ ] Basic testing done (symbols, speech work)

---

## 🐛 Troubleshooting

### Build Fails with "Module not found"
```
Solution: 
1. Check target membership (select file, check right panel)
2. Clean build folder (Cmd+Shift+K)
3. Restart Xcode
```

### App Crashes on Launch
```
Solution:
1. Check console for error message
2. Usually Core Data model misconfiguration
3. Or missing required framework
```

### "Cannot find type in scope"
```
Solution:
1. Missing import statement
2. File not added to target
3. Check spelling of type name
```

### Simulator Won't Launch
```
Solution:
1. Try different simulator (iPhone 14 Pro)
2. Restart Xcode
3. Reset simulator: Device > Erase All Content
```

---

## 📊 Success Metrics

### End of Week 1
- ✅ Clean build (0 errors)
- ✅ App launches
- ✅ Can select symbols
- ✅ Speech works
- ✅ Settings accessible
- ✅ No crashes

**If all above = SUCCESS!** 🎉

---

## 🎯 Week 2 Preview

Next week you'll:
1. Design app icon
2. Get 70+ symbol images
3. Capture screenshots
4. Polish UI

But first, **complete Week 1!**

---

## 💡 Pro Tips

1. **Commit Often**
   ```bash
   git add .
   git commit -m "Initial Xcode project setup"
   ```

2. **Use Xcode Snapshots**
   ```
   File > Create Snapshot
   Name: "Week 1 Complete"
   (Saves current state, can restore if needed)
   ```

3. **Test on Real Device**
   ```
   If you have iPhone/iPad:
   - Connect via USB
   - Trust device
   - Select in Xcode
   - Run (eye tracking needs real device!)
   ```

4. **Don't Add Features**
   ```
   Tempting to improve things
   But resist! Just get it building
   Week 1 = Foundation only
   ```

---

## 📞 Need Help?

### Stuck on Step?
- Re-read the step carefully
- Check Xcode console for specific error
- Google the exact error message
- Apple Developer Forums

### General Questions?
- Review PHASE_12_APP_STORE_RELEASE.md
- Check previous phase docs
- Stack Overflow (tag: swift, swiftui, xcode)

### Really Stuck?
- Create minimal test project
- Try step in isolation
- Compare to working project
- Ask specific question on forums

---

## 🚀 Let's Go!

**You're about to create the Xcode project that will ship to the App Store!**

This is exciting! Take your time, follow each step, and you'll have a working project by end of week.

**Ready? Start with Day 1, Step 1!** 🎯

---

*Phase 12 - Week 1 Action Plan*  
*Version: 1.0.0*  
*Date: October 13, 2025*  
*Status: 🚀 LET'S BUILD!*
