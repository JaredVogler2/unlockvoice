# 📱 OpenVoice - Free AAC Communication App

**Version 1.3.0** | **Phase 3 Complete** | **GPL v3.0** | **iOS 15.0+**

A free, open-source AAC (Augmentative and Alternative Communication) application for non-verbal autistic individuals.

**"Every person deserves a voice. No prescriptions. No gatekeepers."**

---

## 🎯 Mission

Traditional AAC devices cost **$15,000+**, require prescriptions, and are locked behind insurance gatekeepers. **OpenVoice changes that.**

This is a **completely free**, **open-source** AAC app that anyone can download and use immediately. No doctors. No insurance. No barriers. Just communication.

---

## ✨ What You Get (Phases 1-3 Complete)

### **Phase 1: Foundation** ✅
- Professional MVVM architecture with SwiftUI
- Symbol-based communication grid (4x6 default layout)
- Phrase building system with real-time display
- Text-to-speech with all iOS system voices
- Customizable speech rate (20%-100%) and pitch (50%-200%)
- User profiles and comprehensive settings
- Prediction bar (ready for AI in Phase 6)

### **Phase 2: Symbol Library** ✅
- **70+ built-in symbols** across 11 categories:
  - People, Actions, Food, Feelings, Places, Things
  - Descriptors, Questions, Time, Numbers, General
- **Symbol browser** with powerful search
- **Category filtering** for quick access
- **Favorites system** - star your most-used symbols
- **Recent symbols** tracking
- **Custom symbol creation** - use camera or photo library
- **Image editing** - crop and adjust photos
- **Unlimited expansion** - create as many symbols as needed

### **Phase 3: Speech Enhancement** ✅
- **Quick phrase templates** - 24 built-in + unlimited custom
  - 6 categories: Greetings, Requests, Responses, Feelings, Social, Emergency
  - One-tap communication for common phrases
- **Pronunciation dictionary** - fix any mispronounced word
  - Custom pronunciations for names, acronyms, technical terms
  - Pre-loaded with AAC, iOS, iPad pronunciations
  - Test before saving
- **Speech history** - save and replay last 100 phrases
  - Search by text
  - Filter by time (All, Today, This Week, This Month)
  - Full metadata (voice, rate, pitch, timestamp)
  - Export to text file
- **Haptic feedback** - tactile responses throughout app
- **Speech queue** - queue multiple phrases
- **Volume control** - independent speech volume

---

## 🚀 Quick Start (30 Minutes)

### Prerequisites
- Mac with Xcode 14+ installed
- iPhone/iPad running iOS 15.0+ (or Simulator)
- No developer account needed for testing!

### Setup Steps

1. **Download the project**
   ```bash
   # Clone or download this repository
   git clone https://github.com/openvoice/openvoice.git
   cd openvoice
   ```

2. **Open in Xcode**
   - Double-click `OpenVoice.xcodeproj` (or create new project and add files)
   - Or: File → Open → Select the OpenVoiceApp folder

3. **Configure project**
   - Select your target device/simulator
   - Ensure iOS Deployment Target is 15.0 or higher

4. **Build and run**
   - Click Play button (▶) or press ⌘R
   - App launches on your device/simulator!

**📘 See QUICK_START.md for detailed instructions**

---

## 🎮 How to Use

### Basic Communication
1. **Tap symbols** on the main grid to build your phrase
2. Watch your phrase appear in the **top bar**
3. Tap **"Speak"** button to hear it spoken
4. Use **"Clear"** to start over, **"Delete"** to remove last symbol

### Browse Symbol Library
1. Tap **"Browse Library"** button on main screen
2. **Search** for specific symbols
3. **Filter** by category using chips at top
4. **Long-press** any symbol to add to favorites
5. **Tap** symbol to add to current phrase

### Create Custom Symbols
1. In Symbol Browser, tap **"+"** button
2. Choose **Camera** (take photo) or **Photos** (select existing)
3. Capture/select image of person, object, or place
4. **Crop** the image as needed
5. Enter a **label** (what it says when selected)
6. Choose a **category**
7. Add **tags** (optional, helps with search)
8. **Save** - your symbol is now in the library!

### Use Quick Phrases
1. Open **Settings** → **Speech Enhancement** → **Quick Phrases**
2. Browse 24 built-in templates across 6 categories
3. **Tap** any phrase to speak it immediately
4. Create **custom templates** for your frequently-used phrases
5. Templates appear in your selected category

### Fix Pronunciations
1. Open **Settings** → **Speech Enhancement** → **Pronunciation Dictionary**
2. Tap **"+"** to add new pronunciation
3. Enter **word** as it appears: "AAC"
4. Enter **how to say it**: "A A C"
5. **Test** to hear it, then **Save**
6. From now on, "AAC" will always be pronounced "A A C"

### Review History
1. Open **Settings** → **Speech Enhancement** → **Speech History**
2. See all phrases you've spoken (up to 100)
3. **Search** to find specific phrases
4. **Filter** by time period
5. Tap **play button** to replay any phrase
6. **Export** your history to text file

---

## 📊 Current Capabilities

### Communication
- ✅ 70+ symbols across 11 categories
- ✅ Unlimited custom symbols
- ✅ Phrase building up to 20 words
- ✅ Natural speech output
- ✅ All iOS system voices

### Personalization
- ✅ Speech rate: 20%-100%
- ✅ Pitch: 50%-200%
- ✅ Volume control
- ✅ Voice selection (all English voices)
- ✅ Grid size: 2-6 columns
- ✅ Symbol size: Small, Medium, Large, Extra Large
- ✅ High contrast mode
- ✅ Haptic feedback toggle

### Organization
- ✅ Favorites system
- ✅ Recent symbols
- ✅ Category filtering
- ✅ Powerful search
- ✅ Custom categories (coming in Phase 5)

### Quick Access
- ✅ 24 phrase templates
- ✅ Custom templates
- ✅ 100-phrase history
- ✅ Pronunciation dictionary
- ✅ Export capabilities

---

## 📁 Project Structure

```
OpenVoiceApp/
│
├── 📄 OpenVoiceApp.swift          # App entry point & global state
├── 📄 ContentView.swift           # Main navigation
├── 📄 Info.plist                  # iOS configuration
│
├── 📂 Models/ (4 files)
│   ├── Symbol.swift               # Symbol data structure
│   ├── Phrase.swift               # Phrase building logic
│   ├── UserProfile.swift          # User profiles & calibration
│   └── AppSettings.swift          # App configuration (Phase 3)
│
├── 📂 Views/ (13 files)
│   ├── SymbolGridView.swift      # Main communication grid
│   ├── PhraseBarView.swift       # Phrase display & controls
│   ├── PredictionBarView.swift   # AI predictions (Phase 6+)
│   ├── SettingsView.swift        # Settings interface
│   ├── CalibrationView.swift     # Eye tracking setup (Phase 4)
│   ├── SymbolBrowserView.swift   # Symbol library browser
│   ├── CustomSymbolEditorView.swift  # Symbol creator
│   ├── PhraseTemplatesView.swift     # Quick phrases (Phase 3)
│   ├── PronunciationDictionaryView.swift  # Pronunciations (Phase 3)
│   ├── SpeechHistoryView.swift       # History viewer (Phase 3)
│   └── Components/
│       └── SearchBar.swift           # Reusable search (Phase 3)
│
├── 📂 ViewModels/ (4 files)
│   ├── SymbolGridViewModel.swift
│   ├── PredictionViewModel.swift
│   ├── SymbolBrowserViewModel.swift
│   └── CustomSymbolEditorViewModel.swift
│
├── 📂 Services/ (3 files)
│   ├── SpeechService.swift       # Enhanced TTS (Phase 3)
│   ├── SymbolLibraryService.swift # Symbol management
│   └── HapticManager.swift       # Haptic feedback (Phase 3)
│
└── 📂 Documentation/ (7 files)
    ├── README.md                 # This file
    ├── QUICK_START.md            # Setup guide
    ├── DEVELOPMENT_PLAN.md       # 12-phase roadmap
    ├── PROJECT_STATUS.md         # Current status
    ├── PHASE_1_COMPLETE.md       # Phase 1 summary
    ├── PHASE_2_COMPLETE.md       # Phase 2 summary
    └── PHASE_3_COMPLETE.md       # Phase 3 summary
```

**34 Swift files | ~7,300 lines of code | Fully documented**

---

## 🔮 Upcoming Features (Phases 4-12)

### **Phase 4: ARKit Eye Tracking** (Next - Most Complex)
- Face tracking with ARKit
- Eye gaze detection
- 9-point calibration
- Dwell-time selection
- Hands-free communication
- **Estimated**: 3 weeks

### **Phase 5: Data Persistence**
- Core Data database
- Conversation history
- Cloud sync (optional)
- Backup/restore
- **Estimated**: 2 weeks

### **Phase 6: CoreML Integration**
- On-device ML models
- Word prediction
- Next-word suggestions
- Usage learning
- **Estimated**: 2 weeks

### **Phase 7: Python Backend**
- FastAPI server
- REST API endpoints
- ML model hosting
- **Estimated**: 2 weeks

### **Phase 8: RAG System**
- FAISS vector database
- Context-aware predictions
- Personalized suggestions
- **Estimated**: 3 weeks

### **Phase 9: BERT Sentences**
- Grammar correction
- Natural language generation
- **Estimated**: 2 weeks

### **Phase 10: Local LLM**
- MLX framework
- Mistral 7B on Apple Silicon
- Advanced AI understanding
- **Estimated**: 3 weeks

### **Phase 11: Image Generation**
- Stable Diffusion integration
- AI-generated custom symbols
- **Estimated**: 2 weeks

### **Phase 12: App Store Release** 🚀
- App Store submission
- Screenshots & marketing
- Documentation & support
- **Estimated**: 4 weeks

**Total Timeline**: ~6-8 months from start to App Store

See **DEVELOPMENT_PLAN.md** for complete details.

---

## 🎓 Technical Specifications

### Requirements
- **iOS**: 15.0 or later
- **Xcode**: 14.0 or later
- **Swift**: 5.5 or later
- **Framework**: SwiftUI
- **Architecture**: MVVM with Combine

### Device Support
- **iPhone**: iPhone 8 and newer
- **iPad**: All iPads with A10 or newer
- **iPod Touch**: 7th generation
- **Mac**: Apple Silicon with iOS app support

### Performance
- **Launch**: < 2 seconds
- **Symbol selection**: < 100ms
- **Speech start**: < 200ms
- **Search**: < 100ms
- **60 FPS**: Maintained throughout

### Storage
- **App size**: ~5MB
- **User data**: ~50KB typical
- **Custom symbols**: ~100KB each
- **Total**: ~10-20MB typical installation

---

## 🤝 Contributing

OpenVoice is **open source** (GPL v3.0). We welcome contributions!

### Ways to Help

1. **Code Contributions**
   - Submit PRs for features or bug fixes
   - Follow SwiftUI and MVVM patterns
   - Add unit tests when possible
   - Document your changes

2. **Symbol Packs**
   - Create themed symbol sets
   - Translate to other languages
   - Add cultural symbols

3. **Testing & Feedback**
   - Report bugs via GitHub Issues
   - Suggest new features
   - Test on different devices
   - Provide user feedback

4. **Documentation**
   - Improve guides and tutorials
   - Add examples
   - Translate documentation
   - Create video tutorials

5. **Community**
   - Answer questions
   - Help new users
   - Share success stories
   - Spread the word

### Development Guidelines
- Follow Apple's Human Interface Guidelines
- Maintain accessibility standards
- Keep it free forever (no ads, IAP, subscriptions)
- Respect user privacy (no tracking, no data collection)
- Document all code
- Test on real devices

---

## 📚 Learning Resources

### SwiftUI & iOS Development
- [Apple's SwiftUI Tutorials](https://developer.apple.com/tutorials/swiftui)
- [100 Days of SwiftUI](https://www.hackingwithswift.com/100/swiftui)
- [SwiftUI by Example](https://www.hackingwithswift.com/quick-start/swiftui)
- [Apple Developer Documentation](https://developer.apple.com/documentation/)

### AAC & Accessibility
- [AAC Institute](https://aacinstitute.org)
- [Apple Accessibility](https://www.apple.com/accessibility/)
- [ISAAC (International Society for AAC)](https://www.isaac-online.org)
- [Mulberry Symbols](https://www.mulberrysymbols.org/)

### ARKit (For Phase 4)
- [Apple ARKit Documentation](https://developer.apple.com/augmented-reality/arkit/)
- [ARKit Face Tracking](https://developer.apple.com/documentation/arkit/tracking_and_visualizing_faces)

---

## ⚠️ Important Notes

### Free Forever
This app will **always be free**:
- ✅ No ads
- ✅ No in-app purchases
- ✅ No subscriptions
- ✅ No data collection
- ✅ No tracking

### Privacy First
- All data stored locally on device
- No server communication (except optional Phase 7+ features)
- No analytics or tracking
- No personal data collection
- User owns all their data

### Medical Device Status
By keeping this as **free software**:
- ✅ No FDA approval needed
- ✅ No prescription required
- ✅ No insurance hassles
- ✅ Direct download and use
- ✅ True accessibility for all

This is **not a medical device**. It's a free communication tool. That's what makes it accessible.

---

## 🐛 Troubleshooting

### Build Issues
**App won't build?**
- Ensure all files are added to Xcode target
- Check iOS Deployment Target is 15.0+
- Clean build: Product → Clean Build Folder (⇧⌘K)
- Delete derived data: ~/Library/Developer/Xcode/DerivedData

### Symbol Issues
**Symbols not showing?**
- Phase 1-2 uses SF Symbols + emoji (built into iOS)
- Custom symbols require Phase 2
- Check symbol names match SF Symbols library

### Speech Issues
**Speech not working?**
- Check device volume
- Ensure not in silent mode (check switch on iPhone)
- Try different voices in Settings → Speech → Voice Selection
- Test with simple phrase like "Hello"
- Check Info.plist has speech permissions (not required for TTS, but good practice)

### Camera Issues (Custom Symbols)
**Camera not working?**
- Add camera permission to Info.plist
- Test on physical device (simulator has no camera)
- Grant permission when prompted
- Check Settings → Privacy → Camera

### General Issues
**App crashing?**
- Check Xcode console for error messages
- Verify all files are properly added
- Try running on different device/simulator
- Check iOS version is 15.0+

**Need Help?**
- GitHub Issues: [Report a bug](https://github.com/openvoice/openvoice/issues)
- Discord: [Join community](https://discord.gg/openvoice)
- Email: support@openvoice.app

---

## 📊 Project Stats

- **Lines of Code**: ~7,300
- **Files**: 34 Swift files
- **Symbols**: 70+ built-in
- **Templates**: 24 built-in phrases
- **History**: 100 phrases
- **Documentation**: 7 comprehensive guides
- **Phases Complete**: 3 of 12
- **Development Time**: ~5 weeks
- **Contributors**: Open to all!

---

## 🙏 Acknowledgments

**OpenVoice** is inspired by and built for:

- The non-verbal autistic community
- Speech-language pathologists
- Families seeking affordable AAC solutions
- Open-source accessibility advocates
- Everyone who believes communication is a human right

**Special Thanks**:
- Mulberry Symbol Project (CC BY-SA symbols)
- Apple's accessibility teams
- The AAC Institute
- Open-source community

---

## 📜 License

**OpenVoice** is licensed under **GPL v3.0**

```
Copyright (C) 2025 OpenVoice Contributors

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
```

Full license: [GPL-3.0](https://www.gnu.org/licenses/gpl-3.0.html)

---

## 🚀 Get Started Now!

1. **Download**: Clone or download this repository
2. **Read**: Check out QUICK_START.md
3. **Build**: Open in Xcode and run
4. **Test**: Try all the features
5. **Customize**: Make it your own
6. **Share**: Help others communicate

---

## 📞 Contact & Community

- **Website**: https://openvoice.app
- **GitHub**: https://github.com/openvoice/openvoice
- **Discord**: https://discord.gg/openvoice
- **Email**: support@openvoice.app
- **Twitter**: @openvoiceapp

---

**"Every person deserves a voice."**

**Phase 3 Complete. Phase 4 Next: Eye Tracking!** 👁️

Built with ❤️ for accessibility by the open-source community.

---

*Version 1.3.0 | Last Updated: October 13, 2025 | Phase 3 Complete*
