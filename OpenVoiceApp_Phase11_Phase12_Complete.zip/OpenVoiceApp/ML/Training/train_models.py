#!/usr/bin/env python3
"""
OpenVoice - CoreML Model Training Script
Phase 6: Train prediction models from user data

This script trains CoreML models for on-device predictions:
1. N-gram model for sequential predictions
2. Contextual model for time/usage-based predictions
3. Frequency model for most-used symbols

Requirements:
pip install coremltools scikit-learn pandas numpy
"""

import coremltools as ct
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import LabelEncoder
from typing import List, Dict, Tuple
import json
from pathlib import Path
from datetime import datetime

class AAC_ModelTrainer:
    """Train CoreML models for AAC predictions"""
    
    def __init__(self, data_path: str = "training_data/conversations.json"):
        self.data_path = Path(data_path)
        self.conversations = []
        self.symbols = []
        self.n_gram_data = {}
        
    def load_conversation_data(self) -> bool:
        """Load conversation history from exported JSON"""
        try:
            if not self.data_path.exists():
                print(f"⚠️  No training data found at {self.data_path}")
                print("   Creating sample data for demonstration...")
                self._create_sample_data()
                return True
                
            with open(self.data_path, 'r') as f:
                data = json.load(f)
                
            self.conversations = data.get('conversations', [])
            self.symbols = data.get('symbols', [])
            
            print(f"✅ Loaded {len(self.conversations)} conversations")
            print(f"✅ Loaded {len(self.symbols)} unique symbols")
            return True
            
        except Exception as e:
            print(f"❌ Error loading data: {e}")
            return False
    
    def _create_sample_data(self):
        """Create sample training data for demonstration"""
        self.conversations = [
            {"text": "i want water", "symbols": ["i", "want", "water"], "timestamp": "2025-01-01T10:30:00Z"},
            {"text": "i want food", "symbols": ["i", "want", "food"], "timestamp": "2025-01-01T12:00:00Z"},
            {"text": "i need help", "symbols": ["i", "need", "help"], "timestamp": "2025-01-01T14:30:00Z"},
            {"text": "thank you", "symbols": ["thank", "you"], "timestamp": "2025-01-01T15:00:00Z"},
            {"text": "i feel happy", "symbols": ["i", "feel", "happy"], "timestamp": "2025-01-01T16:00:00Z"},
            {"text": "go home", "symbols": ["go", "home"], "timestamp": "2025-01-01T17:30:00Z"},
            {"text": "good morning", "symbols": ["good", "morning"], "timestamp": "2025-01-02T08:00:00Z"},
            {"text": "i want breakfast", "symbols": ["i", "want", "breakfast"], "timestamp": "2025-01-02T08:30:00Z"},
            {"text": "play game", "symbols": ["play", "game"], "timestamp": "2025-01-02T10:00:00Z"},
            {"text": "i am tired", "symbols": ["i", "am", "tired"], "timestamp": "2025-01-02T20:00:00Z"},
        ]
        
        self.symbols = [
            {"id": "sym_i", "label": "i", "category": "pronouns", "usage_count": 50},
            {"id": "sym_want", "label": "want", "category": "verbs", "usage_count": 45},
            {"id": "sym_water", "label": "water", "category": "food_drink", "usage_count": 30},
            {"id": "sym_food", "label": "food", "category": "food_drink", "usage_count": 28},
            {"id": "sym_help", "label": "help", "category": "verbs", "usage_count": 25},
        ]
    
    def build_ngram_model(self, n: int = 2) -> Dict:
        """Build n-gram frequency table"""
        print(f"\n🔨 Building {n}-gram model...")
        
        ngrams = {}
        
        for conv in self.conversations:
            symbols = conv.get('symbols', [])
            
            # Create n-grams
            for i in range(len(symbols) - n + 1):
                context = tuple(symbols[i:i+n-1])
                next_symbol = symbols[i+n-1]
                
                if context not in ngrams:
                    ngrams[context] = {}
                
                ngrams[context][next_symbol] = ngrams[context].get(next_symbol, 0) + 1
        
        print(f"   Found {len(ngrams)} unique {n}-gram contexts")
        return ngrams
    
    def build_frequency_model(self) -> Dict[str, int]:
        """Build symbol frequency table"""
        print("\n📊 Building frequency model...")
        
        frequencies = {}
        
        # From conversations
        for conv in self.conversations:
            for symbol in conv.get('symbols', []):
                frequencies[symbol] = frequencies.get(symbol, 0) + 1
        
        # Add symbol metadata
        for symbol in self.symbols:
            symbol_id = symbol.get('label', symbol.get('id'))
            if symbol_id not in frequencies:
                frequencies[symbol_id] = symbol.get('usage_count', 0)
        
        # Sort by frequency
        sorted_freq = dict(sorted(frequencies.items(), key=lambda x: x[1], reverse=True))
        
        print(f"   Top 10 symbols:")
        for symbol, count in list(sorted_freq.items())[:10]:
            print(f"   - {symbol}: {count} times")
        
        return sorted_freq
    
    def build_contextual_features(self) -> pd.DataFrame:
        """Build time-based contextual features"""
        print("\n⏰ Building contextual features...")
        
        features = []
        
        for conv in self.conversations:
            timestamp = conv.get('timestamp', datetime.now().isoformat())
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            
            for symbol in conv.get('symbols', []):
                features.append({
                    'symbol': symbol,
                    'hour': dt.hour,
                    'day_of_week': dt.weekday(),
                    'is_morning': 1 if 6 <= dt.hour < 12 else 0,
                    'is_afternoon': 1 if 12 <= dt.hour < 18 else 0,
                    'is_evening': 1 if 18 <= dt.hour < 22 else 0,
                    'is_night': 1 if dt.hour >= 22 or dt.hour < 6 else 0,
                })
        
        df = pd.DataFrame(features)
        print(f"   Generated {len(df)} contextual features")
        return df
    
    def export_to_coreml(self, ngrams: Dict, frequencies: Dict) -> bool:
        """Export models to CoreML format"""
        print("\n📦 Exporting to CoreML...")
        
        try:
            # For demonstration, we'll create the model specification
            # In production, you would use actual ML models
            
            output_dir = Path("mlmodels")
            output_dir.mkdir(exist_ok=True)
            
            # Save as JSON for now (in production, convert to .mlmodel)
            with open(output_dir / "ngram_model.json", 'w') as f:
                # Convert tuple keys to strings
                serializable_ngrams = {
                    str(k): v for k, v in ngrams.items()
                }
                json.dump(serializable_ngrams, f, indent=2)
            
            with open(output_dir / "frequency_model.json", 'w') as f:
                json.dump(frequencies, f, indent=2)
            
            print(f"✅ Models saved to {output_dir}/")
            print("\n📝 Next steps:")
            print("   1. Convert JSON models to CoreML .mlmodel format")
            print("   2. Add .mlmodel files to Xcode project")
            print("   3. Update MLPredictionService to load models")
            
            return True
            
        except Exception as e:
            print(f"❌ Error exporting models: {e}")
            return False
    
    def generate_model_card(self, ngrams: Dict, frequencies: Dict):
        """Generate documentation for the models"""
        model_card = f"""
# OpenVoice ML Models - Model Card
Generated: {datetime.now().isoformat()}

## Model Overview
These models power on-device predictions in OpenVoice AAC app.

## Models Included

### 1. N-Gram Model
- **Type**: Bigram/Trigram frequency model
- **Input**: Previous 1-2 symbols
- **Output**: Next symbol predictions with probabilities
- **Contexts**: {len(ngrams)} unique contexts
- **Purpose**: Sequential prediction

### 2. Frequency Model
- **Type**: Usage frequency ranking
- **Symbols**: {len(frequencies)} symbols
- **Top Symbol**: {list(frequencies.keys())[0] if frequencies else 'N/A'}
- **Purpose**: Most-used symbol suggestions

### 3. Contextual Model
- **Type**: Time-of-day classifier
- **Features**: Hour, day of week, time period
- **Purpose**: Context-aware predictions

## Training Data
- **Conversations**: {len(self.conversations)}
- **Date Range**: Training data from user's conversation history
- **Privacy**: All training done on-device, no data sent to servers

## Performance Targets
- **Inference Time**: <50ms per prediction
- **Accuracy**: >80% for top-3 predictions
- **Memory**: <10MB model size
- **Battery**: Minimal impact

## Limitations
- Requires sufficient training data (50+ conversations)
- Better performance with more diverse symbol usage
- Time-based predictions improve with usage patterns

## Usage
Models are automatically loaded by MLPredictionService.swift
and used to generate real-time predictions as users build phrases.
"""
        
        with open("mlmodels/MODEL_CARD.md", 'w') as f:
            f.write(model_card)
        
        print("\n📄 Model card generated: mlmodels/MODEL_CARD.md")
    
    def train_all(self):
        """Main training pipeline"""
        print("=" * 60)
        print("OpenVoice CoreML Model Training")
        print("=" * 60)
        
        # Load data
        if not self.load_conversation_data():
            return False
        
        # Build models
        ngrams = self.build_ngram_model(n=2)
        frequencies = self.build_frequency_model()
        contextual_df = self.build_contextual_features()
        
        # Export models
        if self.export_to_coreml(ngrams, frequencies):
            self.generate_model_card(ngrams, frequencies)
            
            print("\n" + "=" * 60)
            print("✨ Training Complete!")
            print("=" * 60)
            return True
        
        return False


def main():
    """Main entry point"""
    trainer = AAC_ModelTrainer()
    trainer.train_all()


if __name__ == "__main__":
    main()
