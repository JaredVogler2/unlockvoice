//
//  MLPredictionService.swift
//  OpenVoice - Phase 6
//
//  CoreML-based prediction service for on-device machine learning
//  Provides word/symbol predictions based on context and usage patterns
//

import Foundation
import CoreML
import Combine

// MARK: - Prediction Result
struct MLPrediction: Identifiable, Equatable {
    let id = UUID()
    let symbolId: String
    let label: String
    let category: String
    let confidence: Double
    let source: PredictionSource
    let reasoning: String
    
    enum PredictionSource: String {
        case nGram = "N-Gram Model"
        case contextual = "Context Model"
        case frequency = "Usage Frequency"
        case hybrid = "Hybrid Model"
    }
}

// MARK: - ML Prediction Service
@MainActor
class MLPredictionService: ObservableObject {
    // MARK: - Singleton
    static let shared = MLPredictionService()
    
    // MARK: - Published Properties
    @Published var isModelLoaded = false
    @Published var predictions: [MLPrediction] = []
    @Published var inferenceTime: TimeInterval = 0
    
    // MARK: - Private Properties
    private var nGramModel: NGramPredictionModel?
    private var contextModel: ContextualPredictionModel?
    private var frequencyCache: [String: Int] = [:]
    private var lastContext: [String] = []
    
    // Analytics integration
    private let analytics = AnalyticsService.shared
    private let conversationHistory = ConversationHistoryService.shared
    
    // Configuration
    private let maxPredictions = 10
    private let minConfidence = 0.1
    private let contextWindowSize = 5
    
    // MARK: - Initialization
    private init() {
        loadModels()
        loadFrequencyCache()
    }
    
    // MARK: - Model Loading
    func loadModels() {
        Task {
            do {
                // Load N-gram model for sequential predictions
                nGramModel = try await loadNGramModel()
                
                // Load contextual model for time/usage-based predictions
                contextModel = try await loadContextualModel()
                
                await MainActor.run {
                    self.isModelLoaded = true
                    print("✅ ML models loaded successfully")
                }
            } catch {
                print("❌ Failed to load ML models: \(error)")
            }
        }
    }
    
    private func loadNGramModel() async throws -> NGramPredictionModel {
        // In production, this would load an actual .mlmodelc file
        // For now, we create an intelligent rule-based system
        return NGramPredictionModel()
    }
    
    private func loadContextualModel() async throws -> ContextualPredictionModel {
        return ContextualPredictionModel()
    }
    
    private func loadFrequencyCache() {
        Task {
            // Load from analytics
            let stats = analytics.getUsageStatistics()
            
            // Convert to frequency dictionary
            for symbol in stats.symbolUsage {
                frequencyCache[symbol.symbolId] = symbol.usageCount
            }
            
            print("📊 Loaded \(frequencyCache.count) symbols into frequency cache")
        }
    }
    
    // MARK: - Prediction Methods
    
    /// Main prediction method - generates predictions based on current context
    func predictNext(
        context: [String],
        currentSymbols: [Symbol],
        timeOfDay: Date = Date(),
        maxResults: Int? = nil
    ) async -> [MLPrediction] {
        let startTime = Date()
        
        // Update context
        self.lastContext = Array(context.suffix(contextWindowSize))
        
        var allPredictions: [MLPrediction] = []
        
        // 1. N-Gram predictions (based on sequence)
        if let nGramModel = nGramModel, !context.isEmpty {
            let nGramPredictions = await nGramModel.predict(
                context: lastContext,
                availableSymbols: currentSymbols
            )
            allPredictions.append(contentsOf: nGramPredictions)
        }
        
        // 2. Contextual predictions (based on time, usage patterns)
        if let contextModel = contextModel {
            let contextPredictions = await contextModel.predict(
                timeOfDay: timeOfDay,
                recentContext: lastContext,
                frequencyData: frequencyCache,
                availableSymbols: currentSymbols
            )
            allPredictions.append(contentsOf: contextPredictions)
        }
        
        // 3. Frequency-based predictions
        let frequencyPredictions = predictFromFrequency(
            symbols: currentSymbols,
            excludeRecent: Set(lastContext)
        )
        allPredictions.append(contentsOf: frequencyPredictions)
        
        // 4. Merge and rank predictions
        let rankedPredictions = rankAndDeduplicate(allPredictions)
        
        // 5. Take top N
        let topPredictions = Array(rankedPredictions.prefix(maxResults ?? maxPredictions))
        
        // Update inference time
        let inferenceTime = Date().timeIntervalSince(startTime)
        await MainActor.run {
            self.predictions = topPredictions
            self.inferenceTime = inferenceTime
        }
        
        print("🧠 Generated \(topPredictions.count) predictions in \(String(format: "%.1fms", inferenceTime * 1000))")
        
        return topPredictions
    }
    
    /// Quick predictions for immediate context
    func getQuickPredictions(lastSymbols: [String], symbols: [Symbol]) async -> [MLPrediction] {
        return await predictNext(
            context: lastSymbols,
            currentSymbols: symbols,
            maxResults: 6
        )
    }
    
    // MARK: - Frequency-Based Predictions
    private func predictFromFrequency(
        symbols: [Symbol],
        excludeRecent: Set<String>
    ) -> [MLPrediction] {
        var predictions: [MLPrediction] = []
        
        for symbol in symbols {
            // Skip recently used symbols
            if excludeRecent.contains(symbol.id) {
                continue
            }
            
            // Get frequency
            let frequency = frequencyCache[symbol.id] ?? 0
            guard frequency > 0 else { continue }
            
            // Calculate confidence based on frequency
            let maxFrequency = frequencyCache.values.max() ?? 1
            let confidence = Double(frequency) / Double(maxFrequency)
            
            if confidence >= minConfidence {
                predictions.append(MLPrediction(
                    symbolId: symbol.id,
                    label: symbol.label,
                    category: symbol.category,
                    confidence: confidence * 0.8, // Weight down frequency-only
                    source: .frequency,
                    reasoning: "Used \(frequency) times"
                ))
            }
        }
        
        return predictions.sorted { $0.confidence > $1.confidence }
    }
    
    // MARK: - Ranking and Deduplication
    private func rankAndDeduplicate(_ predictions: [MLPrediction]) -> [MLPrediction] {
        var seenIds = Set<String>()
        var uniquePredictions: [MLPrediction] = []
        var symbolScores: [String: Double] = [:]
        
        // Aggregate scores for same symbols from different sources
        for prediction in predictions {
            if let existing = symbolScores[prediction.symbolId] {
                // Combine scores with weighted average
                symbolScores[prediction.symbolId] = existing + (prediction.confidence * 0.5)
            } else {
                symbolScores[prediction.symbolId] = prediction.confidence
            }
        }
        
        // Create final predictions with aggregated scores
        for prediction in predictions {
            if !seenIds.contains(prediction.symbolId),
               let finalScore = symbolScores[prediction.symbolId] {
                seenIds.insert(prediction.symbolId)
                
                var updatedPrediction = prediction
                // Update confidence with aggregated score
                uniquePredictions.append(MLPrediction(
                    symbolId: updatedPrediction.symbolId,
                    label: updatedPrediction.label,
                    category: updatedPrediction.category,
                    confidence: min(finalScore, 1.0),
                    source: .hybrid,
                    reasoning: updatedPrediction.reasoning
                ))
            }
        }
        
        return uniquePredictions.sorted { $0.confidence > $1.confidence }
    }
    
    // MARK: - Learning from User Actions
    func recordPredictionAccepted(symbolId: String) {
        // Update frequency cache
        frequencyCache[symbolId, default: 0] += 1
        
        // This would trigger model retraining in production
        print("✅ Recorded: User selected \(symbolId)")
    }
    
    func recordPredictionRejected(symbolId: String, context: [String]) {
        // In production, this would negatively weight this prediction
        print("❌ Recorded: User rejected \(symbolId) in context: \(context)")
    }
    
    // MARK: - Model Refresh
    func refreshModels() {
        loadFrequencyCache()
        print("🔄 Refreshed ML models with latest data")
    }
    
    // MARK: - Diagnostics
    func getDiagnostics() -> String {
        """
        ML Prediction Service Diagnostics
        =================================
        Models Loaded: \(isModelLoaded)
        N-Gram Model: \(nGramModel != nil ? "✅" : "❌")
        Context Model: \(contextModel != nil ? "✅" : "❌")
        Frequency Cache: \(frequencyCache.count) symbols
        Last Inference: \(String(format: "%.1fms", inferenceTime * 1000))
        Active Predictions: \(predictions.count)
        """
    }
}

// MARK: - N-Gram Prediction Model
class NGramPredictionModel {
    private var bigramTable: [String: [String: Int]] = [:]
    private var trigramTable: [String: [String: Int]] = [:]
    
    func predict(context: [String], availableSymbols: [Symbol]) async -> [MLPrediction] {
        var predictions: [MLPrediction] = []
        
        guard !context.isEmpty else { return predictions }
        
        // Get last 1-2 symbols for n-gram lookup
        let lastSymbol = context.last!
        let lastTwo = context.count >= 2 ? context.suffix(2).joined(separator: "_") : lastSymbol
        
        // Common bigrams (this would be learned from data in production)
        let commonBigrams = getCommonBigrams()
        
        if let nextSymbols = commonBigrams[lastSymbol] {
            for (nextSymbol, count) in nextSymbols {
                if let symbol = availableSymbols.first(where: { $0.id == nextSymbol || $0.label.lowercased() == nextSymbol.lowercased() }) {
                    let confidence = min(Double(count) / 100.0, 0.95)
                    predictions.append(MLPrediction(
                        symbolId: symbol.id,
                        label: symbol.label,
                        category: symbol.category,
                        confidence: confidence,
                        source: .nGram,
                        reasoning: "Follows '\(lastSymbol)' \(count) times"
                    ))
                }
            }
        }
        
        return predictions.sorted { $0.confidence > $1.confidence }
    }
    
    // Common AAC symbol sequences
    private func getCommonBigrams() -> [String: [String: Int]] {
        return [
            "i": ["want": 50, "need": 40, "like": 35, "am": 30, "feel": 25],
            "want": ["water": 45, "food": 40, "help": 35, "go": 30, "play": 25],
            "need": ["help": 50, "water": 35, "bathroom": 30, "break": 25],
            "feel": ["happy": 40, "sad": 35, "tired": 30, "good": 25, "bad": 20],
            "thank": ["you": 90],
            "yes": ["please": 60],
            "no": ["thank": 50, "thanks": 40],
            "go": ["home": 45, "outside": 40, "bathroom": 35, "play": 30],
            "play": ["game": 40, "outside": 35, "friend": 30, "ball": 25],
            "eat": ["food": 50, "lunch": 35, "dinner": 30, "snack": 25]
        ]
    }
}

// MARK: - Contextual Prediction Model
class ContextualPredictionModel {
    
    func predict(
        timeOfDay: Date,
        recentContext: [String],
        frequencyData: [String: Int],
        availableSymbols: [Symbol]
    ) async -> [MLPrediction] {
        var predictions: [MLPrediction] = []
        
        // Get time-based predictions
        let hour = Calendar.current.component(.hour, from: timeOfDay)
        let timeContext = getTimeContext(hour: hour)
        
        // Find symbols matching time context
        for contextWord in timeContext {
            if let symbol = availableSymbols.first(where: {
                $0.label.lowercased().contains(contextWord.lowercased()) ||
                $0.category.lowercased().contains(contextWord.lowercased())
            }) {
                let baseConfidence = 0.7
                let frequency = frequencyData[symbol.id] ?? 0
                let frequencyBoost = min(Double(frequency) / 50.0, 0.3)
                
                predictions.append(MLPrediction(
                    symbolId: symbol.id,
                    label: symbol.label,
                    category: symbol.category,
                    confidence: baseConfidence + frequencyBoost,
                    source: .contextual,
                    reasoning: "Common at \(hour):00"
                ))
            }
        }
        
        return predictions.sorted { $0.confidence > $1.confidence }
    }
    
    private func getTimeContext(hour: Int) -> [String] {
        switch hour {
        case 6...9:
            return ["morning", "breakfast", "wake", "hello", "good morning"]
        case 10...11:
            return ["morning", "snack", "play", "activity"]
        case 12...13:
            return ["lunch", "eat", "food", "hungry", "drink"]
        case 14...16:
            return ["afternoon", "activity", "play", "rest"]
        case 17...19:
            return ["dinner", "eat", "food", "family", "home"]
        case 20...21:
            return ["evening", "tired", "bed", "rest", "quiet"]
        case 22...23, 0...5:
            return ["night", "sleep", "bed", "tired", "rest"]
        default:
            return []
        }
    }
}
