# 🚀 QUICK START GUIDE
## Get OpenVoice Running on Your Mac in 30 Minutes

This guide will help you set up the OpenVoice project and see it running on your Mac today.

## ⏱️ Prerequisites (5 minutes)

1. **Mac mini with macOS** (you have this ✅)
2. **Xcode** - Download from Mac App Store (if not already installed)
3. **Apple ID** - For signing the app

---

## 📦 STEP 1: Create Xcode Project (5 minutes)

1. **Open Xcode**
   - If first time: Complete the setup and install additional components

2. **Create New Project**
   - Click "Create a new Xcode project"
   - Or: File → New → Project

3. **Choose Template**
   - Select **iOS** at the top
   - Choose **App** template
   - Click **Next**

4. **Project Configuration**
   ```
   Product Name: OpenVoice
   Team: (Select your Apple ID)
   Organization Identifier: com.yourname (e.g., com.johnsmith)
   Interface: SwiftUI ← Important!
   Language: Swift ← Important!
   Storage: None
   Include Tests: ✓ (optional)
   ```
   - Click **Next**
   
5. **Save Location**
   - Choose where to save (e.g., Documents/OpenVoice)
   - **Uncheck** "Create Git repository" (we'll do this separately)
   - Click **Create**

---

## 📁 STEP 2: Set Up Project Structure (10 minutes)

### Create Folders

1. **In Xcode, right-click** on the "OpenVoice" folder (blue icon) in the left sidebar
2. **Select "New Group"** and create these folders:
   ```
   Models
   Views
   ViewModels
   Services
   Resources
   ```

### Add Files

You have 14 Swift files ready to add. For each file:

1. **Right-click** on the appropriate folder
2. **Select "New File"**
3. **Choose "Swift File"**
4. **Name it** (e.g., "Symbol.swift")
5. **Copy and paste** the code from the provided file

**File Organization**:
```
OpenVoice/
├── OpenVoiceApp.swift ← Replace the existing file
├── ContentView.swift ← Replace the existing file
├── Models/
│   ├── Symbol.swift ← New
│   ├── Phrase.swift ← New
│   └── UserProfile.swift ← New
├── Views/
│   ├── SymbolGridView.swift ← New
│   ├── PhraseBarView.swift ← New
│   ├── PredictionBarView.swift ← New
│   ├── SettingsView.swift ← New
│   └── CalibrationView.swift ← New
├── ViewModels/
│   ├── SymbolGridViewModel.swift ← New
│   └── PredictionViewModel.swift ← New
└── Services/
    └── SpeechService.swift ← New
```

### Quick File Adding Method:
1. Download all `.swift` files to a folder on your Mac
2. In Xcode: Right-click on "OpenVoice" → "Add Files to OpenVoice"
3. Select all the Swift files → Add
4. Make sure "Copy items if needed" is checked

---

## ⚙️ STEP 3: Configure Project Settings (5 minutes)

### Update Info.plist

1. **In Xcode**, click on the **blue project icon** at the top of file list
2. Select **Info** tab
3. **Right-click** in the white area → "Add Row"
4. Add these keys:

```
Key: Privacy - Camera Usage Description
Value: OpenVoice needs camera access for eye tracking to enable hands-free communication.

Key: Privacy - Photo Library Usage Description
Value: OpenVoice needs access to import photos as custom communication symbols.

Key: Privacy - Speech Recognition Usage Description
Value: OpenVoice may use speech recognition for future features.
```

### Set Deployment Target

1. Click **OpenVoice** (blue project icon)
2. Select **OpenVoice** under TARGETS
3. Under **General** tab:
   - **Minimum Deployments**: iOS 14.0
   - **Supported Destinations**: iPhone, iPad

### Configure Signing

1. Under **Signing & Capabilities** tab:
   - Check **Automatically manage signing**
   - **Team**: Select your Apple ID
   - Xcode will generate a Bundle Identifier automatically

---

## ▶️ STEP 4: Build and Run (5 minutes)

### Option A: Run in Simulator (Easiest)

1. **Select a simulator** from the device dropdown (top center)
   - Choose "iPhone 15 Pro" or "iPad Pro"
   
2. **Click the Play button** (▶) or press **Cmd + R**

3. **Wait for build** (first build takes 1-2 minutes)

4. **Simulator launches** with OpenVoice running!

### Option B: Run on Your Physical Device

1. **Connect your iPhone/iPad** to your Mac via USB cable

2. **Trust the computer** on your device (if prompted)

3. **Select your device** from the device dropdown

4. **Click Play** (▶)

5. If you see a signing error:
   - Go to Settings → General → VPN & Device Management
   - Trust your developer certificate
   
6. **App launches!**

---

## 🎮 STEP 5: Test the App (5 minutes)

### What to Try:

1. **Tap symbols** in the grid
   - They should appear in the phrase bar at the top

2. **Tap the "Speak" button**
   - You should hear the phrase spoken aloud!
   - Make sure device volume is up

3. **Tap the gear icon** (⚙️)
   - Try changing settings:
     - Symbol size
     - Grid columns
     - Speech rate
     - Voice selection

4. **Test "Clear" button**
   - Should remove all symbols from phrase

5. **Test "Delete" button**
   - Should remove last symbol

### Expected Behavior:

✅ App launches without crashing
✅ Grid of symbols displayed
✅ Tapping symbols adds them to phrase bar
✅ Speak button produces audio
✅ Settings can be changed
✅ Changes persist after relaunch

---

## 🎉 SUCCESS!

**You now have OpenVoice Phase 1 running!**

### What You Have:
- ✅ Complete app foundation
- ✅ Touch-based symbol selection
- ✅ Text-to-speech
- ✅ Phrase building
- ✅ Settings system
- ✅ Professional architecture

### What's Next:
- **Phase 2**: Add Mulberry symbols (3,000+ professional AAC symbols)
- **Phase 3**: Enhance speech (already mostly done!)
- **Phase 4**: ARKit eye tracking (the exciting part!)

---

## 🐛 Troubleshooting

### Build Errors?

**"Cannot find 'X' in scope"**
- Make sure all files are added to the project target
- Check the file is in the correct folder
- Clean build folder: Product → Clean Build Folder

**Signing errors**
- Make sure you selected a Team in project settings
- Try: Xcode → Preferences → Accounts → Add Apple ID

**Simulator not launching**
- Try a different simulator
- Xcode → Preferences → Locations → Command Line Tools (select latest Xcode)

### Runtime Issues?

**App crashes on launch**
- Check for any syntax errors in Issue Navigator (left sidebar)
- Look at the console output (bottom of Xcode) for error messages

**Symbols not showing**
- Phase 1 uses SF Symbols (built into iOS)
- They should display as icons
- Phase 2 will add actual Mulberry images

**No sound from Speak button**
- Check device volume
- Check device is not in silent mode
- Try different voice in Settings

### Still Having Issues?

1. **Check the console** (View → Debug Area → Show Debug Area)
2. **Read error messages** carefully
3. **Google the error** - most Xcode errors have Stack Overflow solutions
4. **Ask in Apple Developer Forums**

---

## 📱 Running on Device vs Simulator

### Simulator (No Eye Tracking)
- ✅ Easy testing
- ✅ Fast iteration
- ❌ No camera (can't test eye tracking)
- ❌ No TrueDepth sensors

### Physical Device (iPhone X+, iPad Pro 2018+)
- ✅ Test eye tracking (Phase 4)
- ✅ Real performance testing
- ✅ Actual user experience
- ❌ Requires cable connection

**Recommendation**: Use simulator for Phase 1-3, physical device for Phase 4+

---

## 🔄 Next Steps

### Today:
1. ✅ Get the app running
2. ✅ Test all features
3. ✅ Explore the code
4. ✅ Make small changes to understand how it works

### This Week:
1. **Learn SwiftUI basics** (if new to it)
   - Apple's SwiftUI Tutorials: https://developer.apple.com/tutorials/swiftui
   - 100 Days of SwiftUI: https://www.hackingwithswift.com/100/swiftui

2. **Understand the code**
   - Read through each file
   - Follow the data flow
   - Understand MVVM pattern

3. **Plan Phase 2**
   - Download Mulberry Symbols
   - Learn about asset catalogs
   - Study image loading in SwiftUI

### This Month:
1. **Build Phase 2**: Symbol Library
2. **Test with real users** (if possible)
3. **Start learning ARKit** (for Phase 4)

---

## 📚 Resources

### Learning
- **SwiftUI**: https://developer.apple.com/tutorials/swiftui
- **100 Days of SwiftUI**: https://www.hackingwithswift.com/100/swiftui
- **Hacking with Swift**: https://www.hackingwithswift.com
- **Apple Documentation**: https://developer.apple.com/documentation/

### Community
- **Stack Overflow**: https://stackoverflow.com/questions/tagged/swiftui
- **Apple Developer Forums**: https://developer.apple.com/forums/
- **Swift Forums**: https://forums.swift.org/
- **Reddit**: r/iOSProgramming, r/swift

### Project Resources
- **README.md**: Full project overview
- **DEVELOPMENT_PLAN.md**: Complete roadmap
- **Mulberry Symbols**: https://www.mulberrysymbols.org/

---

## 💡 Tips for Success

1. **Start Small**: Don't try to build everything at once
2. **Test Often**: Run the app after every change
3. **Read Errors**: Error messages are your friends
4. **Use Version Control**: Learn Git to track changes
5. **Ask for Help**: Don't struggle alone - developer community is helpful
6. **Celebrate Progress**: Every small milestone matters!

---

## 🎯 Phase 1 Complete Checklist

- [ ] Xcode project created
- [ ] All Swift files added
- [ ] Project builds without errors
- [ ] App runs in simulator
- [ ] Symbols displayed in grid
- [ ] Tapping symbols works
- [ ] Speak button produces audio
- [ ] Settings can be changed
- [ ] App doesn't crash

**Once you have all ✓ above, you're ready for Phase 2!**

---

## 🙋 Questions?

- Check README.md for detailed information
- Review DEVELOPMENT_PLAN.md for the full roadmap
- Create GitHub issues for bugs or questions
- Join the community (Discord link coming soon)

---

**Congratulations on getting started!** 🎉

**You're building something that will genuinely help people communicate. That's incredible work.**

---

*Remember: This is Phase 1 of 12. You have a solid foundation. Build incrementally, test often, and don't rush. Quality matters more than speed when building accessibility tools.*

**"Every person deserves a voice." - Let's build it together. 💙**
