# 🔧 PHASE 10 INTEGRATION GUIDE

## 📖 Complete Setup & Integration

This guide walks you through setting up Phase 10: Local LLM Integration with MLX framework.

---

## 🎯 Prerequisites

### Hardware Requirements
- **Mac with Apple Silicon** (M1, M2, M3, or later)
- **16GB RAM minimum** (32GB recommended for Mistral 7B)
- **10GB free disk space** (for model storage)

### Software Requirements
- **macOS 14.0+** (Sonoma or later)
- **Python 3.9+** 
- **Xcode 15.0+**
- **Homebrew** (recommended for package management)

---

## ⚙️ Part 1: Python Backend Setup

### Step 1: Install Python Dependencies

```bash
# Navigate to Python backend directory
cd OpenVoiceApp/PythonBackend

# Create virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate

# Install Phase 10 requirements
pip install --upgrade pip
pip install -r requirements_phase10.txt

# Verify MLX installation
python -c "import mlx.core as mx; print(f'MLX version: {mx.__version__}')"
```

### Step 2: Download LLM Model

```bash
# Download Mistral 7B (4-bit quantized) - Primary model
python -m mlx_lm.download --model mlx-community/Mistral-7B-Instruct-v0.2-4bit

# Optional: Download alternative models
# Phi-2 (smaller, faster) - 1.5GB
python -m mlx_lm.download --model mlx-community/phi-2-4bit

# TinyLlama (ultra-light) - 600MB
python -m mlx_lm.download --model mlx-community/TinyLlama-1.1B-Chat-v1.0-4bit

# Models are saved to: ~/.cache/huggingface/hub/
```

### Step 3: Verify Model Download

```bash
# Check model files
ls -lh ~/.cache/huggingface/hub/models--mlx-community--Mistral-7B-Instruct-v0.2-4bit/

# Should see files like:
# - config.json
# - tokenizer.json
# - weights.npz
# Total size: ~4GB
```

### Step 4: Update Main Server

Add Phase 10 router to your FastAPI server:

```python
# In src/main.py, add:

from api.llm_router import router as llm_router

# Include the router
app.include_router(llm_router)
```

### Step 5: Start Backend

```bash
# Start the FastAPI server
cd OpenVoiceApp/PythonBackend
python -m uvicorn src.main:app --reload --host 0.0.0.0 --port 8000

# Or use docker-compose (recommended for production)
docker-compose up -d
```

### Step 6: Test Backend

```bash
# Test health endpoint
curl http://localhost:8000/api/v1/llm/health

# Expected response:
# {
#   "status": "healthy",
#   "phase": 10,
#   "is_loaded": false,
#   "model": null,
#   "mlx_available": true
# }

# Load the model
curl -X POST http://localhost:8000/api/v1/llm/model/load

# Test generation (this will auto-load model if needed)
curl -X POST http://localhost:8000/api/v1/llm/test

# Expected: Natural language response from LLM
```

---

## 📱 Part 2: iOS Integration

### Step 1: Add LocalLLMService to Project

1. **Open Xcode project**
2. **Add file**: Services/LocalLLMService.swift (already created)
3. **Ensure** it's added to your app target
4. **Build** (⌘B) to verify no errors

### Step 2: Initialize Service in App

Update your `OpenVoiceApp.swift`:

```swift
import SwiftUI

@main
struct OpenVoiceApp: App {
    // Initialize LLM service
    @StateObject private var llmService = LocalLLMService.shared
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(llmService)
        }
    }
}
```

### Step 3: Update SymbolGridViewModel

Enhance your `SymbolGridViewModel.swift` to use LLM:

```swift
import SwiftUI
import Combine

@MainActor
class SymbolGridViewModel: ObservableObject {
    @Published var currentPhrase: [Symbol] = []
    @Published var enhancedSentence: String = ""
    @Published var suggestions: [String] = []
    
    private let speechService = SpeechService.shared
    private let llmService = LocalLLMService.shared
    
    // Existing code...
    
    func addSymbol(_ symbol: Symbol) {
        currentPhrase.append(symbol)
        
        // Get LLM enhancement if available
        Task {
            await enhanceCurrentPhrase()
        }
    }
    
    private func enhanceCurrentPhrase() async {
        guard !currentPhrase.isEmpty else { return }
        
        let symbols = currentPhrase.map { $0.name }
        
        // Try to enhance with LLM
        if llmService.isAvailable {
            do {
                let context = getCurrentContext()
                let enhanced = try await llmService.enhance(
                    symbols: symbols,
                    context: context
                )
                
                enhancedSentence = enhanced.sentence
                suggestions = enhanced.suggestions
                
                // Handle urgent communications
                if enhanced.urgencyEnum == .urgent {
                    handleUrgentCommunication(enhanced)
                }
                
            } catch {
                // Fallback to basic phrase building
                enhancedSentence = symbols.joined(separator: " ")
            }
        } else {
            // LLM not available, use basic joining
            enhancedSentence = symbols.joined(separator: " ")
        }
    }
    
    private func getCurrentContext() -> [String: Any] {
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: Date())
        
        var timeOfDay = "morning"
        if hour >= 12 && hour < 17 {
            timeOfDay = "afternoon"
        } else if hour >= 17 {
            timeOfDay = "evening"
        }
        
        return [
            "time_of_day": timeOfDay,
            "symbols_count": currentPhrase.count
        ]
    }
    
    private func handleUrgentCommunication(_ enhanced: EnhancedCommunication) {
        // Flash screen, vibrate, or send notifications
        HapticManager.shared.notification(type: .warning)
        
        // Could send emergency notification to caregivers
        print("🚨 URGENT: \(enhanced.sentence)")
    }
    
    func speakCurrentPhrase() {
        let text = enhancedSentence.isEmpty ? 
                   currentPhrase.map { $0.name }.joined(separator: " ") :
                   enhancedSentence
        
        speechService.speak(text)
    }
}
```

### Step 4: Create LLM Settings View

Create a new view for LLM settings:

```swift
//
//  LLMSettingsView.swift
//  OpenVoice
//

import SwiftUI

struct LLMSettingsView: View {
    @ObservedObject var llmService = LocalLLMService.shared
    @State private var showingStats = false
    
    var body: some View {
        Form {
            Section(header: Text("LLM Status")) {
                HStack {
                    Text("Service Available")
                    Spacer()
                    if llmService.isAvailable {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                    } else {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.red)
                    }
                }
                
                if llmService.isLoading {
                    HStack {
                        ProgressView()
                        Text("Loading model...")
                    }
                }
                
                if let error = llmService.error {
                    Text(error)
                        .foregroundColor(.red)
                        .font(.caption)
                }
            }
            
            Section(header: Text("Actions")) {
                Button("Check Health") {
                    Task {
                        await llmService.checkHealth()
                    }
                }
                
                Button("Load Model") {
                    Task {
                        do {
                            try await llmService.loadModel()
                        } catch {
                            print("Load error: \(error)")
                        }
                    }
                }
                .disabled(llmService.isLoading || llmService.isAvailable)
                
                Button("Unload Model") {
                    Task {
                        do {
                            try await llmService.unloadModel()
                        } catch {
                            print("Unload error: \(error)")
                        }
                    }
                }
                .disabled(!llmService.isAvailable)
                
                Button("Clear Memory") {
                    Task {
                        do {
                            try await llmService.clearMemory()
                        } catch {
                            print("Clear error: \(error)")
                        }
                    }
                }
                .disabled(!llmService.isAvailable)
                
                Button("Test LLM") {
                    Task {
                        do {
                            let result = try await llmService.test()
                            print("Test result: \(result)")
                        } catch {
                            print("Test error: \(error)")
                        }
                    }
                }
                .disabled(!llmService.isAvailable)
            }
            
            Section(header: Text("Statistics")) {
                Button("View Stats") {
                    showingStats = true
                    Task {
                        try? await llmService.fetchStats()
                    }
                }
                .disabled(!llmService.isAvailable)
                
                if let stats = llmService.stats {
                    VStack(alignment: .leading, spacing: 8) {
                        StatRow(label: "Total Generations", value: "\(stats.totalGenerations)")
                        StatRow(label: "Average Latency", value: String(format: "%.0fms", stats.avgLatencyMs))
                        StatRow(label: "Average Tokens", value: String(format: "%.1f", stats.avgTokens))
                        StatRow(label: "Errors", value: "\(stats.errors)")
                    }
                    .font(.caption)
                }
            }
            
            Section(header: Text("About")) {
                Text("Phase 10: Local LLM Integration")
                    .font(.headline)
                Text("Uses Apple's MLX framework for on-device AI.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Link("MLX Documentation", destination: URL(string: "https://ml-explore.github.io/mlx/")!)
                    .font(.caption)
            }
        }
        .navigationTitle("LLM Settings")
    }
}

struct StatRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
            Spacer()
            Text(value)
                .foregroundColor(.secondary)
        }
    }
}
```

### Step 5: Add LLM Settings to Main Settings

Update your `SettingsView.swift` to include LLM settings:

```swift
NavigationLink(destination: LLMSettingsView()) {
    HStack {
        Image(systemName: "brain")
        Text("LLM Settings")
    }
}
```

---

## 🧪 Part 3: Testing Integration

### Test 1: Backend Health Check

```bash
curl http://localhost:8000/api/v1/llm/health
```

Expected: `"status": "healthy", "mlx_available": true`

### Test 2: Simple Enhancement

```bash
curl -X POST http://localhost:8000/api/v1/llm/enhance \
  -H "Content-Type: application/json" \
  -d '{
    "symbols": ["want", "water"],
    "context": {"time_of_day": "afternoon"},
    "use_memory": true
  }'
```

Expected: Natural language sentence with suggestions

### Test 3: iOS Integration

1. **Run app** in simulator or device
2. **Navigate** to Settings → LLM Settings
3. **Check health** - should show green checkmark
4. **Build phrase** with symbols on main screen
5. **Observe** enhanced sentence appears automatically

### Test 4: Conversation Memory

```swift
// In your test code:
let llm = LocalLLMService.shared

// First message
let response1 = try await llm.enhance(symbols: ["my", "name", "alex"])
print(response1.sentence) // "My name is Alex."

// Second message - should remember name
let response2 = try await llm.enhance(symbols: ["how", "are", "you"])
print(response2.sentence) // "How are you doing, Alex?"
```

---

## 🚀 Part 4: Performance Optimization

### Optimize Model Loading

```python
# In mlx_engine.py, pre-load model on startup:

async def startup_event():
    engine = get_mlx_engine()
    await engine.load_model()

# In main.py:
app.add_event_handler("startup", startup_event)
```

### Enable Caching

```python
# Add simple response cache for common phrases
from functools import lru_cache

@lru_cache(maxsize=100)
def cached_enhance(symbols_tuple: tuple) -> str:
    # Cache common symbol combinations
    pass
```

### Optimize iOS Requests

```swift
// Debounce rapid requests
private var enhanceTask: Task<Void, Never>?

func addSymbol(_ symbol: Symbol) {
    currentPhrase.append(symbol)
    
    // Cancel previous enhancement
    enhanceTask?.cancel()
    
    // Debounce: wait 500ms before enhancing
    enhanceTask = Task {
        try? await Task.sleep(nanoseconds: 500_000_000)
        await enhanceCurrentPhrase()
    }
}
```

---

## 🐛 Troubleshooting

### Issue: MLX Not Found

```bash
# Solution: Ensure you're on Apple Silicon
arch

# Should output: arm64

# Reinstall MLX
pip uninstall mlx mlx-lm
pip install --upgrade mlx mlx-lm
```

### Issue: Model Download Fails

```bash
# Solution: Check disk space
df -h

# Clear cache and retry
rm -rf ~/.cache/huggingface/hub/
python -m mlx_lm.download --model mlx-community/Mistral-7B-Instruct-v0.2-4bit
```

### Issue: Slow Generation

**Causes:**
- First generation always slower (model loading)
- CPU mode instead of GPU
- Memory pressure

**Solutions:**
```python
# Verify GPU usage
import mlx.core as mx
print(f"Using GPU: {mx.metal.is_available()}")

# Reduce max_tokens
config = LLMConfig(max_tokens=50)  # Faster

# Use smaller model
# Switch to Phi-2 (1.5GB) or TinyLlama (600MB)
```

### Issue: iOS Can't Connect to Backend

**Solutions:**
1. **Check backend is running**: `curl http://localhost:8000/health`
2. **iOS Simulator**: Use `http://localhost:8000`
3. **Physical Device**: Use Mac's local IP (e.g., `http://192.168.1.100:8000`)
4. **Firewall**: Ensure port 8000 is open

```swift
// For physical device testing:
struct LLMConfig {
    var baseURL: URL = URL(string: "http://192.168.1.100:8000")! // Use your Mac's IP
}
```

### Issue: Out of Memory

**Solutions:**
- **Use smaller model**: TinyLlama (600MB) instead of Mistral (4GB)
- **Reduce context window**: Set `context_window=256`
- **Close other apps**: Free up system RAM
- **Restart backend**: Clear memory leaks

---

## 📊 Monitoring & Metrics

### View Backend Logs

```bash
# Real-time logs
tail -f logs/backend.log

# Filter for LLM events
grep "MLX" logs/backend.log

# Check errors
grep "ERROR" logs/backend.log
```

### Monitor Performance

```bash
# Get statistics
curl http://localhost:8000/api/v1/llm/stats

# Response includes:
# - total_generations
# - avg_latency_ms
# - avg_tokens
# - errors
```

### iOS Monitoring

```swift
// In your app, track metrics:
class MetricsService {
    func trackLLMUsage(latency: Double, confidence: Double) {
        print("LLM: \(latency)ms, confidence: \(confidence)")
        // Send to analytics service
    }
}
```

---

## 🎯 Production Deployment

### Security Considerations

1. **API Authentication** (recommended for production):
```python
# Add API key authentication
from fastapi import Security, HTTPException
from fastapi.security import HTTPBearer

security = HTTPBearer()

@router.post("/enhance")
async def enhance(request: EnhanceRequest, token: str = Security(security)):
    if token != os.getenv("LLM_API_KEY"):
        raise HTTPException(status_code=401)
    # ... rest of code
```

2. **Rate Limiting**:
```python
from slowapi import Limiter

limiter = Limiter(key_func=get_remote_address)

@router.post("/enhance")
@limiter.limit("60/minute")  # Max 60 requests per minute
async def enhance(request: EnhanceRequest):
    # ... code
```

3. **Input Validation**:
```python
# Limit input size
class EnhanceRequest(BaseModel):
    symbols: List[str] = Field(..., max_items=50)  # Max 50 symbols
```

### Scaling

For production with multiple users:

```yaml
# docker-compose.yml
services:
  llm-backend:
    image: openvoice-llm:phase10
    deploy:
      replicas: 3  # Run 3 instances
    environment:
      - MLX_DEVICE=gpu
    resources:
      limits:
        memory: 8G
```

---

## ✅ Integration Checklist

- [ ] Python backend installed
- [ ] MLX and dependencies installed
- [ ] Model downloaded (Mistral 7B)
- [ ] Backend server running
- [ ] Health check passes
- [ ] LocalLLMService added to iOS
- [ ] iOS can connect to backend
- [ ] Symbols enhance correctly
- [ ] Suggestions appear
- [ ] Memory works across messages
- [ ] Settings page functional
- [ ] Performance acceptable (<2s)
- [ ] Error handling works
- [ ] Fallback mechanisms tested

---

## 🎓 Next Steps

1. **Customize prompts** in `mlx_engine.py` for your use case
2. **Fine-tune model** on AAC-specific data (advanced)
3. **Add voice cloning** (Phase 11 preview)
4. **Implement offline mode** with CoreML fallback
5. **Test with real users** and gather feedback

---

## 📚 Additional Resources

### Documentation
- [MLX Framework](https://ml-explore.github.io/mlx/)
- [MLX Examples](https://github.com/ml-explore/mlx-examples)
- [Mistral AI](https://docs.mistral.ai/)

### Tutorials
- [MLX LLM Tutorial](https://github.com/ml-explore/mlx-examples/tree/main/llms)
- [FastAPI Best Practices](https://fastapi.tiangolo.com/tutorial/)

### Community
- [OpenVoice Discord](https://discord.gg/openvoice)
- [GitHub Issues](https://github.com/openvoice/issues)

---

**Phase 10 Integration Complete!** 🎉

You now have a fully functional local LLM powering your AAC app!

---

*OpenVoice - Making AAC smarter with on-device AI* 🤖✨
