//
//  OpenVoiceApp.swift
//  OpenVoice
//
//  An open-source AAC application for non-verbal autistic individuals
//  Free forever. No prescriptions. No gatekeepers.
//

import SwiftUI

@main
struct OpenVoiceApp: App {
    @StateObject private var appState = AppState()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
                .preferredColorScheme(appState.settings.colorScheme)
        }
    }
}

/// Global app state - manages user settings, profiles, and session data
class AppState: ObservableObject {
    @Published var settings: AppSettings
    @Published var currentProfile: UserProfile?
    @Published var isCalibrated: Bool = false
    
    init() {
        // Load settings from UserDefaults
        self.settings = AppSettings.load()
        
        // Load or create default profile
        self.currentProfile = UserProfile.loadDefault()
        
        // Check calibration status
        self.isCalibrated = CalibrationManager.shared.isCalibrated
    }
    
    func saveSettings() {
        settings.save()
    }
}

/// App-wide settings
struct AppSettings: Codable {
    // Display Settings
    var colorScheme: ColorScheme?
    var symbolSize: SymbolSize = .medium
    var gridColumns: Int = 4
    var showPredictions: Bool = true
    
    // Eye Tracking Settings
    var eyeTrackingEnabled: Bool = true
    var dwellTime: Double = 0.8 // seconds
    var gazeIndicatorEnabled: Bool = true
    
    // Speech Settings
    var speechRate: Float = 0.5
    var speechPitch: Float = 1.0
    var speechVolume: Float = 1.0
    var selectedVoice: String = "com.apple.ttsbundle.Samantha-compact"
    
    // Phase 3: Advanced Speech Settings
    var enablePronunciationDictionary: Bool = true
    var saveToHistory: Bool = true
    var historyLimit: Int = 100
    var autoSpeak: Bool = false
    var speakOnSymbolSelect: Bool = false
    
    // Accessibility
    var highContrast: Bool = false
    var reduceMotion: Bool = false
    var hapticFeedback: Bool = true
    var soundEffects: Bool = true
    
    // UI Preferences
    var showLabels: Bool = true
    var animations: Bool = true
    var compactMode: Bool = false
    
    static func load() -> AppSettings {
        guard let data = UserDefaults.standard.data(forKey: "AppSettings"),
              let settings = try? JSONDecoder().decode(AppSettings.self, from: data) else {
            return AppSettings()
        }
        return settings
    }
    
    func save() {
        if let data = try? JSONEncoder().encode(self) {
            UserDefaults.standard.set(data, forKey: "AppSettings")
        }
    }
}

enum SymbolSize: String, Codable, CaseIterable {
    case small = "Small"
    case medium = "Medium"
    case large = "Large"
    case extraLarge = "Extra Large"
    
    var dimension: CGFloat {
        switch self {
        case .small: return 60
        case .medium: return 80
        case .large: return 100
        case .extraLarge: return 120
        }
    }
}
