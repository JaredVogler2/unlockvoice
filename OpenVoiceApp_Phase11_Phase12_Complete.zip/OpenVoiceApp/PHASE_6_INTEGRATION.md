# 🔧 PHASE 6: INTEGRATION GUIDE

## Step-by-Step Instructions to Integrate CoreML Predictions

---

## 📋 Prerequisites

Before starting, ensure you have:
- ✅ Phase 1-5 complete and working
- ✅ Xcode 15.0+
- ✅ iOS 15.0+ deployment target
- ✅ ~30-60 minutes available

---

## 🎯 Integration Overview

You'll be adding 3 new files and updating 2 existing files:

**New Files**:
1. `ML/MLPredictionService.swift` - Core ML service
2. `Views/EnhancedPredictionBarView.swift` - New prediction UI
3. `ML/Training/train_models.py` - Model training (optional)

**Updated Files**:
1. `ViewModels/PredictionViewModel.swift` - ML integration
2. `Views/SymbolGridView.swift` - Use ML predictions

---

## 📁 Step 1: Add New Files to Xcode (5 minutes)

### 1.1 Create ML Directory
```
Right-click on OpenVoiceApp folder
→ New Group
→ Name it "ML"
```

### 1.2 Add MLPredictionService.swift
```
Right-click on ML folder
→ Add Files to "OpenVoiceApp"
→ Select MLPredictionService.swift
→ Ensure "Copy items if needed" is checked
→ Ensure target is "OpenVoiceApp"
→ Click "Add"
```

### 1.3 Add EnhancedPredictionBarView.swift
```
Right-click on Views folder
→ Add Files to "OpenVoiceApp"
→ Select EnhancedPredictionBarView.swift
→ Click "Add"
```

### 1.4 Verify File Structure
```
OpenVoiceApp/
├── ML/
│   └── MLPredictionService.swift ✅
├── Views/
│   ├── EnhancedPredictionBarView.swift ✅
│   └── (existing views...)
├── ViewModels/
│   └── PredictionViewModel.swift (to be replaced)
└── (other folders...)
```

---

## 🔄 Step 2: Update SymbolGridViewModel (10 minutes)

### 2.1 Add ML Prediction Updates

Open `ViewModels/SymbolGridViewModel.swift` and add:

```swift
import Combine

class SymbolGridViewModel: ObservableObject {
    // Existing properties...
    
    // NEW: Add prediction view model
    let predictionViewModel = PredictionViewModel()
    
    // Existing code...
    
    // ENHANCE: Update predictions when phrase changes
    func selectSymbol(_ symbol: Symbol) {
        currentPhrase.addSymbol(symbol)
        
        // NEW: Update ML predictions
        predictionViewModel.updatePredictions(
            currentPhrase: currentPhrase.symbols,
            allSymbols: availableSymbols
        )
        
        // Existing haptic and other code...
    }
    
    func removeLastSymbol() {
        currentPhrase.removeLast()
        
        // NEW: Update predictions after removal
        predictionViewModel.updatePredictions(
            currentPhrase: currentPhrase.symbols,
            allSymbols: availableSymbols
        )
    }
    
    func clearPhrase() {
        currentPhrase.clear()
        
        // NEW: Reset to starter predictions
        predictionViewModel.getStarterPredictions(allSymbols: availableSymbols)
    }
}
```

### 2.2 Handle Prediction Selection

Add this new method:

```swift
func selectPrediction(_ prediction: MLPrediction) {
    // Find the symbol for this prediction
    guard let symbol = availableSymbols.first(where: {
        $0.id == prediction.symbolId || $0.label.lowercased() == prediction.label.lowercased()
    }) else {
        return
    }
    
    // Add to phrase
    selectSymbol(symbol)
    
    // Record prediction was accepted
    predictionViewModel.selectPrediction(prediction)
}
```

---

## 🎨 Step 3: Update UI to Show ML Predictions (10 minutes)

### 3.1 Update ContentView or SymbolGridView

Open your main view file (likely `ContentView.swift` or `SymbolGridView.swift`) and find where `PredictionBarView` is used.

**Replace this**:
```swift
PredictionBarView(viewModel: predictionViewModel)
```

**With this**:
```swift
EnhancedPredictionBarView(
    viewModel: symbolGridViewModel.predictionViewModel,
    onSelectPrediction: { prediction in
        symbolGridViewModel.selectPrediction(prediction)
    }
)
```

### 3.2 Full Example (SymbolGridView)

```swift
struct SymbolGridView: View {
    @StateObject private var viewModel = SymbolGridViewModel()
    
    var body: some View {
        VStack(spacing: 0) {
            // Phrase Bar (existing)
            PhraseBarView(phrase: viewModel.currentPhrase)
            
            // NEW: Enhanced Prediction Bar with ML
            EnhancedPredictionBarView(
                viewModel: viewModel.predictionViewModel,
                onSelectPrediction: { prediction in
                    viewModel.selectPrediction(prediction)
                }
            )
            .frame(height: 120)
            
            // Symbol Grid (existing)
            ScrollView {
                LazyVGrid(columns: viewModel.gridColumns, spacing: 12) {
                    ForEach(viewModel.displayedSymbols) { symbol in
                        SymbolButton(symbol: symbol) {
                            viewModel.selectSymbol(symbol)
                        }
                    }
                }
                .padding()
            }
        }
        .onAppear {
            // Initialize with starter predictions
            viewModel.predictionViewModel.getStarterPredictions(
                allSymbols: viewModel.availableSymbols
            )
        }
    }
}
```

---

## ⚙️ Step 4: Initialize ML Service (5 minutes)

### 4.1 Update OpenVoiceApp.swift

Ensure the ML service initializes on app launch:

```swift
import SwiftUI

@main
struct OpenVoiceApp: App {
    let persistence = PersistenceService.shared
    let mlService = MLPredictionService.shared  // NEW: Initialize ML
    
    init() {
        // ML service auto-initializes as singleton
        print("🧠 ML Service Status: \(mlService.isModelLoaded)")
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistence.viewContext)
        }
    }
}
```

---

## 🧪 Step 5: Test the Integration (10 minutes)

### 5.1 Build the App
```
⌘ + B (Command + B) to build
Fix any compilation errors if they appear
```

### 5.2 Run on Simulator
```
⌘ + R (Command + R) to run
Wait for app to launch
```

### 5.3 Test ML Predictions

1. **Test Empty State**:
   - App opens
   - Prediction bar shows "Start building a phrase"
   - ✅ Should see placeholder

2. **Test First Symbol**:
   - Tap "I" symbol
   - Wait 1 second
   - ✅ Should see predictions: "want", "need", "feel", etc.
   - ✅ Each prediction shows confidence bar

3. **Test Context Awareness**:
   - Select "want"
   - ✅ Should see predictions: "water", "food", "help"
   - ✅ Notice different predictions based on context

4. **Test Prediction Selection**:
   - Tap a prediction card
   - ✅ Symbol should be added to phrase
   - ✅ New predictions should appear

5. **Test Confidence Scores**:
   - Look at prediction cards
   - ✅ Green bar = high confidence (80%+)
   - ✅ Orange bar = medium confidence (50-80%)
   - ✅ Percentage shows below card

6. **Test Time Context**:
   - Change device time to morning (8 AM)
   - Open app
   - ✅ Should see breakfast-related suggestions
   - Change to evening (7 PM)
   - ✅ Should see dinner-related suggestions

### 5.4 Test Performance

```swift
// Add this to test inference speed
print("Inference time: \(mlService.inferenceTime * 1000)ms")
```

✅ **Target**: <50ms
✅ **Expected**: 15-30ms

---

## 🔍 Step 6: Verify Integration (5 minutes)

### 6.1 Check Console Output

Look for these messages:
```
✅ ML models loaded successfully
📊 Loaded 50 symbols into frequency cache
🧠 Generated 6 predictions in 23.4ms
```

### 6.2 Check Diagnostics

Add this to your view:
```swift
Button("Show ML Diagnostics") {
    print(MLPredictionService.shared.getDiagnostics())
}
```

Should show:
```
ML Prediction Service Diagnostics
=================================
Models Loaded: true
N-Gram Model: ✅
Context Model: ✅
Frequency Cache: 70 symbols
Last Inference: 23.4ms
Active Predictions: 6
```

---

## 🐛 Step 7: Troubleshooting

### Issue: Predictions Not Showing

**Symptom**: Prediction bar is empty or shows placeholder

**Solutions**:
```swift
// Check if models loaded
print(MLPredictionService.shared.isModelLoaded)

// Check if updatePredictions is being called
predictionViewModel.updatePredictions(
    currentPhrase: currentPhrase.symbols,
    allSymbols: availableSymbols
)

// Check available symbols
print("Available symbols: \(availableSymbols.count)")
```

### Issue: Compilation Errors

**Symptom**: Red errors in Xcode

**Solutions**:
1. Ensure all files added to correct target
2. Check import statements
3. Clean build folder (⇧⌘K)
4. Rebuild (⌘B)

### Issue: Slow Predictions

**Symptom**: Predictions take >50ms

**Solutions**:
```swift
// In MLPredictionService.swift, reduce cache size
private let maxPredictions = 6  // Instead of 10

// Or limit frequency cache
if frequencyCache.count > 100 {
    // Keep only top 100
}
```

### Issue: Wrong Predictions

**Symptom**: Predictions don't make sense

**Solutions**:
1. Check context being passed
2. Verify symbol IDs match
3. More usage improves accuracy
4. Check frequency cache loaded

---

## ✅ Integration Checklist

Before marking Phase 6 complete, verify:

### Code Integration
- [ ] MLPredictionService.swift added to project
- [ ] EnhancedPredictionBarView.swift added to project
- [ ] PredictionViewModel.swift updated with ML
- [ ] SymbolGridViewModel uses ML predictions
- [ ] ContentView shows EnhancedPredictionBarView
- [ ] OpenVoiceApp initializes ML service

### Functionality
- [ ] App builds without errors
- [ ] Predictions appear when building phrase
- [ ] Confidence scores display correctly
- [ ] Prediction selection works
- [ ] Context-aware suggestions work
- [ ] Time-based predictions work
- [ ] Performance <50ms

### User Experience
- [ ] Predictions are relevant
- [ ] UI is smooth and responsive
- [ ] Confidence bars are meaningful
- [ ] Icons show prediction source
- [ ] Empty state looks good

### Testing
- [ ] Tested on simulator
- [ ] Tested on device (if available)
- [ ] Tested various contexts
- [ ] Tested different times of day
- [ ] Verified no memory leaks

---

## 🎓 Advanced: Training Custom Models (Optional)

### If You Want to Train Real ML Models:

1. **Export Data**:
```swift
let backup = BackupService.shared
backup.createFullBackup { result in
    // Get conversations.json
}
```

2. **Run Training Script**:
```bash
cd OpenVoiceApp/ML/Training
pip install coremltools scikit-learn pandas
python train_models.py
```

3. **Convert to CoreML**:
```python
import coremltools as ct
# Follow Apple's CoreML conversion guide
```

4. **Add to Xcode**:
```
Drag .mlmodel files into Xcode
→ Xcode auto-generates Swift classes
→ Update MLPredictionService to use them
```

---

## 🎉 You're Done!

Congratulations! You've successfully integrated CoreML predictions into OpenVoice.

### What You've Achieved:
✅ On-device machine learning
✅ Context-aware predictions
✅ Confidence-based ranking
✅ Privacy-preserving intelligence
✅ Fast inference (<50ms)
✅ User-adaptive learning

### Next Steps:
- Use the app and let it learn your patterns
- Review analytics to see prediction accuracy
- Consider Phase 7 (Python Backend) for advanced models
- Explore Phase 8 (RAG System) for conversation memory

---

**"Intelligence Integrated. Privacy Protected. Communication Enhanced."** 🧠✨

---

*Phase 6 Integration Complete!*  
*Ready for Phase 7: Python Backend (Optional)*
