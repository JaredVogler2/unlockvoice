# OpenVoice Privacy Policy

**Last Updated**: [INSERT DATE]

---

## Overview

OpenVoice is committed to protecting your privacy. This Privacy Policy explains how we handle information in the OpenVoice AAC (Augmentative and Alternative Communication) application.

**The short version**: We don't collect, store, or transmit any of your personal data. Everything happens on your device.

---

## Information Collection

### What We DO NOT Collect

OpenVoice **does not** collect, store, or transmit:
- Personal information
- Usage data
- Analytics
- Crash reports
- Communication content
- Symbol selections
- Speech history
- Photos or images
- Eye tracking data
- Location data
- Device identifiers
- ANY data whatsoever

### What Stays on Your Device

All of the following data is stored **locally on your device only**:
- Communication symbols you create
- Speech history
- Custom phrases
- App settings and preferences
- Pronunciation dictionary entries
- Usage statistics (for your own viewing)
- Eye tracking calibration data

This data:
- Never leaves your device
- Is not backed up to any cloud service by OpenVoice
- Is not accessible to us or anyone else
- Can be deleted by deleting the app

---

## Permissions We Request

OpenVoice requests the following iOS permissions to function:

### Camera Access
**Purpose**: Eye tracking for hands-free symbol selection  
**How It's Used**: 
- ARKit face tracking to detect where you're looking
- Allows selection of symbols using eye gaze
- Camera data is processed in real-time and never recorded or saved

**You can use OpenVoice without granting camera access** - you just won't have eye tracking features.

### Photo Library Access
**Purpose**: Import photos as custom communication symbols  
**How It's Used**:
- Allows you to select photos from your library to use as symbols
- Only photos you specifically select are accessed
- Photos are copied to app's local storage and never uploaded anywhere

**You can use OpenVoice without granting photo access** - you just can't import custom symbol images.

### Face ID / Face Tracking
**Purpose**: Precise eye gaze detection for hands-free use  
**How It's Used**:
- Enables ARKit face tracking features
- Detects facial position and eye direction
- All processing happens on-device in real-time
- No face data is ever saved or transmitted

**You can use OpenVoice without granting face tracking access** - you just can't use eye tracking features.

### Microphone Access
**Purpose**: Not currently used, may be used for future features  
**How It's Used**:
- OpenVoice does not currently request or use microphone access
- May be used in future updates for speech recognition features
- If implemented, will be entirely on-device

---

## How Your Data is Used

### Local Processing Only

All features of OpenVoice work entirely on your device:

**Text-to-Speech**:
- Uses Apple's built-in iOS speech synthesis
- No data sent to external servers
- Voice processing happens on your device

**Symbol Library**:
- Symbols stored in app bundle or device storage
- Custom symbols saved locally
- No syncing or uploading

**Eye Tracking**:
- ARKit processing happens on-device
- Eye gaze data processed in real-time
- Nothing recorded or saved

**AI Predictions** (Optional):
- CoreML models run entirely on your device
- Predictions based on local usage patterns
- No data sent to external servers

**LLM Features** (Optional, Advanced):
- Only available if YOU run the Python backend
- Backend runs on YOUR computer, not our servers
- We don't operate any servers or backends
- Communication between app and backend stays on your local network

---

## Third-Party Services

### We Do Not Use Any Third-Party Services

OpenVoice does not integrate with:
- Analytics services (no Google Analytics, Firebase, etc.)
- Crash reporting services (no Crashlytics, Sentry, etc.)
- Ad networks (no ads at all)
- Social media platforms
- Cloud storage services
- Any external APIs or services

### Apple Services

The only external entity that may have information about OpenVoice is Apple:
- **App Store**: Apple knows you downloaded OpenVoice
- **iCloud**: If YOU enable device backup, iOS may back up OpenVoice data to YOUR iCloud
- **Apple's TTS**: When you use text-to-speech, Apple's on-device engine processes text

We have no access to any of this information.

---

## Data Security

### How We Protect Your Data

**Local Storage**:
- All data stored using iOS standard security
- Protected by your device's passcode/Face ID/Touch ID
- Encrypted if you have device encryption enabled

**No Transmission**:
- Since data never leaves your device, there's no risk of interception
- No servers to hack
- No databases to breach

**Open Source**:
- OpenVoice is open source (GPL v3)
- You can audit the code yourself
- Community can verify our privacy claims

---

## Your Rights and Choices

### Data Control

You have complete control over your data:

**View Your Data**:
- All data visible in app settings
- Usage statistics in Analytics section
- Speech history in History section

**Delete Your Data**:
- Clear speech history: Settings > Clear History
- Clear custom symbols: Delete individually
- Delete ALL data: Delete the OpenVoice app

**Export Your Data**:
- Export speech history to text file
- Export usage statistics to CSV
- No lock-in, your data is portable

### Opt-Out of Features

You can disable any feature:
- Eye tracking: Settings > Eye Tracking > Off
- Predictions: Settings > Predictions > Off
- Speech history: Settings > Save History > Off
- LLM features: Simply don't run the backend

---

## Children's Privacy

OpenVoice is designed for users of all ages, including children. We do not:
- Collect any information from children
- Target advertising to children (we have no ads)
- Require any personal information
- Create accounts or profiles

Parents can use OpenVoice with confidence that their child's information is not being collected.

---

## Changes to This Policy

We may update this Privacy Policy from time to time. Changes will be posted:
- In the app (Settings > About > Privacy Policy)
- On our website at [INSERT WEBSITE URL]/privacy
- In App Store listing notes

Continued use of OpenVoice after changes means you accept the updated policy.

---

## Open Source

OpenVoice is open source software (GPL v3.0 license). The source code is available at:

**GitHub**: [INSERT GITHUB URL]

You can verify our privacy claims by reviewing the code. We welcome security audits and welcome reports of any privacy concerns.

---

## Medical Disclaimer

OpenVoice is a communication tool, not a medical device. It:
- Is not FDA approved
- Should not replace medical advice
- Is not a treatment for any condition
- Should be used as a communication aid only

Consult with speech therapists and healthcare providers about using AAC tools.

---

## Contact Us

If you have questions about this Privacy Policy or OpenVoice's privacy practices:

**Email**: [INSERT SUPPORT EMAIL]  
**Website**: [INSERT WEBSITE URL]  
**GitHub Issues**: [INSERT GITHUB URL]/issues

We typically respond within 48 hours.

---

## Legal

### Data Controller

[INSERT YOUR NAME/ORGANIZATION]  
[INSERT ADDRESS if required by jurisdiction]

### Jurisdiction

This Privacy Policy is governed by the laws of [INSERT JURISDICTION].

### Compliance

OpenVoice complies with:
- Apple App Store Guidelines
- COPPA (Children's Online Privacy Protection Act)
- GDPR (General Data Protection Regulation) - by not collecting data
- CCPA (California Consumer Privacy Act) - by not collecting data

---

## Summary

**TL;DR**:
- ✅ We collect ZERO data
- ✅ Everything stays on your device
- ✅ No analytics, no tracking, no ads
- ✅ You have complete control
- ✅ Open source and auditable
- ✅ Free forever

**Your privacy is not negotiable.**

---

*OpenVoice Privacy Policy*  
*Version 1.0*  
*Effective: [INSERT DATE]*  

---

## Instructions for Customization

**Before publishing, replace**:
1. `[INSERT DATE]` - Today's date
2. `[INSERT WEBSITE URL]` - Your support website URL
3. `[INSERT SUPPORT EMAIL]` - Your support email
4. `[INSERT GITHUB URL]` - Your GitHub repository URL
5. `[INSERT YOUR NAME/ORGANIZATION]` - Your name or org name
6. `[INSERT ADDRESS if required by jurisdiction]` - Legal address if needed
7. `[INSERT JURISDICTION]` - Your location (e.g., "United States", "California")

**Where to host**:
- On your support website at yoursite.com/privacy
- As a page on GitHub Pages
- As a simple HTML file

**Link in App Store**:
- App Store Connect > App Privacy > Privacy Policy URL
- Enter your hosted URL

**Link in App**:
```swift
// In SettingsView.swift, add:
Link("Privacy Policy", destination: URL(string: "https://yoursite.com/privacy")!)
```

---

**This privacy policy is designed for OpenVoice and can be used as-is after customization. It's written in plain English and accurately reflects OpenVoice's zero-data-collection approach.**
