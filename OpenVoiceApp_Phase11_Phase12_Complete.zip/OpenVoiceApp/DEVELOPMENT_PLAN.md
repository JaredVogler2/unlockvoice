# OpenVoice Development Plan
## Complete Roadmap from Foundation to App Store

## 🎯 Project Overview

**Goal**: Build a fully-featured, free AAC application with eye tracking, AI predictions, and no gatekeeping

**Timeline**: 6-10 months (depending on experience and available time)

**Status**: Phase 1 Complete ✅

---

## 📊 Phase Breakdown

### ✅ PHASE 1: FOUNDATION (COMPLETE - Weeks 1-2)

**Deliverables**:
- [x] App architecture (MVVM)
- [x] Navigation structure
- [x] Symbol model and grid UI
- [x] Phrase building system
- [x] Speech service
- [x] Settings interface
- [x] Basic prediction system

**Testing Checklist**:
- [x] App launches without crashing
- [x] Symbols display in grid
- [x] Tapping symbols adds to phrase
- [x] Speak button produces audio
- [x] Settings can be modified
- [x] App state persists

**Files Created** (14 files):
```
✅ OpenVoiceApp.swift
✅ ContentView.swift
✅ Models/Symbol.swift
✅ Models/Phrase.swift
✅ Models/UserProfile.swift
✅ Views/SymbolGridView.swift
✅ Views/PhraseBarView.swift
✅ Views/PredictionBarView.swift
✅ Views/SettingsView.swift
✅ Views/CalibrationView.swift
✅ ViewModels/SymbolGridViewModel.swift
✅ ViewModels/PredictionViewModel.swift
✅ Services/SpeechService.swift
✅ README.md
```

---

### 🔄 PHASE 2: SYMBOL LIBRARY (Weeks 3-4)

**Goal**: Integrate Mulberry symbols and build robust symbol management

**Tasks**:
1. Download Mulberry Symbols library (3,000+ symbols)
2. Create asset catalog organization
3. Implement category-based browsing
4. Add symbol search functionality
5. Build symbol editor for custom symbols
6. Implement photo import from camera
7. Create symbol export/import system

**New Files**:
```
Services/SymbolLibraryService.swift
Models/SymbolLibrary.swift
Views/SymbolBrowserView.swift
Views/SymbolEditorView.swift
Views/CategorySelectorView.swift
Resources/Assets.xcassets/ (with Mulberry symbols)
```

**Code Tasks**:
```swift
// 1. Symbol Library Service
class SymbolLibraryService {
    func loadMulberrySymbols() -> [Symbol]
    func categorizeSymbols(_ symbols: [Symbol]) -> [SymbolCategory: [Symbol]]
    func searchSymbols(query: String) -> [Symbol]
    func importCustomSymbol(from image: UIImage) -> Symbol
}

// 2. Category Browsing
struct CategoryBrowserView: View {
    // Display symbols by category
    // Allow filtering and sorting
}

// 3. Custom Symbol Creation
struct SymbolEditorView: View {
    // Photo picker integration
    // Image cropping
    // Label editing
    // Category assignment
}
```

**Testing Checklist**:
- [ ] 100+ Mulberry symbols load correctly
- [ ] Categories display properly
- [ ] Search finds relevant symbols
- [ ] Can take photo and create symbol
- [ ] Custom symbols persist
- [ ] Symbol library is performant (no lag)

**Resources Needed**:
- Mulberry Symbols: https://www.mulberrysymbols.org/
- PHPickerViewController documentation
- UIImage processing tutorials

---

### 🎤 PHASE 3: TEXT-TO-SPEECH ENHANCEMENT (Week 5)

**Goal**: Polish and enhance speech output

**Status**: Core implementation done ✅, enhancements needed

**Tasks**:
1. Voice customization UI improvements
2. Speech rate and pitch fine-tuning
3. Pronunciation dictionary
4. SSML support for emphasis
5. Speech history playback
6. Volume control integration
7. Voice preview before selection

**Enhancements**:
```swift
// 1. Pronunciation Dictionary
class PronunciationService {
    var customPronunciations: [String: String] = [:]
    
    func applyPronunciation(to text: String) -> String {
        // Replace words with phonetic spellings
    }
}

// 2. SSML Support
extension SpeechService {
    func speakWithSSML(_ ssml: String) {
        // Add emphasis, pauses, etc.
    }
}

// 3. Voice Characteristics
struct VoiceProfile: Codable {
    var identifier: String
    var rate: Float
    var pitch: Float
    var volume: Float
    var customizations: [String: Any]
}
```

**Testing Checklist**:
- [ ] All iOS voices available
- [ ] Voice selection persists
- [ ] Pronunciation dictionary works
- [ ] Can preview voices
- [ ] Volume adjustable
- [ ] Rate/pitch sound natural

---

### 👁️ PHASE 4: ARKIT EYE TRACKING (Weeks 6-8) ⚡ COMPLEX

**Goal**: Implement hands-free symbol selection via eye gaze

**This is the most complex phase** - requires:
- ARKit knowledge
- 3D geometry understanding
- Real-time performance optimization
- Calibration algorithms

**Tasks**:
1. ARKit face tracking setup
2. Eye gaze vector calculation
3. Screen coordinate projection
4. Dwell-time selection implementation
5. 9-point calibration system
6. Calibration data persistence
7. Gaze indicator overlay
8. Performance optimization (60 FPS)
9. Accessibility settings for tracking

**New Files**:
```
Core/EyeTracking/EyeTrackingManager.swift
Core/EyeTracking/GazeCalculator.swift
Core/EyeTracking/DwellTimeDetector.swift
Core/Calibration/CalibrationEngine.swift
Core/Calibration/CalibrationViewModel.swift
Views/EyeTrackingDebugView.swift (for testing)
```

**Key Code Components**:
```swift
// 1. ARKit Setup
import ARKit

class EyeTrackingManager: NSObject, ARSCNViewDelegate {
    private var sceneView: ARSCNView!
    private var configuration: ARFaceTrackingConfiguration!
    
    func startTracking() {
        configuration = ARFaceTrackingConfiguration()
        sceneView.session.run(configuration)
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let faceAnchor = anchor as? ARFaceAnchor else { return }
        
        // Get eye look-at points
        let leftEye = faceAnchor.lookAtPoint(forEye: .left)
        let rightEye = faceAnchor.lookAtPoint(forEye: .right)
        
        // Calculate gaze point
        let gazePoint = calculateGazePoint(left: leftEye, right: rightEye)
        
        // Check for dwell time
        checkDwellTime(at: gazePoint)
    }
}

// 2. Gaze Calculation
class GazeCalculator {
    func projectToScreen(gazeVector: simd_float3) -> CGPoint {
        // Convert 3D eye vector to 2D screen coordinates
    }
    
    func applyCalibration(_ point: CGPoint, with calibrationData: CalibrationData) -> CGPoint {
        // Apply calibration correction
    }
}

// 3. Dwell Time Detection
class DwellTimeDetector {
    private var dwellStartTime: Date?
    private var dwellPoint: CGPoint?
    
    func update(gazePoint: CGPoint, threshold: Double) -> Bool {
        // Return true if dwell time threshold reached
    }
}

// 4. Calibration
class CalibrationEngine {
    func performCalibration(points: [CGPoint], completion: @escaping (CalibrationData) -> Void) {
        // Show calibration targets
        // Collect gaze data at each point
        // Calculate offset matrix
        // Return calibration data
    }
}
```

**Testing Checklist**:
- [ ] ARKit face tracking active
- [ ] Eye gaze detected accurately (<2° error)
- [ ] Calibration completes successfully
- [ ] Dwell time selection works
- [ ] 60 FPS maintained
- [ ] Works in various lighting
- [ ] Handles face tracking loss gracefully
- [ ] Calibration persists between sessions

**Resources**:
- Apple ARKit documentation
- WWDC videos on face tracking
- Academic papers on eye tracking algorithms
- Community examples on GitHub

**⚠️ Complexity Warning**:
This phase may require:
- Hiring an AR specialist (optional)
- Extended timeline (3-4 weeks instead of 2)
- Extensive testing with different users
- Debugging 3D geometry issues

---

### 💾 PHASE 5: DATA PERSISTENCE (Weeks 9-10)

**Goal**: Robust local database for all user data

**Tasks**:
1. Core Data model design
2. Migration system
3. Conversation history storage
4. Custom symbols database
5. Usage analytics (local only)
6. Export/import functionality
7. Backup system

**Data Models**:
```swift
// Core Data Entities

@Entity SymbolEntity {
    @Attribute var id: UUID
    @Attribute var label: String
    @Attribute var category: String
    @Attribute var imageData: Data?
    @Attribute var frequency: Int
    @Attribute var lastUsed: Date
    @Relationship var phrases: [PhraseEntity]
}

@Entity PhraseEntity {
    @Attribute var id: UUID
    @Attribute var timestamp: Date
    @Attribute var text: String
    @Attribute var wasSpoken: Bool
    @Relationship var symbols: [SymbolEntity]
}

@Entity UserProfileEntity {
    @Attribute var id: UUID
    @Attribute var name: String
    @Attribute var settings: Data // Encoded JSON
    @Attribute var calibrationData: Data?
    @Relationship var phrases: [PhraseEntity]
    @Relationship var customSymbols: [SymbolEntity]
}
```

**Services**:
```
Services/DataService.swift
Services/ExportService.swift
Services/BackupService.swift
Models/CoreDataModels.xcdatamodeld
```

**Testing Checklist**:
- [ ] Data persists across app restarts
- [ ] Large datasets handled efficiently
- [ ] Export/import works
- [ ] Migration doesn't lose data
- [ ] Performance is acceptable (<100ms queries)

---

### 🧠 PHASE 6: COREML INTEGRATION (Weeks 11-12)

**Goal**: On-device machine learning for predictions

**Tasks**:
1. Train/convert prediction model
2. Integrate CoreML
3. Create MLModel assets
4. Build inference pipeline
5. Optimize for latency
6. A/B test predictions

**Models to Create**:
```
1. Word Prediction Model (N-gram or small transformer)
   - Input: Previous 3-5 symbols
   - Output: Top 10 next symbols with probabilities

2. Context Model
   - Input: Time of day, recent symbols, frequency data
   - Output: Contextually relevant symbols

3. Grammar Model (Simple)
   - Input: Symbol sequence
   - Output: Grammaticality score
```

**Implementation**:
```swift
import CoreML

class MLPredictionService {
    private var model: WordPredictionModel!
    
    func loadModel() {
        guard let modelURL = Bundle.main.url(forResource: "WordPredictor", withExtension: "mlmodelc") else { return }
        model = try? WordPredictionModel(contentsOf: modelURL)
    }
    
    func predict(context: [String], maxPredictions: Int = 10) -> [Prediction] {
        let input = WordPredictionInput(words: context)
        guard let output = try? model.prediction(input: input) else { return [] }
        
        return output.predictions.map { word, prob in
            Prediction(text: word, confidence: prob, source: .coreMl)
        }
    }
}
```

**Testing Checklist**:
- [ ] Model loads successfully
- [ ] Predictions returned in <50ms
- [ ] Predictions are relevant
- [ ] Model doesn't crash on edge cases
- [ ] Battery impact is minimal

---

### 🖥️ PHASE 7: PYTHON BACKEND (Weeks 13-14)

**Goal**: Backend services for advanced ML features

**Setup**:
```bash
# Project structure
python-backend/
├── src/
│   ├── main.py
│   ├── models/
│   │   ├── rag_engine.py
│   │   ├── sentence_former.py
│   │   ├── predictor.py
│   │   └── image_gen.py
│   ├── api/
│   │   └── endpoints.py
│   └── services/
│       └── model_loader.py
├── requirements.txt
├── Dockerfile
└── docker-compose.yml
```

**FastAPI Setup**:
```python
# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="OpenVoice ML API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.post("/predict")
async def predict(request: PredictionRequest):
    # Use ML models for predictions
    pass

@app.post("/sentence/form")
async def form_sentence(request: SentenceRequest):
    # Use BERT for grammar
    pass
```

**iOS Integration**:
```swift
class APIService {
    private let baseURL = "http://localhost:8000"
    
    func getPredictions(context: [String]) async throws -> [Prediction] {
        let url = URL(string: "\(baseURL)/predict")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body = ["context": context]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode([Prediction].self, from: data)
    }
}
```

**Testing**:
- [ ] API responds to health checks
- [ ] iOS can connect to backend
- [ ] Requests complete in <100ms
- [ ] Error handling works

---

### 🔮 PHASE 8: RAG SYSTEM (Weeks 15-17) ⚡ COMPLEX

**Goal**: Personalized predictions based on conversation history

**Architecture**:
```
User speaks → Conversation saved → Embedded → Stored in FAISS
Next time → Query embeddings → Find similar → Predict next words
```

**Python Implementation**:
```python
# rag_engine.py
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

class RAGEngine:
    def __init__(self):
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.index = faiss.IndexFlatL2(384)  # 384 is embedding dimension
        self.conversations = []
    
    def add_conversation(self, text: str):
        embedding = self.model.encode([text])[0]
        self.index.add(np.array([embedding]))
        self.conversations.append(text)
    
    def search(self, query: str, k: int = 5):
        query_embedding = self.model.encode([query])[0]
        distances, indices = self.index.search(np.array([query_embedding]), k)
        return [self.conversations[i] for i in indices[0]]
    
    def predict_next(self, current_phrase: str, n: int = 10):
        # Find similar past conversations
        similar = self.search(current_phrase, k=20)
        
        # Extract next words from similar conversations
        # Use frequency and context to rank
        # Return top N predictions
        pass
```

**Testing**:
- [ ] Embeddings generated correctly
- [ ] Search returns relevant results
- [ ] Predictions improve over time
- [ ] Performance acceptable (<50ms)
- [ ] Privacy maintained (local storage)

---

### 📝 PHASE 9: BERT SENTENCE FORMATION (Weeks 18-19)

**Goal**: Transform symbol sequences into natural language

**Example**:
```
Input:  "want eat pizza now"
Output: "I want to eat pizza now"

Input:  "bathroom need help"
Output: "I need help with the bathroom"
```

**Implementation**:
```python
# sentence_former.py
from transformers import pipeline

class SentenceFormer:
    def __init__(self):
        self.model = pipeline("text2text-generation", model="google/flan-t5-base")
    
    def form_sentence(self, symbols: list[str]) -> str:
        prompt = f"Complete this sentence naturally: {' '.join(symbols)}"
        result = self.model(prompt, max_length=50)[0]['generated_text']
        return result
```

**Testing**:
- [ ] Grammar improvements work
- [ ] Meaning preserved
- [ ] Latency acceptable (100-300ms)
- [ ] Works offline (model cached)

---

### 🤖 PHASE 10: LOCAL LLM (Weeks 20-22)

**Goal**: On-device language model for advanced features

**MLX Integration** (Apple Silicon):
```python
import mlx.core as mx
from mlx_lm import load, generate

class LocalLLM:
    def __init__(self):
        self.model, self.tokenizer = load("mlx-community/Mistral-7B-Instruct-v0.2-4bit")
    
    def complete(self, prompt: str) -> str:
        response = generate(self.model, self.tokenizer, prompt, max_tokens=100)
        return response
```

---

### 🎨 PHASE 11: IMAGE GENERATION (Weeks 23-24)

**Goal**: AI-generated custom symbols

**Stable Diffusion Integration**:
```python
from diffusers import StableDiffusionPipeline

class ImageGenerator:
    def __init__(self):
        self.pipe = StableDiffusionPipeline.from_pretrained(
            "stabilityai/stable-diffusion-2-1",
            torch_dtype=torch.float16
        )
    
    def generate_symbol(self, prompt: str) -> Image:
        image = self.pipe(
            f"simple icon of {prompt}, flat design, white background",
            num_inference_steps=20
        ).images[0]
        return image
```

---

### 🚀 PHASE 12: APP STORE RELEASE (Weeks 25-28)

**Tasks**:
1. Beta testing with TestFlight
2. Bug fixes and polish
3. App Store assets (screenshots, icon, description)
4. Privacy policy
5. Support website
6. App Store submission
7. Marketing and outreach

**App Store Requirements**:
- [ ] App Icon (1024x1024)
- [ ] Screenshots (all device sizes)
- [ ] Privacy policy URL
- [ ] Support URL
- [ ] Description and keywords
- [ ] Age rating
- [ ] App Review guidelines compliance

---

## 🎯 Success Metrics

- **Performance**: 60 FPS, <100ms latency
- **Accuracy**: >95% eye tracking accuracy
- **Reliability**: <0.1% crash rate
- **Accessibility**: WCAG 2.1 AAA compliant
- **Privacy**: 100% local processing (ML optional)
- **Impact**: 1000+ active users in first year

---

## 📞 Getting Help

- **Swift/iOS**: Apple Developer Forums, Stack Overflow
- **ARKit**: WWDC videos, Apple sample code
- **ML**: Hugging Face forums, PyTorch tutorials
- **Community**: Create Discord/Slack for collaborators

---

**Remember**: This is a marathon, not a sprint. Build incrementally, test thoroughly, and celebrate each milestone! 🎉
