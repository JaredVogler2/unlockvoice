"""
Conversation Analyzer
Provides analytics and insights on conversation patterns
"""

import logging
from typing import List, Dict, Any
from collections import Counter, defaultdict
from datetime import datetime, timedelta
import numpy as np

logger = logging.getLogger(__name__)


class ConversationAnalyzer:
    """
    Analyze conversation patterns and provide insights
    """
    
    def __init__(self, rag_engine):
        """
        Initialize analyzer
        
        Args:
            rag_engine: RAG engine instance
        """
        self.rag_engine = rag_engine
        logger.info("ConversationAnalyzer initialized")
    
    def get_summary(self) -> Dict[str, Any]:
        """
        Get overall conversation summary
        """
        conversations = self.rag_engine.conversations
        
        if not conversations:
            return {
                'total_conversations': 0,
                'date_range': None,
                'avg_length': 0,
                'total_words': 0
            }
        
        # Calculate statistics
        lengths = [len(c['text'].split()) for c in conversations]
        timestamps = [datetime.fromisoformat(c['timestamp']) for c in conversations]
        
        return {
            'total_conversations': len(conversations),
            'date_range': {
                'earliest': min(timestamps).isoformat(),
                'latest': max(timestamps).isoformat()
            },
            'avg_length': np.mean(lengths),
            'total_words': sum(lengths),
            'min_length': min(lengths),
            'max_length': max(lengths)
        }
    
    def get_top_words(self, n: int = 20) -> List[Dict[str, Any]]:
        """
        Get most frequently used words
        """
        conversations = self.rag_engine.conversations
        
        if not conversations:
            return []
        
        # Count words
        word_counts = Counter()
        for conv in conversations:
            words = conv['text'].lower().split()
            word_counts.update(words)
        
        # Filter common stop words
        stop_words = {
            'i', 'want', 'to', 'the', 'a', 'an', 'and', 'or', 'but',
            'is', 'are', 'was', 'were', 'be', 'been', 'being',
            'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
            'could', 'should', 'may', 'might', 'can', 'shall'
        }
        
        top_words = []
        for word, count in word_counts.most_common(n * 2):
            if word not in stop_words and len(word) > 2:
                top_words.append({
                    'word': word,
                    'count': count,
                    'frequency': count / len(conversations)
                })
                if len(top_words) >= n:
                    break
        
        return top_words
    
    def get_top_phrases(self, n: int = 10, phrase_length: int = 2) -> List[Dict[str, Any]]:
        """
        Get most common phrases (n-grams)
        """
        conversations = self.rag_engine.conversations
        
        if not conversations:
            return []
        
        # Count n-grams
        phrase_counts = Counter()
        for conv in conversations:
            words = conv['text'].lower().split()
            if len(words) >= phrase_length:
                for i in range(len(words) - phrase_length + 1):
                    phrase = ' '.join(words[i:i+phrase_length])
                    phrase_counts[phrase] += 1
        
        return [
            {
                'phrase': phrase,
                'count': count,
                'frequency': count / len(conversations)
            }
            for phrase, count in phrase_counts.most_common(n)
        ]
    
    def get_temporal_patterns(self) -> Dict[str, Any]:
        """
        Analyze temporal patterns in conversations
        """
        conversations = self.rag_engine.conversations
        
        if not conversations:
            return {}
        
        # Group by hour of day
        by_hour = defaultdict(int)
        by_day_of_week = defaultdict(int)
        by_date = defaultdict(int)
        
        for conv in conversations:
            timestamp = datetime.fromisoformat(conv['timestamp'])
            by_hour[timestamp.hour] += 1
            by_day_of_week[timestamp.strftime('%A')] += 1
            by_date[timestamp.date().isoformat()] += 1
        
        # Find peak times
        peak_hour = max(by_hour.items(), key=lambda x: x[1])[0] if by_hour else None
        peak_day = max(by_day_of_week.items(), key=lambda x: x[1])[0] if by_day_of_week else None
        
        return {
            'by_hour': dict(by_hour),
            'by_day_of_week': dict(by_day_of_week),
            'peak_hour': peak_hour,
            'peak_day': peak_day,
            'daily_counts': dict(sorted(by_date.items())[-30:])  # Last 30 days
        }
    
    def get_conversation_clusters(self, n_clusters: int = 5) -> List[Dict[str, Any]]:
        """
        Find conversation topic clusters
        """
        conversations = self.rag_engine.conversations
        
        if len(conversations) < n_clusters:
            return []
        
        try:
            # Get embeddings from FAISS index
            embeddings = []
            for i in range(len(conversations)):
                # Get embedding from index
                vec = self.rag_engine.index.reconstruct(i)
                embeddings.append(vec)
            
            embeddings = np.array(embeddings)
            
            # Simple K-means clustering
            from sklearn.cluster import KMeans
            
            kmeans = KMeans(n_clusters=n_clusters, random_state=42)
            labels = kmeans.fit_predict(embeddings)
            
            # Group conversations by cluster
            clusters = defaultdict(list)
            for i, label in enumerate(labels):
                clusters[label].append(conversations[i])
            
            # Get representative conversations for each cluster
            results = []
            for cluster_id, cluster_convs in clusters.items():
                # Get most common words in cluster
                all_words = ' '.join([c['text'].lower() for c in cluster_convs]).split()
                common_words = Counter(all_words).most_common(5)
                
                results.append({
                    'cluster_id': int(cluster_id),
                    'size': len(cluster_convs),
                    'common_words': [w[0] for w in common_words],
                    'sample_conversations': [c['text'] for c in cluster_convs[:3]]
                })
            
            return sorted(results, key=lambda x: x['size'], reverse=True)
            
        except Exception as e:
            logger.error(f"Error clustering conversations: {e}")
            return []
    
    def get_prediction_accuracy_estimate(self) -> Dict[str, Any]:
        """
        Estimate prediction accuracy based on conversation patterns
        """
        conversations = self.rag_engine.conversations
        
        if len(conversations) < 10:
            return {
                'estimated_accuracy': 0,
                'confidence': 'low',
                'sample_size': len(conversations)
            }
        
        # Look for repeated patterns
        bigrams = Counter()
        trigrams = Counter()
        
        for conv in conversations:
            words = conv['text'].lower().split()
            
            # Count bigrams
            for i in range(len(words) - 1):
                bigrams[' '.join(words[i:i+2])] += 1
            
            # Count trigrams
            for i in range(len(words) - 2):
                trigrams[' '.join(words[i:i+3])] += 1
        
        # Calculate repetition score (more repetition = better predictions)
        total_bigrams = sum(bigrams.values())
        total_trigrams = sum(trigrams.values())
        
        unique_bigrams = len(bigrams)
        unique_trigrams = len(trigrams)
        
        if unique_bigrams > 0:
            bigram_repetition = total_bigrams / unique_bigrams
        else:
            bigram_repetition = 0
        
        if unique_trigrams > 0:
            trigram_repetition = total_trigrams / unique_trigrams
        else:
            trigram_repetition = 0
        
        # Estimate accuracy (heuristic)
        avg_repetition = (bigram_repetition + trigram_repetition) / 2
        estimated_accuracy = min(0.95, 0.5 + (avg_repetition / 10))
        
        # Confidence based on sample size
        if len(conversations) < 20:
            confidence = 'low'
        elif len(conversations) < 100:
            confidence = 'medium'
        else:
            confidence = 'high'
        
        return {
            'estimated_accuracy': estimated_accuracy,
            'confidence': confidence,
            'sample_size': len(conversations),
            'pattern_strength': {
                'bigram_repetition': bigram_repetition,
                'trigram_repetition': trigram_repetition,
                'unique_patterns': unique_bigrams + unique_trigrams
            }
        }
    
    def get_user_vocabulary(self) -> Dict[str, Any]:
        """
        Analyze user's vocabulary
        """
        conversations = self.rag_engine.conversations
        
        if not conversations:
            return {
                'vocabulary_size': 0,
                'unique_words': 0,
                'avg_word_length': 0
            }
        
        all_words = []
        for conv in conversations:
            words = conv['text'].lower().split()
            all_words.extend(words)
        
        unique_words = set(all_words)
        
        return {
            'vocabulary_size': len(unique_words),
            'total_words_used': len(all_words),
            'unique_words': len(unique_words),
            'avg_word_length': np.mean([len(w) for w in all_words]) if all_words else 0,
            'longest_word': max(all_words, key=len) if all_words else None,
            'lexical_diversity': len(unique_words) / len(all_words) if all_words else 0
        }
