"""
Model Service - Loads and manages ML models
"""

import logging
from typing import List, Dict, Any, Optional
import asyncio
from datetime import datetime
import json

logger = logging.getLogger(__name__)


class ModelService:
    """
    Service for loading and managing ML models
    """
    
    def __init__(self):
        self.is_ready = False
        self.prediction_count = 0
        self.sentence_count = 0
        self.latencies = []
        self.avg_latency_ms = 0.0
        
        # Model components
        self.ngram_model = None
        self.contextual_model = None
        self.sentence_model = None
        self.rag_engine = None
        
        logger.info("ModelService initialized")
    
    async def initialize(self):
        """
        Initialize all ML models
        """
        try:
            logger.info("Loading ML models...")
            
            # Initialize N-gram model
            from models.predictor import NGramPredictor
            self.ngram_model = NGramPredictor()
            await self.ngram_model.load()
            logger.info("✅ N-gram model loaded")
            
            # Initialize contextual model
            from models.predictor import ContextualPredictor
            self.contextual_model = ContextualPredictor()
            await self.contextual_model.load()
            logger.info("✅ Contextual model loaded")
            
            # Initialize sentence formation model
            from models.sentence_former import SentenceFormer
            self.sentence_model = SentenceFormer()
            await self.sentence_model.load()
            logger.info("✅ Sentence model loaded")
            
            # Initialize RAG engine
            from models.rag_engine import RAGEngine
            self.rag_engine = RAGEngine()
            await self.rag_engine.initialize()
            logger.info("✅ RAG engine initialized")
            
            self.is_ready = True
            logger.info("🎉 All models loaded successfully!")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize models: {e}", exc_info=True)
            raise
    
    async def predict_next(
        self,
        context: List[str],
        max_predictions: int = 10,
        time_of_day: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Predict next words using multiple models
        """
        predictions = []
        
        try:
            # Get N-gram predictions
            ngram_preds = await self.ngram_model.predict(
                context=context,
                max_predictions=max_predictions
            )
            predictions.extend(ngram_preds)
            
            # Get contextual predictions
            if time_of_day:
                context_preds = await self.contextual_model.predict(
                    context=context,
                    time_of_day=time_of_day,
                    max_predictions=max_predictions
                )
                predictions.extend(context_preds)
            
            # Merge and rank predictions
            predictions = self._merge_predictions(predictions, max_predictions)
            
        except Exception as e:
            logger.error(f"Prediction error: {e}", exc_info=True)
            # Return empty list on error rather than failing
            predictions = []
        
        return predictions
    
    async def form_sentence(
        self,
        symbols: List[str],
        preserve_order: bool = True,
        add_grammar: bool = True
    ) -> Dict[str, Any]:
        """
        Form a natural sentence from symbols
        """
        try:
            result = await self.sentence_model.form_sentence(
                symbols=symbols,
                preserve_order=preserve_order,
                add_grammar=add_grammar
            )
            return result
            
        except Exception as e:
            logger.error(f"Sentence formation error: {e}", exc_info=True)
            # Fallback: just join symbols
            return {
                'sentence': ' '.join(symbols),
                'confidence': 0.5,
                'grammar_changes': []
            }
    
    async def rag_predict(
        self,
        current_phrase: str,
        conversation_history: List[str],
        k: int = 5
    ) -> Dict[str, Any]:
        """
        Use RAG to predict next words based on conversation history
        """
        try:
            result = await self.rag_engine.predict(
                current_phrase=current_phrase,
                conversation_history=conversation_history,
                k=k
            )
            return result
            
        except Exception as e:
            logger.error(f"RAG prediction error: {e}", exc_info=True)
            return {
                'predictions': [],
                'similar_contexts': [],
                'relevance_scores': []
            }
    
    async def add_conversation(self, conversation: Dict[str, Any]):
        """
        Add conversation to RAG system
        """
        try:
            await self.rag_engine.add_conversation(conversation)
        except Exception as e:
            logger.error(f"Add conversation error: {e}", exc_info=True)
    
    def _merge_predictions(
        self,
        predictions: List[Dict[str, Any]],
        max_predictions: int
    ) -> List[Dict[str, Any]]:
        """
        Merge predictions from multiple sources
        """
        # Group by text
        merged = {}
        for pred in predictions:
            text = pred['text']
            if text in merged:
                # Average confidence scores
                merged[text]['confidence'] = (
                    merged[text]['confidence'] + pred['confidence']
                ) / 2
                merged[text]['source'] = 'hybrid'
            else:
                merged[text] = pred
        
        # Sort by confidence and take top N
        sorted_preds = sorted(
            merged.values(),
            key=lambda x: x['confidence'],
            reverse=True
        )
        
        return sorted_preds[:max_predictions]
    
    def update_latency(self, latency_ms: float):
        """
        Update latency statistics
        """
        self.latencies.append(latency_ms)
        # Keep only last 100 measurements
        if len(self.latencies) > 100:
            self.latencies = self.latencies[-100:]
        
        # Calculate average
        self.avg_latency_ms = sum(self.latencies) / len(self.latencies)
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Get information about loaded models
        """
        return {
            'ngram_model': {
                'loaded': self.ngram_model is not None,
                'type': 'N-gram language model',
                'version': '1.0.0'
            },
            'contextual_model': {
                'loaded': self.contextual_model is not None,
                'type': 'Contextual predictor',
                'version': '1.0.0'
            },
            'sentence_model': {
                'loaded': self.sentence_model is not None,
                'type': 'Sentence formation (T5/BERT)',
                'version': '1.0.0'
            },
            'rag_engine': {
                'loaded': self.rag_engine is not None,
                'type': 'RAG with FAISS',
                'version': '1.0.0'
            }
        }
    
    async def reload_models(self):
        """
        Reload all models
        """
        logger.info("Reloading models...")
        self.is_ready = False
        await self.initialize()
    
    async def cleanup(self):
        """
        Cleanup resources
        """
        logger.info("Cleaning up model service...")
        # Add any cleanup code here
        self.is_ready = False
