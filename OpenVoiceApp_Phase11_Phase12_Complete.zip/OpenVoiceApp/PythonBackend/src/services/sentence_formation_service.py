"""
Phase 9: Advanced Sentence Formation Service
Orchestrates transformer models, grammar correction, and context awareness
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
from .transformer_sentence_former import (
    TransformerSentenceFormer,
    GrammarCorrector,
    ContextAwareEnhancer
)
from .sentence_former import SentenceFormer  # Phase 7 rule-based fallback

logger = logging.getLogger(__name__)


class AdvancedSentenceFormationService:
    """
    Complete sentence formation service
    Combines transformer models, grammar correction, and context awareness
    """
    
    def __init__(
        self,
        model_name: str = "google/flan-t5-small",
        use_grammar_correction: bool = True,
        use_context: bool = True,
        fallback_to_rules: bool = True
    ):
        """
        Initialize advanced sentence formation service
        
        Args:
            model_name: Transformer model to use
            use_grammar_correction: Enable grammar correction
            use_context: Enable context-aware generation
            fallback_to_rules: Use rule-based fallback if transformers fail
        """
        self.model_name = model_name
        self.use_grammar_correction = use_grammar_correction
        self.use_context = use_context
        self.fallback_to_rules = fallback_to_rules
        
        # Initialize components
        self.transformer = TransformerSentenceFormer(model_name=model_name)
        self.grammar_corrector = GrammarCorrector(model_name=model_name) if use_grammar_correction else None
        self.context_enhancer = ContextAwareEnhancer() if use_context else None
        self.rule_based = SentenceFormer() if fallback_to_rules else None
        
        self.is_loaded = False
        
        # Statistics
        self.stats = {
            'total_formations': 0,
            'transformer_success': 0,
            'grammar_corrections': 0,
            'context_used': 0,
            'fallback_used': 0
        }
        
        logger.info(f"AdvancedSentenceFormationService initialized")
    
    async def load(self):
        """Load all models"""
        try:
            start_time = datetime.now()
            
            # Load transformer
            logger.info("Loading transformer model...")
            await self.transformer.load()
            
            # Load grammar corrector
            if self.grammar_corrector:
                logger.info("Loading grammar correction model...")
                await self.grammar_corrector.load()
            
            # Load rule-based fallback
            if self.rule_based:
                await self.rule_based.load()
            
            self.is_loaded = True
            
            load_time = (datetime.now() - start_time).total_seconds()
            logger.info(f"All models loaded in {load_time:.2f}s")
            
        except Exception as e:
            logger.error(f"Failed to load sentence formation service: {e}")
            raise
    
    async def form_sentence(
        self,
        symbols: List[str],
        mode: str = "auto",
        temperature: float = 0.7,
        correct_grammar: bool = True,
        return_alternatives: bool = False
    ) -> Dict[str, Any]:
        """
        Form a natural sentence from AAC symbols
        
        Args:
            symbols: List of AAC symbol words
            mode: Generation mode ('auto', 'transformer', 'rules', 'hybrid')
            temperature: Creativity level (0.0 = conservative, 1.0 = creative)
            correct_grammar: Apply grammar correction
            return_alternatives: Return multiple options
            
        Returns:
            Dict with formed sentence, confidence, alternatives, and metadata
        """
        try:
            self.stats['total_formations'] += 1
            
            if not symbols:
                return self._empty_response()
            
            start_time = datetime.now()
            
            # Get conversation context
            context = self.context_enhancer.get_context() if self.use_context else None
            
            # Choose generation strategy
            if mode == "auto":
                # Try transformer first, fallback to rules
                result = await self._auto_mode(
                    symbols, context, temperature, return_alternatives
                )
            elif mode == "transformer":
                # Transformer only
                result = await self._transformer_mode(
                    symbols, context, temperature, return_alternatives
                )
            elif mode == "rules":
                # Rule-based only
                result = await self._rules_mode(symbols)
            elif mode == "hybrid":
                # Combine both approaches
                result = await self._hybrid_mode(
                    symbols, context, temperature
                )
            else:
                raise ValueError(f"Unknown mode: {mode}")
            
            # Apply grammar correction if enabled
            if correct_grammar and self.grammar_corrector and result.get('sentence'):
                result = await self._apply_grammar_correction(result)
            
            # Update context
            if self.use_context and result.get('sentence'):
                self.context_enhancer.add_to_context(result['sentence'])
                self.stats['context_used'] += 1
            
            # Add timing
            total_time = (datetime.now() - start_time).total_seconds()
            result['metadata']['total_time_ms'] = int(total_time * 1000)
            result['metadata']['mode'] = mode
            
            return result
            
        except Exception as e:
            logger.error(f"Sentence formation error: {e}")
            return self._error_response(symbols, str(e))
    
    async def _auto_mode(
        self,
        symbols: List[str],
        context: Optional[List[str]],
        temperature: float,
        return_alternatives: bool
    ) -> Dict[str, Any]:
        """Auto mode: Try transformer, fallback to rules"""
        try:
            # Try transformer first
            result = await self.transformer.form_sentence(
                symbols=symbols,
                context=context,
                temperature=temperature,
                return_alternatives=return_alternatives
            )
            
            self.stats['transformer_success'] += 1
            return result
            
        except Exception as e:
            logger.warning(f"Transformer failed, using fallback: {e}")
            
            if self.rule_based:
                self.stats['fallback_used'] += 1
                result = await self.rule_based.form_sentence(symbols)
                result['metadata']['fallback'] = True
                result['metadata']['fallback_reason'] = str(e)
                return result
            else:
                raise
    
    async def _transformer_mode(
        self,
        symbols: List[str],
        context: Optional[List[str]],
        temperature: float,
        return_alternatives: bool
    ) -> Dict[str, Any]:
        """Transformer-only mode"""
        result = await self.transformer.form_sentence(
            symbols=symbols,
            context=context,
            temperature=temperature,
            return_alternatives=return_alternatives
        )
        self.stats['transformer_success'] += 1
        return result
    
    async def _rules_mode(self, symbols: List[str]) -> Dict[str, Any]:
        """Rule-based only mode"""
        if not self.rule_based:
            raise RuntimeError("Rule-based fallback not available")
        
        result = await self.rule_based.form_sentence(symbols)
        result['metadata']['mode'] = 'rules'
        return result
    
    async def _hybrid_mode(
        self,
        symbols: List[str],
        context: Optional[List[str]],
        temperature: float
    ) -> Dict[str, Any]:
        """
        Hybrid mode: Generate with both methods and choose best
        """
        # Generate with transformer
        transformer_result = await self.transformer.form_sentence(
            symbols=symbols,
            context=context,
            temperature=temperature,
            return_alternatives=False
        )
        
        # Generate with rules
        rules_result = await self.rule_based.form_sentence(symbols) if self.rule_based else None
        
        # Compare and choose best
        if rules_result:
            # Choose based on confidence
            if transformer_result['confidence'] >= rules_result['confidence']:
                result = transformer_result
                result['metadata']['hybrid_choice'] = 'transformer'
            else:
                result = rules_result
                result['metadata']['hybrid_choice'] = 'rules'
            
            # Add alternative
            result['alternatives'] = [
                transformer_result['sentence'],
                rules_result['sentence']
            ]
        else:
            result = transformer_result
        
        return result
    
    async def _apply_grammar_correction(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """Apply grammar correction to result"""
        try:
            correction = await self.grammar_corrector.correct(result['sentence'])
            
            if correction['changed']:
                self.stats['grammar_corrections'] += 1
                
                # Update result
                result['original_sentence'] = result['sentence']
                result['sentence'] = correction['corrected']
                result['grammar_corrections'] = correction['changes']
                result['metadata']['grammar_corrected'] = True
            
            return result
            
        except Exception as e:
            logger.error(f"Grammar correction failed: {e}")
            return result
    
    def _empty_response(self) -> Dict[str, Any]:
        """Response for empty input"""
        return {
            'sentence': '',
            'confidence': 0.0,
            'alternatives': [],
            'metadata': {'empty_input': True}
        }
    
    def _error_response(self, symbols: List[str], error: str) -> Dict[str, Any]:
        """Response for errors"""
        # Try simple fallback
        sentence = ' '.join(symbols)
        if sentence:
            sentence = sentence[0].upper() + sentence[1:] + '.'
        
        return {
            'sentence': sentence,
            'confidence': 0.3,
            'alternatives': [],
            'metadata': {
                'error': error,
                'fallback': True
            }
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """Get service statistics"""
        transformer_stats = self.transformer.get_stats() if self.transformer else {}
        
        return {
            'service': self.stats.copy(),
            'transformer': transformer_stats,
            'models': {
                'transformer': self.model_name,
                'grammar_correction': self.use_grammar_correction,
                'context_aware': self.use_context,
                'rule_fallback': self.fallback_to_rules
            },
            'is_loaded': self.is_loaded
        }
    
    def clear_context(self):
        """Clear conversation context"""
        if self.context_enhancer:
            self.context_enhancer.clear_context()
            logger.info("Context cleared")


class SentenceFormationCache:
    """
    Cache for sentence formations
    Speeds up repeated symbol sequences
    """
    
    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.cache = {}
        self.hits = 0
        self.misses = 0
        logger.info(f"SentenceFormationCache initialized (max_size={max_size})")
    
    def get(self, symbols: List[str]) -> Optional[Dict[str, Any]]:
        """Get cached result"""
        key = self._make_key(symbols)
        
        if key in self.cache:
            self.hits += 1
            logger.debug(f"Cache hit for: {symbols}")
            return self.cache[key]
        else:
            self.misses += 1
            return None
    
    def put(self, symbols: List[str], result: Dict[str, Any]):
        """Cache a result"""
        key = self._make_key(symbols)
        
        # Evict oldest if full
        if len(self.cache) >= self.max_size:
            oldest = next(iter(self.cache))
            del self.cache[oldest]
        
        self.cache[key] = result
        logger.debug(f"Cached result for: {symbols}")
    
    def _make_key(self, symbols: List[str]) -> str:
        """Create cache key from symbols"""
        return '|'.join(s.lower() for s in symbols)
    
    def clear(self):
        """Clear cache"""
        self.cache.clear()
        logger.info("Cache cleared")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total = self.hits + self.misses
        hit_rate = (self.hits / total) if total > 0 else 0
        
        return {
            'size': len(self.cache),
            'max_size': self.max_size,
            'hits': self.hits,
            'misses': self.misses,
            'hit_rate': round(hit_rate, 3)
        }
