"""
Phase 10: LLM API Endpoints
FastAPI routes for local LLM integration
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import logging
import time

from models.mlx_engine import get_mlx_engine, LLMConfig

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/api/v1/llm", tags=["llm"])


# Request Models
class EnhanceRequest(BaseModel):
    """Request to enhance AAC symbols"""
    symbols: List[str] = Field(..., description="AAC symbols to enhance")
    context: Optional[Dict[str, Any]] = Field(None, description="Additional context")
    use_memory: bool = Field(True, description="Use conversation memory")


class GenerateRequest(BaseModel):
    """Generic generation request"""
    symbols: List[str] = Field(..., description="Input symbols")
    task: str = Field("enhance", description="Task type: enhance, predict, question, intent")
    additional_context: Optional[str] = Field(None, description="Additional context")
    use_memory: bool = Field(True, description="Use conversation memory")
    max_tokens: Optional[int] = Field(100, description="Maximum tokens to generate")
    temperature: Optional[float] = Field(0.7, description="Sampling temperature")


class QuestionRequest(BaseModel):
    """Request to answer a question"""
    question: str = Field(..., description="Question about the conversation")


class ConfigUpdateRequest(BaseModel):
    """Request to update LLM configuration"""
    model_name: Optional[str] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None


# Response Models
class EnhanceResponse(BaseModel):
    """Response from enhancement"""
    sentence: str
    confidence: float
    suggestions: List[str]
    intent: str
    urgency: str
    latency_ms: float
    model: str


class GenerateResponse(BaseModel):
    """Generic generation response"""
    text: str
    confidence: float
    tokens: int
    latency_ms: float
    model: str
    finish_reason: str


class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    phase: int
    is_loaded: bool
    model: Optional[str]
    mlx_available: bool


class StatsResponse(BaseModel):
    """Statistics response"""
    is_loaded: bool
    model: str
    total_generations: int
    total_tokens: int
    errors: int
    avg_latency_ms: float
    avg_tokens: float
    mlx_available: bool


# Endpoints

@router.get("/health", response_model=HealthResponse)
async def health_check():
    """Check Phase 10 LLM health"""
    engine = get_mlx_engine()
    
    try:
        stats = engine.get_stats()
        
        return HealthResponse(
            status="healthy" if stats["mlx_available"] else "limited",
            phase=10,
            is_loaded=stats["is_loaded"],
            model=stats["model"] if stats["is_loaded"] else None,
            mlx_available=stats["mlx_available"]
        )
    except Exception as e:
        logger.error(f"Health check error: {e}")
        return HealthResponse(
            status="error",
            phase=10,
            is_loaded=False,
            model=None,
            mlx_available=False
        )


@router.post("/enhance", response_model=EnhanceResponse)
async def enhance_communication(request: EnhanceRequest):
    """
    Enhance AAC communication with LLM
    
    Converts simple AAC symbols into natural, contextual language
    with smart suggestions and intent detection.
    """
    try:
        engine = get_mlx_engine()
        
        # Load model if not loaded
        if not engine.is_loaded:
            logger.info("Loading model for first request...")
            success = await engine.load_model()
            if not success:
                raise HTTPException(
                    status_code=503,
                    detail="Model failed to load. MLX may not be available."
                )
        
        # Enhance communication
        result = await engine.enhance_communication(
            symbols=request.symbols,
            context=request.context
        )
        
        return EnhanceResponse(**result)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Enhancement error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Enhancement failed: {str(e)}"
        )


@router.post("/generate", response_model=GenerateResponse)
async def generate_text(request: GenerateRequest):
    """
    Generic text generation endpoint
    
    Supports multiple tasks:
    - enhance: Convert symbols to natural language
    - predict: Predict next likely symbols
    - question: Answer questions about conversation
    - intent: Detect intent and urgency
    """
    try:
        engine = get_mlx_engine()
        
        # Load model if not loaded
        if not engine.is_loaded:
            success = await engine.load_model()
            if not success:
                raise HTTPException(
                    status_code=503,
                    detail="Model failed to load"
                )
        
        # Update config if needed
        if request.max_tokens:
            engine.config.max_tokens = request.max_tokens
        if request.temperature:
            engine.config.temperature = request.temperature
        
        # Generate
        result = await engine.generate(
            symbols=request.symbols,
            task=request.task,
            additional_context=request.additional_context,
            use_memory=request.use_memory
        )
        
        return GenerateResponse(
            text=result.text,
            confidence=result.confidence,
            tokens=result.tokens,
            latency_ms=result.latency_ms,
            model=result.model,
            finish_reason=result.finish_reason
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Generation error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Generation failed: {str(e)}"
        )


@router.post("/question")
async def answer_question(request: QuestionRequest):
    """Answer a question about the conversation"""
    try:
        engine = get_mlx_engine()
        
        if not engine.is_loaded:
            raise HTTPException(
                status_code=503,
                detail="Model not loaded"
            )
        
        # Convert question to symbols for generation
        question_symbols = request.question.split()
        
        result = await engine.generate(
            symbols=question_symbols,
            task="question",
            use_memory=False
        )
        
        return {
            "question": request.question,
            "answer": result.text,
            "confidence": result.confidence,
            "latency_ms": result.latency_ms
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Question answering error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Question answering failed: {str(e)}"
        )


@router.get("/stats", response_model=StatsResponse)
async def get_statistics():
    """Get LLM engine statistics"""
    try:
        engine = get_mlx_engine()
        stats = engine.get_stats()
        
        return StatsResponse(**stats)
        
    except Exception as e:
        logger.error(f"Stats error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get stats: {str(e)}"
        )


@router.post("/memory/clear")
async def clear_memory():
    """Clear conversation memory"""
    try:
        engine = get_mlx_engine()
        engine.clear_memory()
        
        return {"status": "success", "message": "Memory cleared"}
        
    except Exception as e:
        logger.error(f"Memory clear error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to clear memory: {str(e)}"
        )


@router.post("/model/load")
async def load_model(background_tasks: BackgroundTasks):
    """Load the LLM model"""
    try:
        engine = get_mlx_engine()
        
        if engine.is_loaded:
            return {
                "status": "already_loaded",
                "model": engine.config.model_name
            }
        
        # Load in background
        background_tasks.add_task(engine.load_model)
        
        return {
            "status": "loading",
            "model": engine.config.model_name,
            "message": "Model loading in background"
        }
        
    except Exception as e:
        logger.error(f"Model load error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to load model: {str(e)}"
        )


@router.post("/model/unload")
async def unload_model():
    """Unload the model to free memory"""
    try:
        engine = get_mlx_engine()
        await engine.unload_model()
        
        return {
            "status": "success",
            "message": "Model unloaded"
        }
        
    except Exception as e:
        logger.error(f"Model unload error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to unload model: {str(e)}"
        )


@router.post("/config/update")
async def update_config(request: ConfigUpdateRequest):
    """Update LLM configuration"""
    try:
        engine = get_mlx_engine()
        
        updated = []
        if request.model_name:
            engine.config.model_name = request.model_name
            updated.append("model_name")
            # Need to reload if model changes
            if engine.is_loaded:
                await engine.unload_model()
        
        if request.max_tokens:
            engine.config.max_tokens = request.max_tokens
            updated.append("max_tokens")
        
        if request.temperature:
            engine.config.temperature = request.temperature
            updated.append("temperature")
        
        if request.top_p:
            engine.config.top_p = request.top_p
            updated.append("top_p")
        
        return {
            "status": "success",
            "updated": updated,
            "config": {
                "model_name": engine.config.model_name,
                "max_tokens": engine.config.max_tokens,
                "temperature": engine.config.temperature,
                "top_p": engine.config.top_p
            }
        }
        
    except Exception as e:
        logger.error(f"Config update error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to update config: {str(e)}"
        )


@router.post("/test")
async def test_generation():
    """Test LLM generation with sample data"""
    try:
        engine = get_mlx_engine()
        
        if not engine.is_loaded:
            success = await engine.load_model()
            if not success:
                raise HTTPException(
                    status_code=503,
                    detail="Model failed to load"
                )
        
        # Test with simple symbols
        test_symbols = ["want", "water"]
        
        start_time = time.time()
        result = await engine.enhance_communication(
            symbols=test_symbols,
            context={"time_of_day": "afternoon"}
        )
        total_time = (time.time() - start_time) * 1000
        
        return {
            "status": "success",
            "test_input": test_symbols,
            "result": result,
            "total_time_ms": round(total_time, 2)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Test error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Test failed: {str(e)}"
        )
