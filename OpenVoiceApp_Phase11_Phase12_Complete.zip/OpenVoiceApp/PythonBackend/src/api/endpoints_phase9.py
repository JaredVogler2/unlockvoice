"""
Phase 9: Advanced Sentence Formation API Endpoints
Transformer-based natural language generation for AAC
"""

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Create Phase 9 router
router_phase9 = APIRouter(prefix="/api/v1/sentence/v2", tags=["Phase 9 - Advanced Sentence Formation"])


# Request/Response Models for Phase 9
class AdvancedSentenceRequest(BaseModel):
    """Request for advanced sentence formation using transformers"""
    symbols: List[str] = Field(
        ..., 
        description="List of AAC symbols to form into a sentence",
        min_length=1,
        max_length=30
    )
    mode: str = Field(
        default="auto",
        description="Generation mode: 'auto', 'transformer', 'rules', 'hybrid'"
    )
    temperature: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Creativity level (0.0 = conservative, 1.0 = creative)"
    )
    correct_grammar: bool = Field(
        default=True,
        description="Apply grammar correction to output"
    )
    return_alternatives: bool = Field(
        default=False,
        description="Return multiple sentence alternatives"
    )
    use_context: bool = Field(
        default=True,
        description="Use conversation context for better generation"
    )
    
    @validator('symbols')
    def validate_symbols(cls, v):
        if not v:
            raise ValueError("Symbols list cannot be empty")
        return [s.strip() for s in v if s.strip()]
    
    @validator('mode')
    def validate_mode(cls, v):
        valid_modes = ['auto', 'transformer', 'rules', 'hybrid']
        if v not in valid_modes:
            raise ValueError(f"Mode must be one of: {valid_modes}")
        return v


class AdvancedSentenceResponse(BaseModel):
    """Response from advanced sentence formation"""
    sentence: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    alternatives: List[str] = []
    original_symbols: List[str]
    grammar_corrections: Optional[List[str]] = None
    metadata: Dict[str, Any]
    latency_ms: int
    timestamp: str


class GrammarCorrectionRequest(BaseModel):
    """Request for grammar correction"""
    text: str = Field(..., description="Text to correct")
    preserve_meaning: bool = Field(
        default=True,
        description="Try to preserve original meaning"
    )


class GrammarCorrectionResponse(BaseModel):
    """Response from grammar correction"""
    original: str
    corrected: str
    changed: bool
    changes: List[str]
    timestamp: str


class ContextManagementRequest(BaseModel):
    """Request for context management"""
    action: str = Field(..., description="'add', 'clear', or 'get'")
    text: Optional[str] = Field(None, description="Text to add to context (for 'add' action)")
    
    @validator('action')
    def validate_action(cls, v):
        valid_actions = ['add', 'clear', 'get']
        if v not in valid_actions:
            raise ValueError(f"Action must be one of: {valid_actions}")
        return v


class BatchSentenceRequest(BaseModel):
    """Request for batch sentence formation"""
    symbol_sequences: List[List[str]] = Field(
        ...,
        description="List of symbol sequences to process",
        max_length=10
    )
    mode: str = Field(default="auto")
    temperature: float = Field(default=0.7, ge=0.0, le=1.0)


class ModelStatsResponse(BaseModel):
    """Response with model statistics"""
    service: Dict[str, Any]
    transformer: Dict[str, Any]
    models: Dict[str, Any]
    is_loaded: bool
    timestamp: str


# Dependency to get sentence formation service
def get_sentence_service():
    """Get or create sentence formation service instance"""
    from ..services.sentence_formation_service import AdvancedSentenceFormationService
    
    # This would typically be managed by the app state
    # For now, we'll create on demand (in production, use app.state)
    if not hasattr(get_sentence_service, '_service'):
        get_sentence_service._service = AdvancedSentenceFormationService(
            model_name="google/flan-t5-small",
            use_grammar_correction=True,
            use_context=True,
            fallback_to_rules=True
        )
    
    return get_sentence_service._service


@router_phase9.post("/form", response_model=AdvancedSentenceResponse)
async def form_sentence_advanced(request: AdvancedSentenceRequest, req: Request):
    """
    Form a natural sentence from AAC symbols using transformer models
    
    This endpoint uses advanced NLP models (FLAN-T5) to transform symbol sequences
    into grammatically correct, natural-sounding sentences.
    
    **Features:**
    - Semantic understanding of symbols
    - Context-aware generation
    - Grammar correction
    - Multiple generation modes
    - Configurable creativity level
    
    **Example:**
    ```json
    {
        "symbols": ["want", "eat", "pizza"],
        "mode": "auto",
        "temperature": 0.7,
        "correct_grammar": true
    }
    ```
    
    **Returns:**
    ```json
    {
        "sentence": "I want to eat pizza.",
        "confidence": 0.92,
        "alternatives": ["I'd like to eat pizza.", "I want pizza."],
        "latency_ms": 45
    }
    ```
    """
    try:
        start_time = datetime.now()
        
        # Get service
        service = get_sentence_service()
        
        # Ensure service is loaded
        if not service.is_loaded:
            logger.info("Loading sentence formation models (first request)...")
            await service.load()
        
        # Form sentence
        result = await service.form_sentence(
            symbols=request.symbols,
            mode=request.mode,
            temperature=request.temperature,
            correct_grammar=request.correct_grammar,
            return_alternatives=request.return_alternatives
        )
        
        # Calculate latency
        latency = (datetime.now() - start_time).total_seconds() * 1000
        
        return AdvancedSentenceResponse(
            sentence=result.get('sentence', ''),
            confidence=result.get('confidence', 0.0),
            alternatives=result.get('alternatives', []),
            original_symbols=request.symbols,
            grammar_corrections=result.get('grammar_corrections'),
            metadata=result.get('metadata', {}),
            latency_ms=int(latency),
            timestamp=datetime.utcnow().isoformat()
        )
        
    except Exception as e:
        logger.error(f"Advanced sentence formation error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Sentence formation failed: {str(e)}"
        )


@router_phase9.post("/grammar/correct", response_model=GrammarCorrectionResponse)
async def correct_grammar(request: GrammarCorrectionRequest):
    """
    Correct grammatical errors in text
    
    Uses transformer models to fix grammar while preserving meaning.
    
    **Example:**
    ```json
    {
        "text": "I wants to eats pizza",
        "preserve_meaning": true
    }
    ```
    
    **Returns:**
    ```json
    {
        "original": "I wants to eats pizza",
        "corrected": "I want to eat pizza",
        "changed": true,
        "changes": ["Fixed verb conjugation: wants → want", "Fixed verb form: eats → eat"]
    }
    ```
    """
    try:
        service = get_sentence_service()
        
        if not service.is_loaded:
            await service.load()
        
        if not service.grammar_corrector:
            raise HTTPException(
                status_code=501,
                detail="Grammar correction not enabled in this configuration"
            )
        
        # Correct grammar
        result = await service.grammar_corrector.correct(
            text=request.text,
            preserve_meaning=request.preserve_meaning
        )
        
        return GrammarCorrectionResponse(
            original=result['original'],
            corrected=result['corrected'],
            changed=result['changed'],
            changes=result['changes'],
            timestamp=datetime.utcnow().isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Grammar correction error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Grammar correction failed: {str(e)}"
        )


@router_phase9.post("/context/manage")
async def manage_context(request: ContextManagementRequest):
    """
    Manage conversation context
    
    **Actions:**
    - `add`: Add text to conversation context
    - `get`: Get current context
    - `clear`: Clear all context
    
    **Example (add):**
    ```json
    {
        "action": "add",
        "text": "I want to go outside"
    }
    ```
    
    **Example (clear):**
    ```json
    {
        "action": "clear"
    }
    ```
    """
    try:
        service = get_sentence_service()
        
        if not service.context_enhancer:
            raise HTTPException(
                status_code=501,
                detail="Context management not enabled"
            )
        
        if request.action == "add":
            if not request.text:
                raise HTTPException(
                    status_code=400,
                    detail="Text required for 'add' action"
                )
            service.context_enhancer.add_to_context(request.text)
            return {
                "status": "added",
                "text": request.text,
                "context_size": len(service.context_enhancer.conversation_history)
            }
        
        elif request.action == "get":
            context = service.context_enhancer.get_context()
            return {
                "context": context,
                "size": len(context)
            }
        
        elif request.action == "clear":
            service.clear_context()
            return {
                "status": "cleared",
                "context_size": 0
            }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Context management error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Context management failed: {str(e)}"
        )


@router_phase9.post("/batch", response_model=List[AdvancedSentenceResponse])
async def form_sentences_batch(request: BatchSentenceRequest):
    """
    Form multiple sentences in a single request
    
    **Limits:**
    - Maximum 10 sequences per batch
    - Maximum 30 symbols per sequence
    
    **Example:**
    ```json
    {
        "symbol_sequences": [
            ["want", "eat", "pizza"],
            ["need", "drink", "water"],
            ["like", "play", "outside"]
        ],
        "mode": "auto",
        "temperature": 0.7
    }
    ```
    """
    try:
        if len(request.symbol_sequences) > 10:
            raise HTTPException(
                status_code=400,
                detail="Maximum 10 sequences per batch"
            )
        
        service = get_sentence_service()
        
        if not service.is_loaded:
            await service.load()
        
        results = []
        
        for symbols in request.symbol_sequences:
            start_time = datetime.now()
            
            result = await service.form_sentence(
                symbols=symbols,
                mode=request.mode,
                temperature=request.temperature,
                correct_grammar=True,
                return_alternatives=False
            )
            
            latency = (datetime.now() - start_time).total_seconds() * 1000
            
            results.append(AdvancedSentenceResponse(
                sentence=result.get('sentence', ''),
                confidence=result.get('confidence', 0.0),
                alternatives=[],
                original_symbols=symbols,
                grammar_corrections=result.get('grammar_corrections'),
                metadata=result.get('metadata', {}),
                latency_ms=int(latency),
                timestamp=datetime.utcnow().isoformat()
            ))
        
        return results
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Batch sentence formation error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Batch processing failed: {str(e)}"
        )


@router_phase9.get("/stats", response_model=ModelStatsResponse)
async def get_model_stats():
    """
    Get statistics about the sentence formation models
    
    **Returns:**
    - Generation counts
    - Average latency
    - Model configuration
    - Memory usage
    - Cache statistics
    
    **Example Response:**
    ```json
    {
        "service": {
            "total_formations": 1250,
            "transformer_success": 1180,
            "grammar_corrections": 340,
            "fallback_used": 70
        },
        "transformer": {
            "model": "google/flan-t5-small",
            "generations": 1180,
            "avg_time_ms": 42
        },
        "is_loaded": true
    }
    ```
    """
    try:
        service = get_sentence_service()
        
        if not service.is_loaded:
            return ModelStatsResponse(
                service={},
                transformer={},
                models={},
                is_loaded=False,
                timestamp=datetime.utcnow().isoformat()
            )
        
        stats = service.get_stats()
        
        return ModelStatsResponse(
            service=stats['service'],
            transformer=stats['transformer'],
            models=stats['models'],
            is_loaded=stats['is_loaded'],
            timestamp=datetime.utcnow().isoformat()
        )
        
    except Exception as e:
        logger.error(f"Stats retrieval error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get stats: {str(e)}"
        )


@router_phase9.get("/health")
async def phase9_health_check():
    """
    Check Phase 9 system health
    
    **Returns:**
    - Model loading status
    - Component availability
    - System readiness
    """
    try:
        service = get_sentence_service()
        
        components = {
            "transformer": service.transformer is not None,
            "grammar_corrector": service.grammar_corrector is not None,
            "context_enhancer": service.context_enhancer is not None,
            "rule_fallback": service.rule_based is not None
        }
        
        return {
            "status": "healthy" if service.is_loaded else "not_loaded",
            "phase": 9,
            "components": components,
            "is_loaded": service.is_loaded,
            "model": service.model_name,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Health check error: {e}", exc_info=True)
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }


# Add comparison endpoint
@router_phase9.post("/compare")
async def compare_generation_modes(symbols: List[str]):
    """
    Compare different generation modes for the same symbols
    
    Useful for testing and understanding how different modes work.
    
    **Example:**
    ```json
    {
        "symbols": ["want", "eat", "pizza"]
    }
    ```
    
    **Returns:**
    Sentences generated using all available modes:
    - transformer
    - rules
    - hybrid
    """
    try:
        service = get_sentence_service()
        
        if not service.is_loaded:
            await service.load()
        
        modes = ['transformer', 'rules', 'hybrid']
        results = {}
        
        for mode in modes:
            try:
                result = await service.form_sentence(
                    symbols=symbols,
                    mode=mode,
                    temperature=0.7,
                    correct_grammar=False,
                    return_alternatives=False
                )
                
                results[mode] = {
                    "sentence": result.get('sentence', ''),
                    "confidence": result.get('confidence', 0.0),
                    "metadata": result.get('metadata', {})
                }
            except Exception as e:
                results[mode] = {
                    "error": str(e)
                }
        
        return {
            "symbols": symbols,
            "results": results,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Comparison error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Comparison failed: {str(e)}"
        )
