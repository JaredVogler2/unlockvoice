"""
API Endpoints for OpenVoice ML Backend
"""

from fastapi import APIRouter, HTTPException, Request, Depends
from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

router = APIRouter()


# Request/Response Models
class PredictionRequest(BaseModel):
    """Request for word prediction"""
    context: List[str] = Field(
        ..., 
        description="Previous words/symbols in the phrase",
        max_length=10
    )
    max_predictions: int = Field(
        default=10, 
        ge=1, 
        le=20,
        description="Maximum number of predictions to return"
    )
    user_id: Optional[str] = Field(
        None,
        description="Optional user ID for personalized predictions"
    )
    time_of_day: Optional[str] = Field(
        None,
        description="Time context (morning/afternoon/evening/night)"
    )

    @validator('context')
    def validate_context(cls, v):
        if not v:
            raise ValueError("Context cannot be empty")
        return [word.strip().lower() for word in v if word.strip()]


class Prediction(BaseModel):
    """Single prediction result"""
    text: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    source: str  # 'ngram', 'context', 'frequency', 'hybrid'
    metadata: Optional[Dict[str, Any]] = None


class PredictionResponse(BaseModel):
    """Response with predictions"""
    predictions: List[Prediction]
    latency_ms: float
    timestamp: str
    model_version: str = "1.0.0"


class SentenceRequest(BaseModel):
    """Request for sentence formation"""
    symbols: List[str] = Field(
        ..., 
        description="List of symbols to form into a sentence",
        min_length=1,
        max_length=20
    )
    preserve_order: bool = Field(
        default=True,
        description="Whether to preserve the original symbol order"
    )
    add_grammar: bool = Field(
        default=True,
        description="Whether to add grammatical words (I, the, to, etc.)"
    )

    @validator('symbols')
    def validate_symbols(cls, v):
        if not v:
            raise ValueError("Symbols list cannot be empty")
        return [s.strip().lower() for s in v if s.strip()]


class SentenceResponse(BaseModel):
    """Response with formed sentence"""
    original_symbols: List[str]
    formed_sentence: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    grammar_changes: Optional[List[str]] = None
    latency_ms: float
    timestamp: str
    model_version: str = "1.0.0"


class RAGRequest(BaseModel):
    """Request for RAG-based prediction"""
    current_phrase: str = Field(..., description="Current phrase being built")
    conversation_history: List[str] = Field(
        default_factory=list,
        max_length=100,
        description="Recent conversation history"
    )
    k: int = Field(
        default=5,
        ge=1,
        le=20,
        description="Number of similar conversations to retrieve"
    )


class RAGResponse(BaseModel):
    """Response from RAG system"""
    predictions: List[Prediction]
    similar_contexts: List[str]
    relevance_scores: List[float]
    latency_ms: float
    timestamp: str


# Endpoints
@router.post("/predict", response_model=PredictionResponse)
async def predict_next_words(
    request: PredictionRequest,
    req: Request
) -> PredictionResponse:
    """
    Predict next words based on context
    
    Uses N-gram models, contextual information, and frequency analysis
    to suggest the most likely next words/symbols.
    """
    start_time = datetime.utcnow()
    
    try:
        model_service = req.state.model_service
        if not model_service or not model_service.is_ready:
            raise HTTPException(
                status_code=503,
                detail="Model service not ready"
            )
        
        # Get predictions from model service
        predictions = await model_service.predict_next(
            context=request.context,
            max_predictions=request.max_predictions,
            time_of_day=request.time_of_day,
            user_id=request.user_id
        )
        
        # Calculate latency
        latency = (datetime.utcnow() - start_time).total_seconds() * 1000
        
        # Update metrics
        model_service.prediction_count += 1
        model_service.update_latency(latency)
        
        logger.info(f"Prediction completed in {latency:.2f}ms for context: {request.context}")
        
        return PredictionResponse(
            predictions=predictions,
            latency_ms=round(latency, 2),
            timestamp=datetime.utcnow().isoformat()
        )
        
    except Exception as e:
        logger.error(f"Prediction error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/sentence/form", response_model=SentenceResponse)
async def form_sentence(
    request: SentenceRequest,
    req: Request
) -> SentenceResponse:
    """
    Transform symbol sequence into natural language sentence
    
    Takes a list of symbols and uses BERT/T5 models to form
    grammatically correct, natural-sounding sentences.
    
    Example:
        Input: ["want", "eat", "pizza"]
        Output: "I want to eat pizza"
    """
    start_time = datetime.utcnow()
    
    try:
        model_service = req.state.model_service
        if not model_service or not model_service.is_ready:
            raise HTTPException(
                status_code=503,
                detail="Model service not ready"
            )
        
        # Form sentence using model
        result = await model_service.form_sentence(
            symbols=request.symbols,
            preserve_order=request.preserve_order,
            add_grammar=request.add_grammar
        )
        
        # Calculate latency
        latency = (datetime.utcnow() - start_time).total_seconds() * 1000
        
        # Update metrics
        model_service.sentence_count += 1
        model_service.update_latency(latency)
        
        logger.info(f"Sentence formed in {latency:.2f}ms: {result['sentence']}")
        
        return SentenceResponse(
            original_symbols=request.symbols,
            formed_sentence=result['sentence'],
            confidence=result['confidence'],
            grammar_changes=result.get('grammar_changes'),
            latency_ms=round(latency, 2),
            timestamp=datetime.utcnow().isoformat()
        )
        
    except Exception as e:
        logger.error(f"Sentence formation error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/rag/predict", response_model=RAGResponse)
async def rag_predict(
    request: RAGRequest,
    req: Request
) -> RAGResponse:
    """
    Predict using RAG (Retrieval Augmented Generation)
    
    Finds similar conversation patterns from history and suggests
    contextually appropriate next words.
    """
    start_time = datetime.utcnow()
    
    try:
        model_service = req.state.model_service
        if not model_service or not model_service.is_ready:
            raise HTTPException(
                status_code=503,
                detail="Model service not ready"
            )
        
        # Get RAG predictions
        result = await model_service.rag_predict(
            current_phrase=request.current_phrase,
            conversation_history=request.conversation_history,
            k=request.k
        )
        
        # Calculate latency
        latency = (datetime.utcnow() - start_time).total_seconds() * 1000
        
        logger.info(f"RAG prediction completed in {latency:.2f}ms")
        
        return RAGResponse(
            predictions=result['predictions'],
            similar_contexts=result['similar_contexts'],
            relevance_scores=result['relevance_scores'],
            latency_ms=round(latency, 2),
            timestamp=datetime.utcnow().isoformat()
        )
        
    except Exception as e:
        logger.error(f"RAG prediction error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/conversation/add")
async def add_conversation(
    conversation: Dict[str, Any],
    req: Request
):
    """
    Add conversation to RAG system for future predictions
    """
    try:
        model_service = req.state.model_service
        if not model_service:
            raise HTTPException(
                status_code=503,
                detail="Model service not ready"
            )
        
        await model_service.add_conversation(conversation)
        
        return {
            "status": "success",
            "message": "Conversation added to RAG system",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Add conversation error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/models/info")
async def get_model_info(req: Request):
    """
    Get information about loaded models
    """
    try:
        model_service = req.state.model_service
        if not model_service:
            raise HTTPException(
                status_code=503,
                detail="Model service not ready"
            )
        
        return {
            "models": model_service.get_model_info(),
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Model info error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/models/reload")
async def reload_models(req: Request):
    """
    Reload ML models (useful after training updates)
    """
    try:
        model_service = req.state.model_service
        if not model_service:
            raise HTTPException(
                status_code=503,
                detail="Model service not ready"
            )
        
        await model_service.reload_models()
        
        return {
            "status": "success",
            "message": "Models reloaded successfully",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Model reload error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==========================================
# PHASE 8: Advanced RAG Endpoints
# ==========================================

class RAGSearchRequest(BaseModel):
    """Request for semantic search"""
    query: str = Field(..., description="Search query")
    k: int = Field(default=20, ge=1, le=100, description="Number of results")
    use_temporal_weighting: bool = Field(
        default=True,
        description="Apply temporal decay to scores"
    )


class RAGSearchResponse(BaseModel):
    """Response with search results"""
    results: List[Dict[str, Any]]
    latency_ms: float
    timestamp: str


class ConversationAddRequest(BaseModel):
    """Request to add conversation"""
    text: str = Field(..., min_length=1, description="Conversation text")
    timestamp: Optional[str] = Field(None, description="ISO timestamp")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")


@router.post("/rag/v2/search")
async def search_similar_conversations(
    request: RAGSearchRequest,
    req: Request
):
    """
    Search for semantically similar conversations using FAISS
    
    Phase 8: Uses semantic embeddings for better similarity search
    """
    try:
        import time
        start_time = time.time()
        
        # Get RAG engine v2
        from ..models.rag_engine_v2 import get_rag_engine
        rag_engine = get_rag_engine()
        
        if not rag_engine.is_ready:
            raise HTTPException(
                status_code=503,
                detail="RAG engine not initialized"
            )
        
        # Search similar conversations
        results = await rag_engine.search_similar(
            query=request.query,
            k=request.k,
            use_temporal_weighting=request.use_temporal_weighting
        )
        
        latency = (time.time() - start_time) * 1000
        
        return RAGSearchResponse(
            results=results,
            latency_ms=latency,
            timestamp=datetime.utcnow().isoformat()
        )
        
    except Exception as e:
        logger.error(f"RAG search error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/rag/v2/predict")
async def rag_predict_v2(
    request: RAGRequest,
    req: Request
):
    """
    Get predictions using advanced RAG with semantic search
    
    Phase 8: Uses FAISS for semantic similarity search
    """
    try:
        import time
        start_time = time.time()
        
        # Get RAG engine v2
        from ..models.rag_engine_v2 import get_rag_engine
        rag_engine = get_rag_engine()
        
        if not rag_engine.is_ready:
            raise HTTPException(
                status_code=503,
                detail="RAG engine not initialized"
            )
        
        # Get predictions
        result = await rag_engine.predict(
            current_phrase=request.current_phrase,
            conversation_history=request.conversation_history,
            k=request.k,
            max_predictions=request.max_predictions
        )
        
        latency = (time.time() - start_time) * 1000
        
        # Convert to Prediction objects
        predictions = [
            Prediction(**pred)
            for pred in result['predictions']
        ]
        
        return {
            "predictions": predictions,
            "similar_contexts": result.get('similar_contexts', []),
            "relevance_scores": result.get('relevance_scores', []),
            "num_contexts": result.get('num_contexts', 0),
            "latency_ms": latency,
            "timestamp": datetime.utcnow().isoformat(),
            "model_version": "2.0.0-faiss"
        }
        
    except Exception as e:
        logger.error(f"RAG v2 prediction error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/conversation/add")
async def add_conversation(
    request: ConversationAddRequest,
    req: Request
):
    """
    Add conversation to RAG system
    
    Phase 8: Stores conversation with semantic embeddings
    """
    try:
        # Get RAG engine v2
        from ..models.rag_engine_v2 import get_rag_engine
        rag_engine = get_rag_engine()
        
        if not rag_engine.is_ready:
            raise HTTPException(
                status_code=503,
                detail="RAG engine not initialized"
            )
        
        # Add conversation
        success = await rag_engine.add_conversation({
            'text': request.text,
            'timestamp': request.timestamp or datetime.utcnow().isoformat(),
            'metadata': request.metadata or {}
        })
        
        if not success:
            raise HTTPException(
                status_code=400,
                detail="Failed to add conversation"
            )
        
        return {
            "status": "success",
            "message": "Conversation added successfully",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Add conversation error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/rag/stats")
async def get_rag_statistics(req: Request):
    """
    Get RAG engine statistics
    
    Phase 8: Includes FAISS index statistics
    """
    try:
        # Get RAG engine v2
        from ..models.rag_engine_v2 import get_rag_engine
        rag_engine = get_rag_engine()
        
        if not rag_engine.is_ready:
            return {
                "is_ready": False,
                "message": "RAG engine not initialized"
            }
        
        stats = rag_engine.get_statistics()
        
        return {
            **stats,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"RAG stats error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/rag/save")
async def save_rag_index(req: Request):
    """
    Manually trigger RAG index save
    """
    try:
        from ..models.rag_engine_v2 import get_rag_engine
        rag_engine = get_rag_engine()
        
        if not rag_engine.is_ready:
            raise HTTPException(
                status_code=503,
                detail="RAG engine not initialized"
            )
        
        success = await rag_engine.save()
        
        if not success:
            raise HTTPException(
                status_code=500,
                detail="Failed to save RAG index"
            )
        
        return {
            "status": "success",
            "message": "RAG index saved successfully",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"RAG save error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analytics/summary")
async def get_analytics_summary(req: Request):
    """
    Get conversation analytics summary
    
    Phase 8: Powered by ConversationAnalyzer
    """
    try:
        from ..models.rag_engine_v2 import get_rag_engine
        from ..services.conversation_analyzer import ConversationAnalyzer
        
        rag_engine = get_rag_engine()
        
        if not rag_engine.is_ready:
            raise HTTPException(
                status_code=503,
                detail="RAG engine not initialized"
            )
        
        analyzer = ConversationAnalyzer(rag_engine)
        summary = analyzer.get_summary()
        
        return {
            **summary,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Analytics summary error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analytics/words")
async def get_top_words(
    n: int = 20,
    req: Request = None
):
    """
    Get most frequently used words
    """
    try:
        from ..models.rag_engine_v2 import get_rag_engine
        from ..services.conversation_analyzer import ConversationAnalyzer
        
        rag_engine = get_rag_engine()
        
        if not rag_engine.is_ready:
            raise HTTPException(
                status_code=503,
                detail="RAG engine not initialized"
            )
        
        analyzer = ConversationAnalyzer(rag_engine)
        top_words = analyzer.get_top_words(n=n)
        
        return {
            "top_words": top_words,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Top words error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/analytics/patterns")
async def get_temporal_patterns(req: Request):
    """
    Get temporal usage patterns
    """
    try:
        from ..models.rag_engine_v2 import get_rag_engine
        from ..services.conversation_analyzer import ConversationAnalyzer
        
        rag_engine = get_rag_engine()
        
        if not rag_engine.is_ready:
            raise HTTPException(
                status_code=503,
                detail="RAG engine not initialized"
            )
        
        analyzer = ConversationAnalyzer(rag_engine)
        patterns = analyzer.get_temporal_patterns()
        
        return {
            **patterns,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Temporal patterns error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

