"""
OpenVoice Python Backend
FastAPI server for advanced ML features

Phase 7-8-9 Implementation
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from contextlib import asynccontextmanager
import logging
from datetime import datetime

from api.endpoints import router as api_router
from api.endpoints_phase9 import router_phase9
from services.model_loader import ModelService

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Global service instances
model_service = None
embedding_service = None
rag_engine = None
sentence_formation_service = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Startup and shutdown events
    """
    # Startup
    logger.info("🚀 Starting OpenVoice Backend...")
    global model_service, embedding_service, rag_engine, sentence_formation_service
    
    try:
        # Initialize Phase 7 models
        model_service = ModelService()
        await model_service.initialize()
        logger.info("✅ Phase 7 models loaded successfully")
        
        # Initialize Phase 8: Embedding Service
        try:
            from models.embedding_service import get_embedding_service
            embedding_service = get_embedding_service()
            await embedding_service.initialize()
            logger.info("✅ Phase 8: Embedding service initialized")
        except Exception as e:
            logger.warning(f"⚠️ Phase 8 embedding service failed: {e}")
            logger.warning("   Continuing without advanced RAG features")
        
        # Initialize Phase 8: FAISS RAG Engine
        try:
            from models.rag_engine_v2 import get_rag_engine
            rag_engine = get_rag_engine()
            await rag_engine.initialize()
            logger.info("✅ Phase 8: FAISS RAG engine initialized")
            logger.info(f"   Loaded {len(rag_engine.conversations)} conversations")
        except Exception as e:
            logger.warning(f"⚠️ Phase 8 RAG engine failed: {e}")
            logger.warning("   Falling back to Phase 7 RAG")
        
        # Initialize Phase 9: Advanced Sentence Formation
        try:
            from services.sentence_formation_service import AdvancedSentenceFormationService
            logger.info("🔮 Initializing Phase 9: Advanced Sentence Formation...")
            sentence_formation_service = AdvancedSentenceFormationService(
                model_name="google/flan-t5-small",
                use_grammar_correction=True,
                use_context=True,
                fallback_to_rules=True
            )
            # Load models lazily (on first request) to speed up startup
            logger.info("✅ Phase 9: Sentence formation service created (models load on first use)")
        except Exception as e:
            logger.warning(f"⚠️ Phase 9 sentence formation failed: {e}")
            logger.warning("   Continuing without transformer-based sentence formation")
        
        logger.info("🎉 All services started successfully!")
        
    except Exception as e:
        logger.error(f"❌ Failed to load models: {e}")
        raise
    
    yield
    
    # Shutdown
    logger.info("🛑 Shutting down OpenVoice Backend...")
    
    # Save RAG index before shutdown
    if rag_engine and rag_engine.is_ready:
        logger.info("💾 Saving RAG index...")
        await rag_engine.save()
        logger.info("✅ RAG index saved")
    
    if model_service:
        await model_service.cleanup()
    
    logger.info("👋 Shutdown complete")


# Create FastAPI app
app = FastAPI(
    title="OpenVoice ML API",
    description="Backend ML services for OpenVoice AAC App - Phase 7-8-9",
    version="3.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your iOS app
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Global exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc),
            "timestamp": datetime.utcnow().isoformat()
        }
    )


# Health check endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "OpenVoice ML API",
        "version": "1.0.0",
        "status": "running",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy",
        "phase_7": {
            "models_loaded": model_service.is_ready if model_service else False
        },
        "phase_8": {
            "embedding_service": embedding_service.is_ready if embedding_service else False,
            "rag_engine": rag_engine.is_ready if rag_engine else False,
            "conversations_loaded": len(rag_engine.conversations) if (rag_engine and rag_engine.is_ready) else 0
        },
        "phase_9": {
            "sentence_formation_service": sentence_formation_service is not None,
            "transformers_loaded": sentence_formation_service.is_loaded if sentence_formation_service else False,
            "model": sentence_formation_service.model_name if sentence_formation_service else None
        },
        "timestamp": datetime.utcnow().isoformat(),
        "uptime": "active"
    }


@app.get("/metrics")
async def get_metrics():
    """Get service metrics"""
    if not model_service:
        raise HTTPException(status_code=503, detail="Model service not initialized")
    
    return {
        "predictions_served": model_service.prediction_count,
        "sentences_formed": model_service.sentence_count,
        "average_latency_ms": model_service.avg_latency_ms,
        "timestamp": datetime.utcnow().isoformat()
    }


# Include API routers
app.include_router(api_router, prefix="/api/v1")
app.include_router(router_phase9)  # Phase 9 has its own prefix


# Make model_service accessible to routes
@app.middleware("http")
async def add_model_service(request: Request, call_next):
    request.state.model_service = model_service
    response = await call_next(request)
    return response


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
