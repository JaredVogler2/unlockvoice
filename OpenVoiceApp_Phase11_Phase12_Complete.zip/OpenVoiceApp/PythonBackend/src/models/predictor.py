"""
Prediction Models - N-gram and Contextual
"""

import logging
from typing import List, Dict, Any, Optional
from collections import defaultdict, Counter
import json
import os

logger = logging.getLogger(__name__)


class NGramPredictor:
    """
    N-gram based word prediction
    """
    
    def __init__(self):
        self.bigrams = defaultdict(Counter)
        self.trigrams = defaultdict(Counter)
        self.is_loaded = False
        logger.info("NGramPredictor initialized")
    
    async def load(self):
        """
        Load N-gram models
        """
        try:
            # Load pre-trained n-grams or build from data
            # For now, use common AAC patterns
            self._build_default_ngrams()
            self.is_loaded = True
            logger.info("N-gram model loaded successfully")
            
        except Exception as e:
            logger.error(f"Failed to load N-gram model: {e}")
            raise
    
    def _build_default_ngrams(self):
        """
        Build default AAC-focused n-grams
        """
        # Common AAC phrases
        common_phrases = [
            "I want water",
            "I want food",
            "I want help",
            "I want to go",
            "I want to play",
            "I need help",
            "I need bathroom",
            "I need break",
            "I feel happy",
            "I feel sad",
            "I feel tired",
            "I feel hungry",
            "yes please",
            "no thank you",
            "more please",
            "all done",
            "good morning",
            "good night",
            "thank you",
            "I love you",
        ]
        
        # Build bigrams and trigrams
        for phrase in common_phrases:
            words = phrase.lower().split()
            
            # Build bigrams
            for i in range(len(words) - 1):
                self.bigrams[words[i]][words[i + 1]] += 1
            
            # Build trigrams
            for i in range(len(words) - 2):
                context = (words[i], words[i + 1])
                self.trigrams[context][words[i + 2]] += 1
    
    async def predict(
        self,
        context: List[str],
        max_predictions: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Predict next words using n-grams
        """
        predictions = []
        
        try:
            if len(context) == 0:
                return predictions
            
            # Try trigram first (more specific)
            if len(context) >= 2:
                trigram_key = (context[-2].lower(), context[-1].lower())
                if trigram_key in self.trigrams:
                    for word, count in self.trigrams[trigram_key].most_common(max_predictions):
                        predictions.append({
                            'text': word,
                            'confidence': min(0.95, 0.7 + (count / 100)),
                            'source': 'ngram-3',
                            'metadata': {'count': count}
                        })
            
            # Fall back to bigram
            if len(predictions) < max_predictions:
                last_word = context[-1].lower()
                if last_word in self.bigrams:
                    for word, count in self.bigrams[last_word].most_common(max_predictions):
                        # Avoid duplicates
                        if not any(p['text'] == word for p in predictions):
                            predictions.append({
                                'text': word,
                                'confidence': min(0.85, 0.6 + (count / 100)),
                                'source': 'ngram-2',
                                'metadata': {'count': count}
                            })
            
        except Exception as e:
            logger.error(f"N-gram prediction error: {e}")
        
        return predictions[:max_predictions]


class ContextualPredictor:
    """
    Context-aware predictions based on time, user patterns, etc.
    """
    
    def __init__(self):
        self.time_contexts = {}
        self.is_loaded = False
        logger.info("ContextualPredictor initialized")
    
    async def load(self):
        """
        Load contextual models
        """
        try:
            self._build_time_contexts()
            self.is_loaded = True
            logger.info("Contextual model loaded successfully")
            
        except Exception as e:
            logger.error(f"Failed to load contextual model: {e}")
            raise
    
    def _build_time_contexts(self):
        """
        Build time-of-day based contexts
        """
        self.time_contexts = {
            'morning': {
                'breakfast': 0.9,
                'wake': 0.85,
                'hello': 0.8,
                'good': 0.8,
                'morning': 0.85,
                'hungry': 0.7,
                'sleepy': 0.6,
            },
            'afternoon': {
                'lunch': 0.9,
                'play': 0.8,
                'outside': 0.75,
                'activity': 0.7,
                'tired': 0.65,
                'water': 0.7,
            },
            'evening': {
                'dinner': 0.9,
                'tired': 0.85,
                'home': 0.8,
                'bath': 0.75,
                'bed': 0.8,
                'night': 0.75,
            },
            'night': {
                'bed': 0.95,
                'sleep': 0.9,
                'tired': 0.9,
                'night': 0.85,
                'bathroom': 0.7,
            }
        }
    
    async def predict(
        self,
        context: List[str],
        time_of_day: str,
        max_predictions: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Predict using contextual information
        """
        predictions = []
        
        try:
            # Get time-based suggestions
            if time_of_day in self.time_contexts:
                time_words = self.time_contexts[time_of_day]
                
                for word, confidence in sorted(
                    time_words.items(),
                    key=lambda x: x[1],
                    reverse=True
                )[:max_predictions]:
                    predictions.append({
                        'text': word,
                        'confidence': confidence,
                        'source': 'contextual-time',
                        'metadata': {'time_of_day': time_of_day}
                    })
            
        except Exception as e:
            logger.error(f"Contextual prediction error: {e}")
        
        return predictions
    
    def get_time_of_day(self, hour: int) -> str:
        """
        Determine time of day from hour
        """
        if 5 <= hour < 12:
            return 'morning'
        elif 12 <= hour < 17:
            return 'afternoon'
        elif 17 <= hour < 21:
            return 'evening'
        else:
            return 'night'


class FrequencyPredictor:
    """
    User-specific frequency-based predictions
    """
    
    def __init__(self):
        self.user_frequencies = defaultdict(Counter)
        self.is_loaded = False
        logger.info("FrequencyPredictor initialized")
    
    async def load(self):
        """
        Load frequency data
        """
        try:
            # Load from file if exists
            self.is_loaded = True
            logger.info("Frequency predictor loaded")
        except Exception as e:
            logger.error(f"Failed to load frequency predictor: {e}")
            raise
    
    async def predict(
        self,
        user_id: str,
        max_predictions: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Predict based on user's most frequent words
        """
        predictions = []
        
        try:
            if user_id in self.user_frequencies:
                for word, count in self.user_frequencies[user_id].most_common(max_predictions):
                    predictions.append({
                        'text': word,
                        'confidence': min(0.8, 0.5 + (count / 1000)),
                        'source': 'frequency',
                        'metadata': {'usage_count': count}
                    })
        
        except Exception as e:
            logger.error(f"Frequency prediction error: {e}")
        
        return predictions
    
    def record_usage(self, user_id: str, word: str):
        """
        Record word usage for a user
        """
        self.user_frequencies[user_id][word.lower()] += 1
