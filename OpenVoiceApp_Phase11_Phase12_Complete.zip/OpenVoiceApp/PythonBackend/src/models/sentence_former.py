"""
Sentence Formation Model
Transforms symbol sequences into natural language
"""

import logging
from typing import List, Dict, Any
import re

logger = logging.getLogger(__name__)


class SentenceFormer:
    """
    Forms natural sentences from symbol sequences
    Uses rule-based approach with optional transformer models
    """
    
    def __init__(self):
        self.is_loaded = False
        self.grammar_rules = {}
        self.common_insertions = {}
        logger.info("SentenceFormer initialized")
    
    async def load(self):
        """
        Load sentence formation models
        """
        try:
            self._build_grammar_rules()
            self.is_loaded = True
            logger.info("Sentence formation model loaded")
            
        except Exception as e:
            logger.error(f"Failed to load sentence former: {e}")
            raise
    
    def _build_grammar_rules(self):
        """
        Build grammar rules for AAC sentence formation
        """
        # Common verb → pronoun + verb transformations
        self.grammar_rules = {
            'want': 'I want',
            'need': 'I need',
            'like': 'I like',
            'love': 'I love',
            'feel': 'I feel',
            'going': 'I am going',
            'eating': 'I am eating',
            'playing': 'I am playing',
        }
        
        # Common insertions
        self.common_insertions = {
            'to_verbs': ['eat', 'drink', 'play', 'go', 'see', 'help'],
            'articles': ['water', 'bathroom', 'food', 'bed'],
            'possessives': ['mom', 'dad', 'brother', 'sister', 'friend'],
        }
    
    async def form_sentence(
        self,
        symbols: List[str],
        preserve_order: bool = True,
        add_grammar: bool = True
    ) -> Dict[str, Any]:
        """
        Form a natural sentence from symbols
        
        Args:
            symbols: List of symbol words
            preserve_order: Keep original order
            add_grammar: Add grammatical words
            
        Returns:
            Dict with formed sentence, confidence, and changes
        """
        try:
            if not symbols:
                return {
                    'sentence': '',
                    'confidence': 0.0,
                    'grammar_changes': []
                }
            
            # Start with original symbols
            words = [s.lower() for s in symbols]
            grammar_changes = []
            
            if add_grammar:
                # Apply grammar transformations
                words, changes = self._apply_grammar(words)
                grammar_changes.extend(changes)
            
            # Capitalize first word
            if words:
                words[0] = words[0].capitalize()
            
            # Join into sentence
            sentence = ' '.join(words)
            
            # Add punctuation if missing
            if sentence and not sentence[-1] in '.!?':
                sentence += '.'
            
            # Calculate confidence based on transformations
            confidence = self._calculate_confidence(symbols, words)
            
            return {
                'sentence': sentence,
                'confidence': confidence,
                'grammar_changes': grammar_changes
            }
            
        except Exception as e:
            logger.error(f"Sentence formation error: {e}")
            # Fallback
            return {
                'sentence': ' '.join(symbols).capitalize() + '.',
                'confidence': 0.5,
                'grammar_changes': []
            }
    
    def _apply_grammar(self, words: List[str]) -> tuple[List[str], List[str]]:
        """
        Apply grammar rules to improve sentence
        """
        result = []
        changes = []
        i = 0
        
        while i < len(words):
            word = words[i]
            
            # Check if word needs pronoun
            if word in self.grammar_rules:
                result.append('I')
                result.append(word)
                changes.append(f"Added 'I' before '{word}'")
                i += 1
                continue
            
            # Check if next word needs "to"
            if i + 1 < len(words) and words[i + 1] in self.common_insertions['to_verbs']:
                result.append(word)
                result.append('to')
                changes.append(f"Added 'to' before '{words[i + 1]}'")
                i += 1
                continue
            
            # Check if word needs article
            if word in self.common_insertions['articles']:
                if not result or result[-1] not in ['the', 'a']:
                    result.append('the')
                    result.append(word)
                    changes.append(f"Added 'the' before '{word}'")
                    i += 1
                    continue
            
            # Default: add word as-is
            result.append(word)
            i += 1
        
        return result, changes
    
    def _calculate_confidence(self, original: List[str], transformed: List[str]) -> float:
        """
        Calculate confidence score for the transformation
        """
        # Base confidence
        confidence = 0.7
        
        # Adjust based on transformations
        transformation_ratio = len(transformed) / len(original) if original else 1.0
        
        if 1.0 <= transformation_ratio <= 1.5:
            # Reasonable amount of additions
            confidence = 0.85
        elif transformation_ratio > 2.0:
            # Too many additions, less confident
            confidence = 0.65
        
        # Boost if contains common patterns
        sentence = ' '.join(transformed)
        if any(pattern in sentence for pattern in ['I want', 'I need', 'I like']):
            confidence = min(0.95, confidence + 0.1)
        
        return confidence


class TransformerSentenceFormer:
    """
    Advanced sentence formation using transformer models
    (T5, BERT, etc.)
    
    This is a placeholder for future transformer integration
    """
    
    def __init__(self):
        self.model = None
        self.tokenizer = None
        logger.info("TransformerSentenceFormer initialized (placeholder)")
    
    async def load(self):
        """
        Load transformer model
        """
        logger.info("Transformer models not yet implemented")
        # TODO: Implement with transformers library
        # from transformers import T5Tokenizer, T5ForConditionalGeneration
        # self.tokenizer = T5Tokenizer.from_pretrained("t5-small")
        # self.model = T5ForConditionalGeneration.from_pretrained("t5-small")
    
    async def form_sentence(self, symbols: List[str]) -> str:
        """
        Form sentence using transformer model
        """
        # Placeholder
        return ' '.join(symbols)
