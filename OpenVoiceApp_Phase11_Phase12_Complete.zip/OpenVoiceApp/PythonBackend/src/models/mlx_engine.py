"""
MLX Engine Service - Local LLM Integration
Phase 10: On-device language models using Apple's MLX framework
"""

import logging
import time
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import asyncio
from pathlib import Path

logger = logging.getLogger(__name__)

# Try to import MLX - graceful fallback if not available
try:
    import mlx.core as mx
    from mlx_lm import load, generate
    MLX_AVAILABLE = True
    logger.info("MLX framework available")
except ImportError:
    MLX_AVAILABLE = False
    logger.warning("MLX not available - LLM features will be disabled")


@dataclass
class LLMConfig:
    """Configuration for LLM models"""
    model_name: str = "mlx-community/Mistral-7B-Instruct-v0.2-4bit"
    max_tokens: int = 100
    temperature: float = 0.7
    top_p: float = 0.95
    repetition_penalty: float = 1.2
    context_window: int = 512
    

@dataclass
class LLMResponse:
    """Response from LLM generation"""
    text: str
    confidence: float
    tokens: int
    latency_ms: float
    model: str
    finish_reason: str  # 'complete', 'max_tokens', 'error'
    

class ConversationMemory:
    """Manages conversation history for context"""
    
    def __init__(self, max_history: int = 10):
        self.max_history = max_history
        self.history: List[Dict[str, str]] = []
        
    def add_message(self, role: str, content: str):
        """Add message to conversation history"""
        self.history.append({"role": role, "content": content})
        
        # Keep only recent messages
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]
    
    def get_context(self) -> str:
        """Get formatted conversation context"""
        if not self.history:
            return ""
        
        context_parts = []
        for msg in self.history:
            if msg["role"] == "user":
                context_parts.append(f"User: {msg['content']}")
            else:
                context_parts.append(f"Assistant: {msg['content']}")
        
        return "\n".join(context_parts)
    
    def clear(self):
        """Clear conversation history"""
        self.history.clear()


class MLXEngine:
    """
    Main MLX engine for running local LLMs
    Optimized for Apple Silicon (M1/M2/M3)
    """
    
    def __init__(self, config: Optional[LLMConfig] = None):
        self.config = config or LLMConfig()
        self.model = None
        self.tokenizer = None
        self.is_loaded = False
        self.memory = ConversationMemory()
        
        # Statistics
        self.stats = {
            "total_generations": 0,
            "total_tokens": 0,
            "total_latency_ms": 0,
            "errors": 0
        }
        
        logger.info(f"MLXEngine initialized with model: {self.config.model_name}")
    
    async def load_model(self):
        """Load the LLM model"""
        if not MLX_AVAILABLE:
            logger.error("MLX not available - cannot load model")
            return False
        
        if self.is_loaded:
            logger.info("Model already loaded")
            return True
        
        try:
            start_time = time.time()
            logger.info(f"Loading model: {self.config.model_name}")
            
            # Load model and tokenizer
            # MLX will automatically use Apple Silicon GPU
            self.model, self.tokenizer = load(self.config.model_name)
            
            load_time = (time.time() - start_time) * 1000
            self.is_loaded = True
            
            logger.info(f"Model loaded successfully in {load_time:.0f}ms")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            self.stats["errors"] += 1
            return False
    
    def _create_prompt(
        self, 
        symbols: List[str], 
        task: str = "enhance",
        additional_context: Optional[str] = None
    ) -> str:
        """Create prompt for the LLM"""
        
        # Get conversation history
        history_context = self.memory.get_context()
        
        if task == "enhance":
            # Convert AAC symbols to natural language
            prompt = (
                "You are an AAC communication assistant helping a non-verbal person communicate. "
                "Convert these AAC symbols into a natural, grammatically correct, empathetic sentence. "
                "Be concise but complete.\n\n"
            )
            
            if history_context:
                prompt += f"Previous conversation:\n{history_context}\n\n"
            
            if additional_context:
                prompt += f"Context: {additional_context}\n"
            
            prompt += f"AAC Symbols: {' '.join(symbols)}\n\n"
            prompt += "Natural sentence:"
            
        elif task == "predict":
            # Predict next likely symbols
            prompt = (
                "Based on this AAC communication sequence, suggest the most likely next symbols. "
                "Return 3-5 suggestions as a comma-separated list.\n\n"
            )
            
            if history_context:
                prompt += f"Context:\n{history_context}\n\n"
            
            prompt += f"Current symbols: {' '.join(symbols)}\n\n"
            prompt += "Next likely symbols:"
            
        elif task == "question":
            # Answer a question about the conversation
            question = ' '.join(symbols)
            prompt = (
                "Answer this question about our AAC conversation briefly and clearly.\n\n"
            )
            
            if history_context:
                prompt += f"Conversation history:\n{history_context}\n\n"
            
            prompt += f"Question: {question}\n\n"
            prompt += "Answer:"
        
        elif task == "intent":
            # Recognize intent from symbols
            prompt = (
                "Identify the intent and urgency of these AAC symbols. "
                "Return: intent (e.g. REQUEST, QUESTION, EMERGENCY) and urgency (LOW, MEDIUM, HIGH, URGENT).\n\n"
            )
            prompt += f"Symbols: {' '.join(symbols)}\n\n"
            prompt += "Intent:"
        
        else:
            # Generic completion
            prompt = ' '.join(symbols)
        
        return prompt
    
    async def generate(
        self, 
        symbols: List[str],
        task: str = "enhance",
        additional_context: Optional[str] = None,
        use_memory: bool = True
    ) -> LLMResponse:
        """Generate response from LLM"""
        
        if not self.is_loaded:
            success = await self.load_model()
            if not success:
                return LLMResponse(
                    text="Error: Model not loaded",
                    confidence=0.0,
                    tokens=0,
                    latency_ms=0,
                    model=self.config.model_name,
                    finish_reason="error"
                )
        
        try:
            start_time = time.time()
            
            # Create prompt
            prompt = self._create_prompt(symbols, task, additional_context)
            
            # Generate response using MLX
            # This runs on Apple Silicon GPU for maximum speed
            response_text = generate(
                self.model,
                self.tokenizer,
                prompt=prompt,
                max_tokens=self.config.max_tokens,
                temp=self.config.temperature,
                top_p=self.config.top_p,
                repetition_penalty=self.config.repetition_penalty
            )
            
            # Clean up response
            response_text = response_text.strip()
            
            # Post-process
            if task == "enhance":
                # Ensure proper capitalization and punctuation
                if response_text and response_text[0].islower():
                    response_text = response_text[0].upper() + response_text[1:]
                
                if response_text and response_text[-1] not in '.!?':
                    response_text += '.'
            
            # Calculate metrics
            latency_ms = (time.time() - start_time) * 1000
            tokens = len(response_text.split())
            
            # Update memory if requested
            if use_memory:
                self.memory.add_message("user", ' '.join(symbols))
                self.memory.add_message("assistant", response_text)
            
            # Update statistics
            self.stats["total_generations"] += 1
            self.stats["total_tokens"] += tokens
            self.stats["total_latency_ms"] += latency_ms
            
            # Calculate confidence (simplified)
            confidence = min(0.95, 0.7 + (1 / (latency_ms / 100)))
            
            logger.info(f"Generated in {latency_ms:.0f}ms: {response_text[:50]}...")
            
            return LLMResponse(
                text=response_text,
                confidence=confidence,
                tokens=tokens,
                latency_ms=latency_ms,
                model=self.config.model_name,
                finish_reason="complete"
            )
            
        except Exception as e:
            logger.error(f"Generation error: {e}")
            self.stats["errors"] += 1
            
            return LLMResponse(
                text=f"Error: {str(e)}",
                confidence=0.0,
                tokens=0,
                latency_ms=0,
                model=self.config.model_name,
                finish_reason="error"
            )
    
    async def enhance_communication(
        self,
        symbols: List[str],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Main method for enhancing AAC communication
        
        Returns:
            - sentence: Enhanced natural language
            - suggestions: Follow-up symbol suggestions
            - intent: Detected intent
            - urgency: Urgency level
        """
        
        # Extract context
        additional_context = None
        if context:
            time_of_day = context.get("time_of_day", "")
            location = context.get("location", "")
            emotion = context.get("emotion", "")
            
            context_parts = []
            if time_of_day:
                context_parts.append(f"Time: {time_of_day}")
            if location:
                context_parts.append(f"Location: {location}")
            if emotion:
                context_parts.append(f"Emotion: {emotion}")
            
            if context_parts:
                additional_context = ", ".join(context_parts)
        
        # Generate enhanced sentence
        sentence_result = await self.generate(
            symbols,
            task="enhance",
            additional_context=additional_context,
            use_memory=True
        )
        
        # Detect intent (run in parallel)
        intent_task = asyncio.create_task(
            self.generate(symbols, task="intent", use_memory=False)
        )
        
        # Get predictions (run in parallel)
        predict_task = asyncio.create_task(
            self.generate(symbols, task="predict", use_memory=False)
        )
        
        # Wait for parallel tasks
        intent_result = await intent_task
        predict_result = await predict_task
        
        # Parse intent
        intent_text = intent_result.text.upper()
        if "EMERGENCY" in intent_text or "URGENT" in intent_text:
            intent = "EMERGENCY"
            urgency = "URGENT"
        elif "REQUEST" in intent_text:
            intent = "REQUEST"
            urgency = "HIGH" if "HIGH" in intent_text else "MEDIUM"
        elif "QUESTION" in intent_text:
            intent = "QUESTION"
            urgency = "MEDIUM"
        else:
            intent = "STATEMENT"
            urgency = "LOW"
        
        # Parse predictions
        suggestions = []
        if predict_result.text:
            suggestions = [
                s.strip() 
                for s in predict_result.text.split(',')
                if s.strip()
            ][:5]  # Top 5 suggestions
        
        return {
            "sentence": sentence_result.text,
            "confidence": sentence_result.confidence,
            "suggestions": suggestions,
            "intent": intent,
            "urgency": urgency,
            "latency_ms": sentence_result.latency_ms,
            "model": sentence_result.model
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics"""
        avg_latency = (
            self.stats["total_latency_ms"] / self.stats["total_generations"]
            if self.stats["total_generations"] > 0
            else 0
        )
        
        avg_tokens = (
            self.stats["total_tokens"] / self.stats["total_generations"]
            if self.stats["total_generations"] > 0
            else 0
        )
        
        return {
            "is_loaded": self.is_loaded,
            "model": self.config.model_name,
            "total_generations": self.stats["total_generations"],
            "total_tokens": self.stats["total_tokens"],
            "errors": self.stats["errors"],
            "avg_latency_ms": round(avg_latency, 2),
            "avg_tokens": round(avg_tokens, 2),
            "mlx_available": MLX_AVAILABLE
        }
    
    def clear_memory(self):
        """Clear conversation memory"""
        self.memory.clear()
        logger.info("Conversation memory cleared")
    
    async def unload_model(self):
        """Unload model to free memory"""
        if not self.is_loaded:
            return
        
        self.model = None
        self.tokenizer = None
        self.is_loaded = False
        
        # Force garbage collection
        import gc
        gc.collect()
        
        logger.info("Model unloaded")


# Global instance
_mlx_engine: Optional[MLXEngine] = None


def get_mlx_engine(config: Optional[LLMConfig] = None) -> MLXEngine:
    """Get or create global MLX engine instance"""
    global _mlx_engine
    
    if _mlx_engine is None:
        _mlx_engine = MLXEngine(config)
    
    return _mlx_engine
