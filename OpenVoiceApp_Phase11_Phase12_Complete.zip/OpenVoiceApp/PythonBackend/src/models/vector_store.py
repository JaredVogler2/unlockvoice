"""
Vector Store for FAISS Index Persistence
Handles saving/loading of FAISS indices and metadata
"""

import logging
import numpy as np
import json
import os
from typing import List, Dict, Any, Optional
from datetime import datetime
from pathlib import Path
import pickle

logger = logging.getLogger(__name__)


class VectorStore:
    """
    Persistent storage for FAISS indices and conversation metadata
    """
    
    def __init__(
        self,
        storage_dir: str = "./data/vector_store",
        index_name: str = "conversations"
    ):
        """
        Initialize vector store
        
        Args:
            storage_dir: Directory for storing indices
            index_name: Name of the index
        """
        self.storage_dir = Path(storage_dir)
        self.index_name = index_name
        
        # Paths
        self.index_path = self.storage_dir / f"{index_name}.index"
        self.metadata_path = self.storage_dir / f"{index_name}_metadata.json"
        self.conversations_path = self.storage_dir / f"{index_name}_conversations.pkl"
        self.config_path = self.storage_dir / f"{index_name}_config.json"
        
        # Create storage directory
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"VectorStore initialized: {self.storage_dir}")
    
    def save_index(
        self,
        index: Any,
        conversations: List[Dict[str, Any]],
        metadata: Dict[str, Any]
    ) -> bool:
        """
        Save FAISS index and associated data
        
        Args:
            index: FAISS index object
            conversations: List of conversation dictionaries
            metadata: Additional metadata
            
        Returns:
            True if successful
        """
        try:
            import faiss
            
            # Save FAISS index
            faiss.write_index(index, str(self.index_path))
            logger.info(f"Saved FAISS index to {self.index_path}")
            
            # Save conversations
            with open(self.conversations_path, 'wb') as f:
                pickle.dump(conversations, f)
            logger.info(f"Saved {len(conversations)} conversations")
            
            # Save metadata
            metadata['last_save'] = datetime.now().isoformat()
            metadata['num_vectors'] = index.ntotal
            metadata['num_conversations'] = len(conversations)
            
            with open(self.metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            logger.info(f"Saved metadata")
            
            return True
            
        except Exception as e:
            logger.error(f"Error saving index: {e}")
            return False
    
    def load_index(
        self
    ) -> tuple[Any, List[Dict[str, Any]], Dict[str, Any]]:
        """
        Load FAISS index and associated data
        
        Returns:
            Tuple of (index, conversations, metadata)
        """
        try:
            import faiss
            
            # Check if files exist
            if not self.index_path.exists():
                logger.info("No saved index found")
                return None, [], {}
            
            # Load FAISS index
            index = faiss.read_index(str(self.index_path))
            logger.info(f"Loaded FAISS index with {index.ntotal} vectors")
            
            # Load conversations
            conversations = []
            if self.conversations_path.exists():
                with open(self.conversations_path, 'rb') as f:
                    conversations = pickle.load(f)
                logger.info(f"Loaded {len(conversations)} conversations")
            
            # Load metadata
            metadata = {}
            if self.metadata_path.exists():
                with open(self.metadata_path, 'r') as f:
                    metadata = json.load(f)
                logger.info("Loaded metadata")
            
            return index, conversations, metadata
            
        except Exception as e:
            logger.error(f"Error loading index: {e}")
            return None, [], {}
    
    def save_config(self, config: Dict[str, Any]) -> bool:
        """
        Save configuration
        
        Args:
            config: Configuration dictionary
            
        Returns:
            True if successful
        """
        try:
            with open(self.config_path, 'w') as f:
                json.dump(config, f, indent=2)
            logger.info("Saved configuration")
            return True
            
        except Exception as e:
            logger.error(f"Error saving config: {e}")
            return False
    
    def load_config(self) -> Dict[str, Any]:
        """
        Load configuration
        
        Returns:
            Configuration dictionary
        """
        try:
            if self.config_path.exists():
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                logger.info("Loaded configuration")
                return config
            return {}
            
        except Exception as e:
            logger.error(f"Error loading config: {e}")
            return {}
    
    def backup(self, suffix: str = None) -> bool:
        """
        Create backup of current index
        
        Args:
            suffix: Optional suffix for backup (default: timestamp)
            
        Returns:
            True if successful
        """
        try:
            if suffix is None:
                suffix = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            backup_dir = self.storage_dir / "backups" / suffix
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            # Copy files to backup
            import shutil
            
            if self.index_path.exists():
                shutil.copy2(
                    self.index_path,
                    backup_dir / self.index_path.name
                )
            
            if self.conversations_path.exists():
                shutil.copy2(
                    self.conversations_path,
                    backup_dir / self.conversations_path.name
                )
            
            if self.metadata_path.exists():
                shutil.copy2(
                    self.metadata_path,
                    backup_dir / self.metadata_path.name
                )
            
            logger.info(f"Created backup: {backup_dir}")
            return True
            
        except Exception as e:
            logger.error(f"Error creating backup: {e}")
            return False
    
    def restore_backup(self, suffix: str) -> bool:
        """
        Restore from backup
        
        Args:
            suffix: Backup suffix to restore
            
        Returns:
            True if successful
        """
        try:
            backup_dir = self.storage_dir / "backups" / suffix
            
            if not backup_dir.exists():
                logger.error(f"Backup not found: {backup_dir}")
                return False
            
            import shutil
            
            # Restore files
            backup_index = backup_dir / self.index_path.name
            if backup_index.exists():
                shutil.copy2(backup_index, self.index_path)
            
            backup_conversations = backup_dir / self.conversations_path.name
            if backup_conversations.exists():
                shutil.copy2(backup_conversations, self.conversations_path)
            
            backup_metadata = backup_dir / self.metadata_path.name
            if backup_metadata.exists():
                shutil.copy2(backup_metadata, self.metadata_path)
            
            logger.info(f"Restored from backup: {suffix}")
            return True
            
        except Exception as e:
            logger.error(f"Error restoring backup: {e}")
            return False
    
    def list_backups(self) -> List[str]:
        """
        List available backups
        
        Returns:
            List of backup suffixes
        """
        backup_dir = self.storage_dir / "backups"
        if not backup_dir.exists():
            return []
        
        backups = [d.name for d in backup_dir.iterdir() if d.is_dir()]
        return sorted(backups, reverse=True)
    
    def get_size_info(self) -> Dict[str, Any]:
        """
        Get storage size information
        
        Returns:
            Dictionary with size information
        """
        def get_size(path: Path) -> int:
            if path.exists():
                if path.is_file():
                    return path.stat().st_size
                elif path.is_dir():
                    return sum(
                        f.stat().st_size
                        for f in path.rglob('*')
                        if f.is_file()
                    )
            return 0
        
        return {
            'index_size_mb': get_size(self.index_path) / (1024 * 1024),
            'conversations_size_mb': get_size(self.conversations_path) / (1024 * 1024),
            'metadata_size_kb': get_size(self.metadata_path) / 1024,
            'total_size_mb': get_size(self.storage_dir) / (1024 * 1024),
            'num_backups': len(self.list_backups())
        }
    
    def export_data(self, output_path: str) -> bool:
        """
        Export all data to a single file
        
        Args:
            output_path: Path for export file
            
        Returns:
            True if successful
        """
        try:
            import tarfile
            
            with tarfile.open(output_path, 'w:gz') as tar:
                if self.index_path.exists():
                    tar.add(self.index_path, arcname=self.index_path.name)
                if self.conversations_path.exists():
                    tar.add(
                        self.conversations_path,
                        arcname=self.conversations_path.name
                    )
                if self.metadata_path.exists():
                    tar.add(
                        self.metadata_path,
                        arcname=self.metadata_path.name
                    )
            
            logger.info(f"Exported data to {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting data: {e}")
            return False
    
    def import_data(self, import_path: str) -> bool:
        """
        Import data from export file
        
        Args:
            import_path: Path to import file
            
        Returns:
            True if successful
        """
        try:
            import tarfile
            
            with tarfile.open(import_path, 'r:gz') as tar:
                tar.extractall(path=self.storage_dir)
            
            logger.info(f"Imported data from {import_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error importing data: {e}")
            return False
    
    def clear(self) -> bool:
        """
        Clear all stored data
        
        Returns:
            True if successful
        """
        try:
            import shutil
            
            # Create backup before clearing
            self.backup(suffix="before_clear")
            
            # Remove files
            if self.index_path.exists():
                self.index_path.unlink()
            if self.conversations_path.exists():
                self.conversations_path.unlink()
            if self.metadata_path.exists():
                self.metadata_path.unlink()
            if self.config_path.exists():
                self.config_path.unlink()
            
            logger.info("Cleared vector store")
            return True
            
        except Exception as e:
            logger.error(f"Error clearing store: {e}")
            return False
