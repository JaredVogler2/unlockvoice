"""
Phase 9: Advanced Transformer-Based Sentence Formation
Uses T5/FLAN models to transform AAC symbols into natural sentences
"""

import logging
from typing import List, Dict, Any, Optional, Tuple
import torch
from transformers import (
    T5Tokenizer, 
    T5ForConditionalGeneration,
    AutoTokenizer,
    AutoModelForSeq2SeqLM
)
import re
from datetime import datetime

logger = logging.getLogger(__name__)


class TransformerSentenceFormer:
    """
    Advanced sentence formation using transformer models (T5, FLAN-T5)
    Transforms AAC symbol sequences into grammatically correct natural sentences
    """
    
    def __init__(
        self,
        model_name: str = "google/flan-t5-small",
        device: Optional[str] = None,
        max_length: int = 64,
        use_cache: bool = True
    ):
        """
        Initialize transformer sentence former
        
        Args:
            model_name: Hugging Face model identifier
            device: Device to run on ('cpu', 'cuda', 'mps')
            max_length: Maximum output length
            use_cache: Use generation cache
        """
        self.model_name = model_name
        self.device = device or self._detect_device()
        self.max_length = max_length
        self.use_cache = use_cache
        
        self.model = None
        self.tokenizer = None
        self.is_loaded = False
        
        # Performance tracking
        self.generation_count = 0
        self.total_time = 0.0
        
        logger.info(f"TransformerSentenceFormer initialized with {model_name} on {self.device}")
    
    def _detect_device(self) -> str:
        """Detect best available device"""
        if torch.cuda.is_available():
            return "cuda"
        elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    
    async def load(self):
        """Load transformer model and tokenizer"""
        try:
            start_time = datetime.now()
            
            logger.info(f"Loading model {self.model_name}...")
            
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            
            # Load model
            self.model = AutoModelForSeq2SeqLM.from_pretrained(
                self.model_name,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32
            )
            
            # Move to device
            self.model = self.model.to(self.device)
            self.model.eval()
            
            self.is_loaded = True
            
            load_time = (datetime.now() - start_time).total_seconds()
            logger.info(f"Model loaded successfully in {load_time:.2f}s")
            
        except Exception as e:
            logger.error(f"Failed to load transformer model: {e}")
            raise
    
    async def form_sentence(
        self,
        symbols: List[str],
        context: Optional[List[str]] = None,
        temperature: float = 0.7,
        num_beams: int = 3,
        return_alternatives: bool = False
    ) -> Dict[str, Any]:
        """
        Form a natural sentence from AAC symbols using transformer
        
        Args:
            symbols: List of AAC symbol words
            context: Optional conversation context
            temperature: Sampling temperature (0.0 = deterministic, 1.0 = creative)
            num_beams: Beam search width
            return_alternatives: Return multiple sentence options
            
        Returns:
            Dict with formed sentence, confidence, alternatives, and metadata
        """
        try:
            if not self.is_loaded:
                raise RuntimeError("Model not loaded. Call load() first.")
            
            if not symbols:
                return {
                    'sentence': '',
                    'confidence': 0.0,
                    'alternatives': [],
                    'metadata': {'error': 'No symbols provided'}
                }
            
            start_time = datetime.now()
            
            # Create input prompt
            input_text = self._create_prompt(symbols, context)
            
            # Generate sentence
            sentences = self._generate(
                input_text,
                temperature=temperature,
                num_beams=num_beams,
                num_return_sequences=3 if return_alternatives else 1
            )
            
            # Post-process sentences
            processed = [self._post_process(s) for s in sentences]
            
            # Calculate confidence scores
            confidences = self._calculate_confidences(symbols, processed)
            
            # Select best sentence
            best_idx = confidences.index(max(confidences))
            best_sentence = processed[best_idx]
            best_confidence = confidences[best_idx]
            
            # Generate metadata
            generation_time = (datetime.now() - start_time).total_seconds()
            self.generation_count += 1
            self.total_time += generation_time
            
            result = {
                'sentence': best_sentence,
                'confidence': best_confidence,
                'alternatives': processed if return_alternatives else [],
                'metadata': {
                    'model': self.model_name,
                    'symbols_count': len(symbols),
                    'generation_time_ms': int(generation_time * 1000),
                    'temperature': temperature,
                    'num_beams': num_beams,
                    'device': self.device
                }
            }
            
            logger.debug(f"Generated sentence in {generation_time*1000:.1f}ms: {best_sentence}")
            
            return result
            
        except Exception as e:
            logger.error(f"Sentence formation error: {e}")
            # Fallback to simple concatenation
            return {
                'sentence': self._simple_fallback(symbols),
                'confidence': 0.5,
                'alternatives': [],
                'metadata': {'error': str(e), 'fallback': True}
            }
    
    def _create_prompt(
        self,
        symbols: List[str],
        context: Optional[List[str]] = None
    ) -> str:
        """
        Create input prompt for the model
        
        FLAN-T5 works best with instruction-style prompts
        """
        # Join symbols
        symbol_text = ' '.join(symbols).lower()
        
        # Create instruction-based prompt for FLAN-T5
        if context:
            context_text = ' '.join(context[-3:])  # Last 3 items of context
            prompt = (
                f"Convert these AAC symbols into a natural English sentence. "
                f"Previous context: {context_text}. "
                f"Symbols: {symbol_text}. "
                f"Sentence:"
            )
        else:
            prompt = (
                f"Convert these AAC communication symbols into a natural, "
                f"grammatically correct English sentence: {symbol_text}"
            )
        
        return prompt
    
    def _generate(
        self,
        input_text: str,
        temperature: float = 0.7,
        num_beams: int = 3,
        num_return_sequences: int = 1
    ) -> List[str]:
        """Generate sentences using the transformer model"""
        # Tokenize
        inputs = self.tokenizer(
            input_text,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=256
        ).to(self.device)
        
        # Generate
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=self.max_length,
                num_beams=num_beams,
                num_return_sequences=num_return_sequences,
                temperature=temperature,
                do_sample=temperature > 0,
                top_k=50 if temperature > 0 else None,
                top_p=0.95 if temperature > 0 else None,
                repetition_penalty=1.2,
                length_penalty=1.0,
                early_stopping=True,
                use_cache=self.use_cache
            )
        
        # Decode
        sentences = [
            self.tokenizer.decode(output, skip_special_tokens=True)
            for output in outputs
        ]
        
        return sentences
    
    def _post_process(self, sentence: str) -> str:
        """
        Post-process generated sentence
        - Fix capitalization
        - Add/fix punctuation
        - Remove artifacts
        """
        # Remove extra whitespace
        sentence = ' '.join(sentence.split())
        
        # Capitalize first letter
        if sentence:
            sentence = sentence[0].upper() + sentence[1:]
        
        # Ensure ending punctuation
        if sentence and sentence[-1] not in '.!?':
            sentence += '.'
        
        # Fix common patterns
        sentence = re.sub(r'\s+([.,!?])', r'\1', sentence)  # Remove space before punctuation
        sentence = re.sub(r'([.,!?])([A-Za-z])', r'\1 \2', sentence)  # Add space after punctuation
        
        return sentence
    
    def _calculate_confidences(
        self,
        symbols: List[str],
        sentences: List[str]
    ) -> List[float]:
        """
        Calculate confidence scores for generated sentences
        Based on:
        - Length appropriateness
        - Word overlap with input
        - Grammar patterns
        """
        confidences = []
        
        for sentence in sentences:
            confidence = 0.7  # Base confidence
            
            # Length check
            sentence_words = sentence.lower().split()
            symbol_count = len(symbols)
            
            if symbol_count <= len(sentence_words) <= symbol_count * 3:
                confidence += 0.1  # Good length ratio
            
            # Word overlap
            symbol_set = set(s.lower() for s in symbols)
            sentence_set = set(sentence_words)
            overlap = len(symbol_set & sentence_set) / len(symbol_set) if symbol_set else 0
            confidence += overlap * 0.1
            
            # Grammar patterns (simple heuristic)
            if any(pattern in sentence.lower() for pattern in ['i am', 'i want', 'i need', 'i like']):
                confidence += 0.05
            
            # Has proper punctuation
            if sentence and sentence[-1] in '.!?':
                confidence += 0.05
            
            confidences.append(min(confidence, 1.0))
        
        return confidences
    
    def _simple_fallback(self, symbols: List[str]) -> str:
        """Fallback to simple concatenation if generation fails"""
        if not symbols:
            return ""
        
        sentence = ' '.join(symbols)
        sentence = sentence[0].upper() + sentence[1:] if sentence else ""
        
        if sentence and sentence[-1] not in '.!?':
            sentence += '.'
        
        return sentence
    
    def get_stats(self) -> Dict[str, Any]:
        """Get generation statistics"""
        avg_time = (self.total_time / self.generation_count) if self.generation_count > 0 else 0
        
        return {
            'model': self.model_name,
            'device': self.device,
            'is_loaded': self.is_loaded,
            'generations': self.generation_count,
            'total_time_seconds': round(self.total_time, 2),
            'avg_time_ms': int(avg_time * 1000)
        }


class GrammarCorrector:
    """
    Grammar correction and enhancement service
    Uses transformer models to fix grammatical errors
    """
    
    def __init__(self, model_name: str = "google/flan-t5-small"):
        self.model_name = model_name
        self.model = None
        self.tokenizer = None
        self.is_loaded = False
        logger.info(f"GrammarCorrector initialized with {model_name}")
    
    async def load(self):
        """Load grammar correction model"""
        try:
            logger.info(f"Loading grammar model {self.model_name}...")
            
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self.model = AutoModelForSeq2SeqLM.from_pretrained(self.model_name)
            self.model.eval()
            
            self.is_loaded = True
            logger.info("Grammar model loaded successfully")
            
        except Exception as e:
            logger.error(f"Failed to load grammar model: {e}")
            raise
    
    async def correct(
        self,
        text: str,
        preserve_meaning: bool = True
    ) -> Dict[str, Any]:
        """
        Correct grammatical errors in text
        
        Args:
            text: Input text to correct
            preserve_meaning: Try to preserve original meaning
            
        Returns:
            Dict with corrected text and changes
        """
        try:
            if not self.is_loaded:
                raise RuntimeError("Grammar model not loaded")
            
            # Create correction prompt
            prompt = f"Fix any grammatical errors in this sentence: {text}"
            
            # Tokenize
            inputs = self.tokenizer(
                prompt,
                return_tensors="pt",
                padding=True,
                truncation=True
            )
            
            # Generate correction
            with torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    max_length=64,
                    num_beams=2,
                    early_stopping=True
                )
            
            corrected = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            # Detect changes
            changes = self._detect_changes(text, corrected)
            
            return {
                'original': text,
                'corrected': corrected,
                'changes': changes,
                'changed': text.lower() != corrected.lower()
            }
            
        except Exception as e:
            logger.error(f"Grammar correction error: {e}")
            return {
                'original': text,
                'corrected': text,
                'changes': [],
                'changed': False,
                'error': str(e)
            }
    
    def _detect_changes(self, original: str, corrected: str) -> List[str]:
        """Detect what changed between original and corrected"""
        changes = []
        
        if original.lower() != corrected.lower():
            changes.append(f"Grammar corrected: '{original}' → '{corrected}'")
        
        return changes


class ContextAwareEnhancer:
    """
    Enhances sentence formation with conversation context
    Uses recent history to improve coherence and relevance
    """
    
    def __init__(self, max_context_length: int = 5):
        self.max_context_length = max_context_length
        self.conversation_history = []
        logger.info("ContextAwareEnhancer initialized")
    
    def add_to_context(self, text: str):
        """Add a sentence to conversation context"""
        self.conversation_history.append(text)
        
        # Keep only recent history
        if len(self.conversation_history) > self.max_context_length:
            self.conversation_history.pop(0)
    
    def get_context(self) -> List[str]:
        """Get current conversation context"""
        return self.conversation_history.copy()
    
    def enhance_prompt(
        self,
        symbols: List[str],
        base_prompt: str
    ) -> str:
        """
        Enhance prompt with conversation context
        
        Args:
            symbols: Current AAC symbols
            base_prompt: Base prompt to enhance
            
        Returns:
            Enhanced prompt with context
        """
        if not self.conversation_history:
            return base_prompt
        
        # Get recent context
        recent = self.conversation_history[-3:]
        context_text = ' '.join(recent)
        
        # Create context-aware prompt
        enhanced = (
            f"Based on this conversation: {context_text}. "
            f"{base_prompt}"
        )
        
        return enhanced
    
    def clear_context(self):
        """Clear conversation history"""
        self.conversation_history.clear()
        logger.info("Context cleared")
