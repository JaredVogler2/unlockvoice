"""
Advanced RAG Engine with FAISS Vector Search
Phase 8: Semantic similarity search using sentence-transformers and FAISS
"""

import logging
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from collections import Counter
from datetime import datetime, timedelta
import asyncio

logger = logging.getLogger(__name__)


class FAISSRAGEngine:
    """
    Advanced RAG engine using FAISS for efficient vector similarity search
    """
    
    def __init__(
        self,
        embedding_dim: int = 384,
        similarity_threshold: float = 0.7,
        max_conversations: int = 100000,
        temporal_decay: float = 0.95,
        save_interval: int = 100,
        storage_dir: str = "./data/vector_store"
    ):
        """
        Initialize FAISS RAG engine
        
        Args:
            embedding_dim: Dimension of embedding vectors
            similarity_threshold: Minimum similarity score
            max_conversations: Maximum conversations to store
            temporal_decay: Decay factor for temporal weighting
            save_interval: Auto-save every N additions
            storage_dir: Directory for persistent storage
        """
        self.embedding_dim = embedding_dim
        self.similarity_threshold = similarity_threshold
        self.max_conversations = max_conversations
        self.temporal_decay = temporal_decay
        self.save_interval = save_interval
        
        # FAISS index
        self.index = None
        self.conversations = []
        self.timestamps = []
        
        # Services
        self.embedding_service = None
        self.vector_store = None
        
        # Statistics
        self.stats = {
            'total_added': 0,
            'total_searches': 0,
            'total_predictions': 0,
            'avg_search_time_ms': 0,
            'last_save': None
        }
        
        self.is_ready = False
        self.additions_since_save = 0
        
        logger.info(f"FAISSRAGEngine initialized (dim={embedding_dim})")
    
    async def initialize(self):
        """
        Initialize FAISS index and load from storage
        """
        try:
            # Import here to check availability
            import faiss
            from .embedding_service import get_embedding_service
            from .vector_store import VectorStore
            
            # Initialize embedding service
            self.embedding_service = get_embedding_service()
            if not self.embedding_service.is_ready:
                await self.embedding_service.initialize()
            
            # Initialize vector store
            self.vector_store = VectorStore(
                storage_dir=storage_dir,
                index_name="rag_conversations"
            )
            
            # Try to load existing index
            loaded_index, loaded_convs, metadata = self.vector_store.load_index()
            
            if loaded_index is not None:
                logger.info("Loaded existing FAISS index")
                self.index = loaded_index
                self.conversations = loaded_convs
                self.timestamps = [
                    datetime.fromisoformat(c.get('timestamp', datetime.now().isoformat()))
                    for c in loaded_convs
                ]
                self.stats.update(metadata.get('stats', {}))
            else:
                logger.info("Creating new FAISS index")
                # Create new index (L2 distance)
                self.index = faiss.IndexFlatL2(self.embedding_dim)
                
                # Optionally wrap with ID mapping
                self.index = faiss.IndexIDMap(self.index)
            
            self.is_ready = True
            logger.info(
                f"FAISS RAG engine ready. "
                f"Conversations: {len(self.conversations)}, "
                f"Vectors: {self.index.ntotal}"
            )
            
        except ImportError as e:
            logger.error(
                "Required packages not installed. "
                "Install with: pip install faiss-cpu sentence-transformers"
            )
            raise
        except Exception as e:
            logger.error(f"Failed to initialize FAISS RAG: {e}")
            raise
    
    async def add_conversation(
        self,
        conversation: Dict[str, Any]
    ) -> bool:
        """
        Add conversation to RAG system
        
        Args:
            conversation: Dictionary with 'text', 'timestamp', 'metadata'
            
        Returns:
            True if added successfully
        """
        if not self.is_ready:
            raise RuntimeError("RAG engine not initialized")
        
        try:
            text = conversation.get('text', '').strip()
            if not text:
                return False
            
            # Check for duplicates (semantic deduplication)
            if await self._is_duplicate(text):
                logger.debug(f"Skipping duplicate: {text[:50]}")
                return False
            
            # Generate embedding
            embedding = await self.embedding_service.embed_text(text)
            
            # Add to FAISS index
            conv_id = len(self.conversations)
            self.index.add_with_ids(
                np.array([embedding], dtype='float32'),
                np.array([conv_id], dtype='int64')
            )
            
            # Store conversation data
            timestamp = conversation.get('timestamp')
            if isinstance(timestamp, str):
                timestamp = datetime.fromisoformat(timestamp)
            elif timestamp is None:
                timestamp = datetime.now()
            
            self.conversations.append({
                'id': conv_id,
                'text': text,
                'timestamp': timestamp.isoformat(),
                'metadata': conversation.get('metadata', {})
            })
            self.timestamps.append(timestamp)
            
            # Update stats
            self.stats['total_added'] += 1
            self.additions_since_save += 1
            
            # Auto-save if needed
            if self.additions_since_save >= self.save_interval:
                await self.save()
            
            # Check limit
            if len(self.conversations) > self.max_conversations:
                await self._prune_old_conversations()
            
            logger.debug(f"Added conversation {conv_id}: {text[:50]}")
            return True
            
        except Exception as e:
            logger.error(f"Error adding conversation: {e}")
            return False
    
    async def _is_duplicate(
        self,
        text: str,
        threshold: float = 0.95
    ) -> bool:
        """
        Check if text is duplicate of existing conversation
        """
        if len(self.conversations) == 0:
            return False
        
        try:
            # Search for very similar texts
            results = await self.search_similar(text, k=1)
            if results and results[0]['score'] > threshold:
                return True
            return False
        except:
            return False
    
    async def search_similar(
        self,
        query: str,
        k: int = 20,
        use_temporal_weighting: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Search for similar conversations using FAISS
        
        Args:
            query: Query text
            k: Number of results to return
            use_temporal_weighting: Apply temporal decay to scores
            
        Returns:
            List of similar conversations with scores
        """
        if not self.is_ready:
            raise RuntimeError("RAG engine not initialized")
        
        if len(self.conversations) == 0:
            return []
        
        try:
            import time
            start_time = time.time()
            
            # Generate query embedding
            query_embedding = await self.embedding_service.embed_text(query)
            query_embedding = np.array([query_embedding], dtype='float32')
            
            # Search FAISS index
            k_search = min(k * 2, len(self.conversations))  # Search more, filter later
            distances, indices = self.index.search(query_embedding, k_search)
            
            # Convert distances to similarity scores (L2 -> cosine-like)
            # Lower distance = higher similarity
            # Normalize to 0-1 range
            max_distance = np.max(distances[0]) if len(distances[0]) > 0 else 1
            similarities = 1.0 - (distances[0] / (max_distance + 1e-8))
            
            # Build results
            results = []
            current_time = datetime.now()
            
            for idx, similarity in zip(indices[0], similarities):
                if idx == -1:  # FAISS returns -1 for empty results
                    continue
                
                conv = self.conversations[idx]
                score = float(similarity)
                
                # Apply temporal weighting
                if use_temporal_weighting:
                    timestamp = datetime.fromisoformat(conv['timestamp'])
                    days_ago = (current_time - timestamp).days
                    temporal_weight = self.temporal_decay ** days_ago
                    score = score * temporal_weight
                
                # Filter by threshold
                if score >= self.similarity_threshold:
                    results.append({
                        'id': conv['id'],
                        'text': conv['text'],
                        'score': score,
                        'timestamp': conv['timestamp'],
                        'metadata': conv.get('metadata', {})
                    })
            
            # Sort by score and limit to k
            results.sort(key=lambda x: x['score'], reverse=True)
            results = results[:k]
            
            # Update stats
            search_time = (time.time() - start_time) * 1000
            self.stats['total_searches'] += 1
            self.stats['avg_search_time_ms'] = (
                (self.stats['avg_search_time_ms'] * (self.stats['total_searches'] - 1) + search_time)
                / self.stats['total_searches']
            )
            
            logger.debug(
                f"Found {len(results)} similar conversations "
                f"(query: '{query[:30]}...', time: {search_time:.2f}ms)"
            )
            
            return results
            
        except Exception as e:
            logger.error(f"Error searching similar: {e}")
            return []
    
    async def predict(
        self,
        current_phrase: str,
        conversation_history: List[str] = None,
        k: int = 20,
        max_predictions: int = 10
    ) -> Dict[str, Any]:
        """
        Predict next words using RAG
        
        Args:
            current_phrase: Current phrase being typed
            conversation_history: Recent conversation history
            k: Number of similar conversations to consider
            max_predictions: Maximum predictions to return
            
        Returns:
            Dictionary with predictions and metadata
        """
        if not self.is_ready:
            raise RuntimeError("RAG engine not initialized")
        
        try:
            # Add recent history to index
            if conversation_history:
                for conv_text in conversation_history:
                    await self.add_conversation({
                        'text': conv_text,
                        'timestamp': datetime.now().isoformat()
                    })
            
            # Find similar conversations
            similar = await self.search_similar(current_phrase, k=k)
            
            if not similar:
                return {
                    'predictions': [],
                    'similar_contexts': [],
                    'relevance_scores': []
                }
            
            # Extract next words from similar conversations
            predictions = self._extract_predictions(
                current_phrase,
                similar,
                max_predictions
            )
            
            # Update stats
            self.stats['total_predictions'] += len(predictions)
            
            return {
                'predictions': predictions,
                'similar_contexts': [s['text'] for s in similar[:5]],
                'relevance_scores': [s['score'] for s in similar[:5]],
                'num_contexts': len(similar)
            }
            
        except Exception as e:
            logger.error(f"RAG prediction error: {e}")
            return {
                'predictions': [],
                'similar_contexts': [],
                'relevance_scores': []
            }
    
    def _extract_predictions(
        self,
        current_phrase: str,
        similar_conversations: List[Dict[str, Any]],
        max_predictions: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Extract next word predictions from similar conversations
        """
        predictions = []
        current_words = current_phrase.lower().split()
        
        if not current_words:
            return predictions
        
        # Get last 1-3 words for context
        context_lengths = [1, 2, 3]
        next_words_weighted = Counter()
        
        for conv in similar_conversations:
            words = conv['text'].lower().split()
            conv_score = conv['score']
            
            # Try different context lengths
            for context_len in context_lengths:
                if len(current_words) < context_len:
                    continue
                
                context = current_words[-context_len:]
                
                # Find occurrences of context and get next word
                for i in range(len(words) - context_len):
                    if words[i:i+context_len] == context and i + context_len < len(words):
                        next_word = words[i + context_len]
                        # Weight by conversation score and context length
                        weight = conv_score * (context_len ** 1.5)
                        next_words_weighted[next_word] += weight
        
        # Convert to predictions
        total_weight = sum(next_words_weighted.values())
        
        for word, weight in next_words_weighted.most_common(max_predictions):
            if total_weight > 0:
                confidence = min(0.95, 0.5 + (weight / total_weight))
            else:
                confidence = 0.5
            
            predictions.append({
                'text': word,
                'confidence': confidence,
                'source': 'rag_semantic',
                'metadata': {
                    'weight': weight,
                    'from_contexts': len(similar_conversations)
                }
            })
        
        return predictions
    
    async def save(self) -> bool:
        """
        Save index and data to disk
        """
        if not self.is_ready:
            return False
        
        try:
            metadata = {
                'stats': self.stats,
                'config': {
                    'embedding_dim': self.embedding_dim,
                    'similarity_threshold': self.similarity_threshold,
                    'temporal_decay': self.temporal_decay
                }
            }
            
            success = self.vector_store.save_index(
                self.index,
                self.conversations,
                metadata
            )
            
            if success:
                self.additions_since_save = 0
                self.stats['last_save'] = datetime.now().isoformat()
                logger.info("Saved RAG index successfully")
            
            return success
            
        except Exception as e:
            logger.error(f"Error saving index: {e}")
            return False
    
    async def _prune_old_conversations(self):
        """
        Remove oldest conversations when limit exceeded
        """
        try:
            num_to_remove = len(self.conversations) - int(self.max_conversations * 0.9)
            
            if num_to_remove <= 0:
                return
            
            logger.info(f"Pruning {num_to_remove} old conversations")
            
            # Sort by timestamp
            sorted_indices = sorted(
                range(len(self.conversations)),
                key=lambda i: self.timestamps[i]
            )
            
            # Remove oldest
            indices_to_remove = set(sorted_indices[:num_to_remove])
            
            # Rebuild index and conversations
            import faiss
            new_index = faiss.IndexFlatL2(self.embedding_dim)
            new_index = faiss.IndexIDMap(new_index)
            
            new_conversations = []
            new_timestamps = []
            
            for i, conv in enumerate(self.conversations):
                if i not in indices_to_remove:
                    # Re-embed and add to new index
                    text = conv['text']
                    embedding = await self.embedding_service.embed_text(text)
                    new_id = len(new_conversations)
                    
                    new_index.add_with_ids(
                        np.array([embedding], dtype='float32'),
                        np.array([new_id], dtype='int64')
                    )
                    
                    conv['id'] = new_id
                    new_conversations.append(conv)
                    new_timestamps.append(self.timestamps[i])
            
            self.index = new_index
            self.conversations = new_conversations
            self.timestamps = new_timestamps
            
            # Save after pruning
            await self.save()
            
        except Exception as e:
            logger.error(f"Error pruning conversations: {e}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get RAG statistics
        """
        return {
            **self.stats,
            'total_conversations': len(self.conversations),
            'total_vectors': self.index.ntotal if self.index else 0,
            'is_ready': self.is_ready,
            'embedding_dim': self.embedding_dim,
            'similarity_threshold': self.similarity_threshold,
            'storage_info': self.vector_store.get_size_info() if self.vector_store else {}
        }


# Global instance
_rag_engine: Optional[FAISSRAGEngine] = None


def get_rag_engine() -> FAISSRAGEngine:
    """
    Get global RAG engine instance
    """
    global _rag_engine
    if _rag_engine is None:
        _rag_engine = FAISSRAGEngine()
    return _rag_engine
