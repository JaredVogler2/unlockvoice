# 🎨 SYMBOL IMAGES GUIDE - Getting Your 70+ AAC Symbols

## 📋 Overview

You need **70+ symbol images** for OpenVoice. This guide shows you how to get them quickly and legally.

**Time needed**: 2-4 hours  
**Cost**: Free - $100 (depending on option)  
**Result**: Professional AAC symbol library

---

## 🎯 Option 1: Mulberry Symbols (RECOMMENDED) ✅

**Best for**: Free, professional, designed for AAC  
**Cost**: FREE  
**License**: CC BY-SA 2.0 (free to use, modify, distribute)  
**Quality**: Excellent (designed by AAC experts)

### Step 1: Download Mulberry Symbols

```bash
# Visit website
https://mulberrysymbols.org/

# Or download directly
https://github.com/straight-street/mulberry-symbols/archive/refs/heads/master.zip
```

### Step 2: Extract and Organize

```bash
# Unzip the file
unzip mulberry-symbols-master.zip

# Navigate to symbols
cd mulberry-symbols-master/EN/

# You'll see thousands of SVG files organized by category
```

### Step 3: Select Your 70 Symbols

**Categories to cover** (suggested distribution):
- Food/Drink: 15 symbols (apple, water, eat, hungry, etc.)
- Actions: 15 symbols (go, stop, want, need, help, etc.)
- People: 10 symbols (mom, dad, friend, me, you, etc.)
- Places: 8 symbols (home, school, bathroom, bed, etc.)
- Feelings: 10 symbols (happy, sad, angry, scared, etc.)
- Basic needs: 8 symbols (toilet, sleep, pain, sick, etc.)
- Time: 4 symbols (now, later, today, tomorrow)

**Recommended core vocabulary**:
```
Essential (must-have):
- yes, no, help, stop, go
- want, need, like, don't like
- more, all done, again
- mom, dad, me, you
- happy, sad, angry
- eat, drink, water, food
- bathroom, sleep, home
- now, please, thank you
```

### Step 4: Convert SVG to PNG

**Using ImageMagick** (command line):
```bash
# Install ImageMagick
brew install imagemagick  # Mac
sudo apt-get install imagemagick  # Linux

# Convert all symbols to PNG 512x512
for file in *.svg; do
    convert "$file" -resize 512x512 -background white -flatten "${file%.svg}.png"
done
```

**Using Online Tool**:
```
1. Visit: https://cloudconvert.com/svg-to-png
2. Upload SVG files
3. Set size to 512x512
4. Download PNG files
```

**Using Sketch/Figma** (if you have them):
```
1. Import SVG files
2. Export as PNG @ 2x (1024x1024)
3. Resize to 512x512 in Preview/Photos
```

### Step 5: Add to Xcode

```
1. Open your Xcode project
2. Select Assets.xcassets
3. Right-click > New Folder > Name it "Symbols"
4. Drag your 70+ PNG files into the Symbols folder
5. For each image:
   - Click the image
   - Set "Scales" to "Single Scale"
   - Ensure "Devices" is "Universal"
```

### Step 6: Update SymbolLibraryService.swift

```swift
// Update the loadBuiltInSymbols() method:

private func loadBuiltInSymbols() -> [Symbol] {
    var symbols: [Symbol] = []
    
    // Food category
    symbols.append(Symbol(
        id: UUID(),
        label: "Apple",
        imageName: "apple",  // Should match PNG filename without extension
        category: .food,
        frequency: 0
    ))
    
    symbols.append(Symbol(
        id: UUID(),
        label: "Water",
        imageName: "water",
        category: .drink,
        frequency: 0
    ))
    
    // ... repeat for all 70+ symbols
    
    return symbols
}
```

---

## 🎯 Option 2: ARASAAC Symbols (ALTERNATIVE)

**Best for**: More variety, multilingual support  
**Cost**: FREE  
**License**: CC BY-NC-SA 3.0 (free for non-commercial)  
**Quality**: Excellent

### Download

```
Visit: https://arasaac.org/
Click: Downloads
Choose: PNG format
Select: Size 500px
Download symbol packs by category
```

**Pros**:
- 15,000+ symbols
- Multiple languages
- Color and B&W versions

**Cons**:
- Non-commercial license (may need permission for App Store)
- Requires attribution

---

## 🎯 Option 3: Create Your Own (CUSTOM)

**Best for**: Unique brand, specific needs  
**Cost**: $50-200 (if hiring designer)  
**Time**: 2-4 days

### Using Canva (Easy, $0-13/month)

```
1. Sign up for Canva (free or Pro)
2. Create new design: Custom size 512x512px
3. Search for icon templates
4. Customize with:
   - Simple shapes
   - Flat colors
   - Clear outlines
   - Minimal detail
5. Export as PNG
6. Repeat for all symbols
```

**Tips**:
- Keep it simple (icons, not illustrations)
- Use consistent style across all symbols
- High contrast for visibility
- White or transparent background
- Test at small size (looks good at 64x64?)

### Hiring a Designer (Fiverr, Upwork)

```
Budget: $50-200 for 70 symbols

Job posting template:
"Need 70 simple AAC communication symbols in consistent style.
Specifications:
- 512x512px PNG
- Flat design, simple, minimalist
- White background
- High contrast
- Examples: apple, water, home, happy, help, etc.
- Full list provided
- Commercial license included"
```

---

## 🎯 Option 4: Mix SF Symbols + Free Sets (FASTEST)

**Best for**: Getting to market quickly  
**Cost**: FREE  
**Time**: 1-2 hours

### Use What's Already Available

```swift
// Many symbols work fine with SF Symbols
// Update SymbolLibraryService.swift:

private func loadBuiltInSymbols() -> [Symbol] {
    var symbols: [Symbol] = []
    
    // Use SF Symbols for common items
    let sfSymbols = [
        ("house.fill", "Home", SymbolCategory.places),
        ("person.fill", "Me", SymbolCategory.people),
        ("heart.fill", "Love", SymbolCategory.feelings),
        ("hand.raised.fill", "Stop", SymbolCategory.actions),
        // ... etc
    ]
    
    for (sfSymbol, label, category) in sfSymbols {
        symbols.append(Symbol(
            id: UUID(),
            label: label,
            sfSymbolName: sfSymbol,  // Add this property to Symbol model
            category: category,
            frequency: 0
        ))
    }
    
    return symbols
}
```

### Then Add Custom PNG for Others

```
Download free icon packs for items SF Symbols doesn't have:
- Flaticon.com (some free with attribution)
- Icons8.com (some free with attribution)
- TheNounProject.com (some free with attribution)

Always check license!
```

---

## 📐 Image Specifications

### Required Specs

```
Format: PNG
Size: 512x512px minimum
Color space: sRGB
Background: White or transparent
Bit depth: 24-bit (RGB) or 32-bit (RGBA)
File size: <100KB per image (ideally)
```

### Naming Convention

```
Use lowercase, underscores:
✅ apple.png
✅ happy_face.png
✅ toilet_bathroom.png

Avoid:
❌ Apple.png (capital)
❌ happy-face.png (hyphens)
❌ toilet bathroom.png (spaces)
```

### Style Guidelines

**Good AAC symbols are**:
- ✅ Simple and recognizable
- ✅ High contrast
- ✅ Clear at small sizes
- ✅ Consistent style
- ✅ Culturally appropriate
- ✅ Age-appropriate

**Avoid**:
- ❌ Too much detail
- ❌ Small text
- ❌ Low contrast
- ❌ Photographs (unless for custom symbols)
- ❌ Offensive imagery
- ❌ Copyrighted characters

---

## 🔧 Batch Processing Tools

### ImageMagick (Command Line)

```bash
# Resize all images to 512x512
mogrify -resize 512x512 -background white -flatten *.png

# Convert SVG to PNG
for file in *.svg; do
    convert "$file" -resize 512x512 -background white -flatten "${file%.svg}.png"
done

# Add white background to transparent PNGs
mogrify -background white -alpha remove -alpha off *.png

# Optimize file size
mogrify -quality 85 *.png
```

### Sketch/Figma Export

```
Figma:
1. Select all symbols
2. Export settings:
   - Format: PNG
   - Size: 2x
   - Suffix: @2x
3. Export all

Then resize if needed
```

---

## ✅ Quality Checklist

Before adding symbols to Xcode, verify:

- [ ] All images are 512x512px
- [ ] All images are PNG format
- [ ] File names match Swift code
- [ ] No spaces or special characters in filenames
- [ ] Images look good at small size (64x64)
- [ ] Consistent style across all symbols
- [ ] White or transparent background
- [ ] High contrast
- [ ] Total size <5MB for all symbols

---

## 📊 Symbol Categories & Recommended Count

```
Total: 70-100 symbols

Food/Drink: 15-20
- apple, banana, bread, cheese, chicken
- water, milk, juice, coffee, tea
- hungry, eat, drink, yummy, more

Actions: 15-20
- go, stop, come, look, listen
- want, need, like, love, hate
- help, please, thank you, sorry
- open, close, push, pull

People: 10-12
- me, you, mom, dad, brother, sister
- friend, teacher, doctor, family

Places: 8-10
- home, school, store, park, bathroom
- bedroom, kitchen, outside

Feelings: 10-12
- happy, sad, angry, scared, surprised
- tired, sick, hurt, excited, calm

Basic Needs: 8-10
- toilet, bath, sleep, pain, medicine
- hot, cold, quiet, loud

Time: 5
- now, later, today, tomorrow, wait

Yes/No/Basic: 5
- yes, no, maybe, stop, go
```

---

## 💡 Pro Tips

1. **Start with core vocabulary**
   - Get the most essential 30 symbols first
   - Test with those
   - Add more categories later

2. **Think about your users**
   - Child? Use colorful, playful style
   - Adult? Use neutral, professional style
   - Mixed? Use universally recognizable style

3. **Test at actual size**
   - View symbols at 64x64px
   - Can you still recognize them?
   - If not, simplify

4. **Keep it consistent**
   - Same line weight
   - Same level of detail
   - Same color palette
   - Makes app feel professional

5. **Plan for expansion**
   - Users will want to add more symbols
   - Keep style guide notes
   - Make it easy to create matching symbols

---

## 🚀 Quick Start: 1 Hour Version

**If you need to start NOW**:

1. **Use SF Symbols for 40 symbols** (30 minutes)
   - Already built into iOS
   - Zero download needed
   - See list of good AAC matches above

2. **Download Mulberry for 30 symbols** (30 minutes)
   - Go to mulberrysymbols.org
   - Download ZIP
   - Extract and grab 30 most important
   - Convert to PNG (online tool)
   - Add to Xcode

**Done!** You have 70 symbols and can ship.

Refine later as time allows.

---

## 📞 Need Help?

**Image issues?**
- Check file format (PNG not JPG)
- Verify size (512x512 minimum)
- Ensure files are in Assets.xcassets

**License questions?**
- Mulberry: CC BY-SA (completely free, commercial OK)
- ARASAAC: CC BY-NC-SA (free for non-commercial)
- Custom: You own it

**Can't find a symbol?**
- Check TheNounProject
- Use SF Symbols as placeholder
- Create simple version in Canva
- Users can add custom symbols anyway!

---

**You've got this!** Getting symbols is straightforward. Don't overthink it - Mulberry Symbols are perfect and free. 🎨✨
