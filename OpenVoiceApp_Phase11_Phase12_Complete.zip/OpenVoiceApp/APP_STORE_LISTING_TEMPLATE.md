# 📱 APP STORE LISTING TEMPLATE

## Complete metadata for OpenVoice submission to Apple App Store

---

## 📝 App Information

### App Name
```
OpenVoice AAC
```
*(30 character limit)*

**Alternative options if taken**:
- OpenVoice Communication
- OpenVoice - Free AAC
- OpenVoice AAC Talk
- Voice+ AAC

---

### Subtitle
```
Free AAC Communication App
```
*(30 character limit)*

**Alternative options**:
- Speak Freely with Symbols
- AAC for Everyone
- Symbol-Based Communication
- Eye Tracking AAC

---

### Promotional Text
```
🆕 NEW: AI-powered predictions learn your communication patterns
🎯 70+ symbols across 11 categories
👁️ Revolutionary eye tracking for hands-free use
🔒 100% private - no data collection
💙 Free forever - no subscriptions
```
*(170 character limit)*

---

## 📄 Description (4,000 characters max)

### Full Description

```
OpenVoice is a free, open-source AAC (Augmentative and Alternative Communication) application designed for non-verbal individuals, including autistic people and those with speech disabilities.

🎯 WHY CHOOSE OPENVOICE?

✓ Completely Free - No subscriptions, no in-app purchases, no hidden costs
✓ Open Source - Transparent, auditable code (GPL v3.0)
✓ Privacy First - All processing happens on your device, zero data collection
✓ Professional Quality - Features that rival $15,000 AAC devices
✓ No Gatekeeping - No prescription needed, download and use immediately

🌟 KEY FEATURES

COMMUNICATION SYMBOLS
• 70+ professionally designed symbols across 11 categories
• Create unlimited custom symbols using your camera or photo library
• Search and browse symbols by category
• Favorite frequently used symbols for quick access

EYE TRACKING (Hands-Free)
• Revolutionary ARKit-powered eye tracking
• 9-point calibration for accuracy
• Dwell-time selection
• Perfect for users with limited mobility

INTELLIGENT PREDICTIONS
• AI-powered symbol suggestions
• Learn from your communication patterns
• Context-aware predictions
• Faster communication over time

NATURAL TEXT-TO-SPEECH
• High-quality voice synthesis
• Choose from all iOS system voices
• Customize speed, pitch, and volume
• Sounds natural and clear

QUICK PHRASES
• Save frequently used phrases
• One-tap communication
• 24 built-in common phrases
• Create unlimited custom phrases

SPEECH HISTORY
• Review your last 100 phrases
• Replay any previous phrase instantly
• Search through history
• Export to text file

PRONUNCIATION DICTIONARY
• Fix pronunciations of names, acronyms, technical terms
• Test before saving
• Automatic application
• Unlimited entries

CUSTOMIZATION
• Adjust grid layout (2-6 columns)
• High contrast mode for visibility
• Haptic feedback
• Adjustable text sizes
• Dark mode support

🔒 PRIVACY & SECURITY

OpenVoice respects your privacy:
• Zero data collection
• No analytics or tracking
• No cloud syncing without your permission
• All processing happens on your device
• Open source code - verify yourself

👥 PERFECT FOR

• Non-verbal autistic individuals
• People with apraxia or dysarthria
• Stroke survivors with speech impairment
• ALS/MND patients
• Cerebral palsy
• Temporary speech loss
• Anyone needing alternative communication

📱 TECHNICAL DETAILS

• Requires iOS 15.0 or later
• Works on iPhone, iPad, iPod Touch
• Eye tracking requires Face ID device (iPhone X+, iPad Pro 2018+)
• Works completely offline
• Small app size
• Low battery impact
• No subscription required

💡 ACCESSIBILITY

OpenVoice is built with accessibility in mind:
• VoiceOver compatible
• Switch Control support
• Voice Control compatible
• Adjustable text sizes
• High contrast mode
• Reduced motion support

🤝 OPEN SOURCE & COMMUNITY

OpenVoice is open source software:
• Licensed under GPL v3.0
• Code available on GitHub
• Community contributions welcome
• Transparent development
• No proprietary lock-in

🌍 OUR MISSION

Traditional AAC devices cost $5,000-$15,000 and require prescriptions. This creates barriers for people who need communication tools.

OpenVoice removes these barriers. Everyone deserves a voice.

We built OpenVoice to be:
• FREE for everyone, forever
• POWERFUL with professional features
• PRIVATE with no data collection
• ACCESSIBLE to all who need it

📞 SUPPORT

Need help? We're here for you:
• Email: support@openvoice.app
• Documentation: openvoice.app/guide
• GitHub: github.com/openvoice/openvoice
• Report bugs: github.com/openvoice/openvoice/issues

⭐ REVIEWS HELP

If OpenVoice helps you communicate, please leave a review! Your feedback helps others discover OpenVoice.

💙 Join thousands of people using OpenVoice to communicate every day.

Download now and start speaking freely!

---

Made with ❤️ for the AAC community
OpenVoice is free software (GPL v3.0)
No data collection · No tracking · No ads · No subscriptions
```

**Character count**: ~3,850 (within 4,000 limit)

---

## 🏷️ Keywords

### Keyword String
```
AAC,communication,speech,autism,nonverbal,assistive,accessibility,eye tracking,symbols,alternative communication
```
*(100 character limit - 98 characters used)*

### Individual Keywords
1. AAC
2. communication
3. speech
4. autism
5. nonverbal
6. assistive
7. accessibility
8. eye tracking
9. symbols
10. alternative communication

---

## 📂 Categories

### Primary Category
```
Medical
```

### Secondary Category
```
Education
```

**Why Medical?**
- AAC is medical assistive technology
- Used by speech therapists
- Healthcare context
- Better discoverability for AAC users

**Why Education?**
- Used in schools
- Special education
- Learning tool
- Speech therapy

---

## 👥 Age Rating

### Rating: **4+**

**Content**:
- No objectionable content
- Safe for all ages
- Educational purpose
- No ads or tracking

**Questionnaire Answers**:
- Cartoon or Fantasy Violence: None
- Realistic Violence: None
- Sexual Content or Nudity: None
- Profanity or Crude Humor: None
- Alcohol, Tobacco, or Drug Use: None
- Mature/Suggestive Themes: None
- Horror/Fear Themes: None
- Gambling: None
- Contests: None
- Unrestricted Web Access: None
- User Generated Content: None

---

## 🌐 Support & Privacy URLs

### Support URL
```
https://openvoice.app/support
```
*(Required - must be publicly accessible)*

### Marketing URL (Optional)
```
https://openvoice.app
```

### Privacy Policy URL
```
https://openvoice.app/privacy
```
*(Required)*

---

## 📧 Contact Information

### Email Address
```
support@openvoice.app
```
*(Required for App Store Connect)*

### Phone Number (Optional)
```
[Your phone number if you want to provide one]
```

---

## 💰 Pricing & Availability

### Price
```
Free
```

### In-App Purchases
```
None
```

### Subscriptions
```
None
```

### Availability
```
All countries and regions
```
*(Or select specific countries if needed)*

---

## 🔐 Export Compliance

### Does your app use encryption?
```
No
```

**Explanation**: 
- OpenVoice does not use encryption beyond standard HTTPS
- No custom cryptographic implementations
- Standard iOS security features only

---

## 📸 Screenshots Required

### iPhone 6.7" (Pro Max)
- **Required**: 3-10 screenshots
- **Size**: 1290 x 2796 pixels
- **Devices**: iPhone 14 Pro Max, 15 Pro Max

### iPhone 6.5" (Max/Plus)
- **Required**: 3-10 screenshots  
- **Size**: 1284 x 2778 pixels
- **Devices**: iPhone 11 Pro Max, 12 Pro Max, 13 Pro Max

### iPhone 5.5" (Plus)
- **Optional but recommended**: 3-10 screenshots
- **Size**: 1242 x 2208 pixels
- **Devices**: iPhone 6s Plus, 7 Plus, 8 Plus

### iPad Pro 12.9" (6th gen)
- **Required**: 3-10 screenshots
- **Size**: 2048 x 2732 pixels

### iPad Pro 12.9" (2nd gen)
- **Optional but recommended**: 3-10 screenshots
- **Size**: 2048 x 2732 pixels

---

## 📱 Screenshot Content Ideas

### Screenshot 1: Main Symbol Grid
**Caption**: "Communicate with 70+ clear symbols"
- Show symbol grid in use
- Highlight phrase bar at top
- Clean, inviting interface

### Screenshot 2: Eye Tracking
**Caption**: "Hands-free with eye tracking"
- Show gaze indicator overlay
- Demonstrate hands-free selection
- Highlight accessibility

### Screenshot 3: Custom Symbols
**Caption**: "Create unlimited custom symbols"
- Show photo import or camera
- Custom symbol in grid
- Personalization options

### Screenshot 4: Quick Phrases
**Caption**: "Save frequently used phrases"
- Show quick phrases list
- Categories
- One-tap communication

### Screenshot 5: AI Predictions
**Caption**: "Smart suggestions learn from you"
- Show prediction bar
- Highlighted suggestions
- Intelligent features

### Screenshot 6: Voice Options
**Caption**: "Customize your voice"
- Settings screen
- Voice picker
- Customization options

### Screenshot 7: Speech History
**Caption**: "Review and replay past phrases"
- History view
- Search functionality
- Easy access to past communication

---

## 🎬 App Preview Video (Optional but Recommended)

### Length
```
15-30 seconds
```

### Content Ideas
1. **Opening** (3s): App icon + "OpenVoice"
2. **Feature 1** (5s): Tap symbols to build phrase
3. **Feature 2** (5s): Tap speak button, hear speech
4. **Feature 3** (5s): Create custom symbol with camera
5. **Feature 4** (5s): Eye tracking demonstration
6. **Feature 5** (4s): Quick phrases
7. **Closing** (3s): "Free forever" + App Store badge

### Video Specs
- Portrait orientation
- Same resolutions as screenshots
- 30 fps
- H.264 encoding
- .mov or .m4v format

---

## 📋 App Store Connect Checklist

Before submission:

- [ ] App name decided and checked for availability
- [ ] Subtitle written (30 chars)
- [ ] Description written and proofread (4,000 chars max)
- [ ] Keywords researched and optimized (100 chars)
- [ ] Categories selected (Primary + Secondary)
- [ ] Age rating completed (4+)
- [ ] Screenshots captured for all required sizes
- [ ] App icon ready (1024x1024)
- [ ] Support website live and accessible
- [ ] Privacy policy posted and accessible
- [ ] Support email set up and monitored
- [ ] App build uploaded and processed
- [ ] App Review information provided
- [ ] Export compliance completed

---

## 💡 Tips for Approval

### Do's ✅
- Be honest in description
- Show actual app functionality in screenshots
- Explain all permissions clearly
- Provide working support contact
- Test thoroughly before submission
- Respond quickly to App Review questions

### Don'ts ❌
- Don't use misleading screenshots
- Don't promise features that don't exist
- Don't copy other apps' descriptions
- Don't use fake reviews or ratings
- Don't violate any guidelines
- Don't rush submission without testing

---

## 🎯 Keywords Strategy

### High-Value Keywords (Include)
- AAC (primary search term)
- autism
- nonverbal
- speech
- communication

### Long-Tail Keywords (Good for discovery)
- alternative communication
- eye tracking
- assistive technology

### Avoid
- Generic terms (app, free, best)
- Competitor names
- Irrelevant terms
- Repeated keywords

---

## 📊 Localization (Future)

Start with English, expand later:

**Priority languages**:
1. Spanish (es)
2. French (fr)
3. German (de)
4. Portuguese (pt)
5. Chinese Simplified (zh-Hans)

For each language, translate:
- App name
- Subtitle
- Description
- Keywords
- Screenshots (text overlays)
- In-app content

---

## 🚀 Launch Strategy

### Pre-Launch
- Set up TestFlight
- Recruit beta testers
- Collect feedback
- Fix bugs

### Launch Day
- Submit for review
- Prepare marketing materials
- Write blog post
- Draft social media posts

### Post-Launch
- Monitor reviews
- Respond to feedback
- Track analytics
- Plan updates

---

**This template is ready to use! Just customize the URLs, email, and other placeholders.** 📱✨
