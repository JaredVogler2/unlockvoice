# 🔧 PHASE 4 INTEGRATION GUIDE

## Step-by-Step Integration of Eye Tracking

This guide walks you through integrating Phase 4 eye tracking into your existing OpenVoice project.

---

## 📋 Prerequisites

Before starting:
- [ ] Phases 1-3 are fully integrated and working
- [ ] You have Xcode 15.0 or later
- [ ] Physical device with TrueDepth camera (iPhone X+) for testing
- [ ] Latest iOS SDK installed

---

## 🚀 Integration Steps

### Step 1: Add New Files

Copy all new Phase 4 files to your Xcode project:

```
# Core Eye Tracking
Core/EyeTracking/
├── EyeTrackingManager.swift
├── GazeCalculator.swift
└── DwellTimeDetector.swift

# Calibration
Core/Calibration/
└── CalibrationEngine.swift

# UI Components
Views/EyeTracking/
├── GazeIndicatorView.swift
├── EyeTrackingSettingsView.swift
└── EyeTrackingTestView.swift
```

**In Xcode:**
1. Right-click on your project navigator
2. Select "Add Files to OpenVoice..."
3. Select the Core and Views/EyeTracking folders
4. Ensure "Copy items if needed" is checked
5. Click "Add"

---

### Step 2: Update AppSettings.swift

The AppSettings model needs to include eye tracking settings.

**File**: `Models/AppSettings.swift`

Add this property after the accessibility settings:
```swift
// MARK: - Eye Tracking Settings (Phase 4)
var eyeTracking: EyeTrackingSettings = EyeTrackingSettings()
```

Add this struct at the end of the file:
```swift
// MARK: - Eye Tracking Settings (Phase 4)

struct EyeTrackingSettings: Codable {
    var enabled: Bool = false
    var dwellTime: TimeInterval = 1.0
    var movementTolerance: CGFloat = 30
    var smoothingFrames: Int = 3
    var dwellPreset: String = "normal"
    
    // Feedback
    var visualFeedback: Bool = true
    var hapticFeedback: Bool = true
    var soundFeedback: Bool = false
    
    // UI
    var showGazeCursor: Bool = true
    var showTrackingQuality: Bool = true
    
    // Advanced
    var requireStableGaze: Bool = true
    var debugMode: Bool = false
}
```

---

### Step 3: Update Info.plist

Add camera usage description for ARKit:

1. Open `Info.plist`
2. Add new row: **Privacy - Camera Usage Description**
3. Value: "OpenVoice uses the camera for eye tracking to enable hands-free communication."

Raw XML format:
```xml
<key>NSCameraUsageDescription</key>
<string>OpenVoice uses the camera for eye tracking to enable hands-free communication.</string>
```

---

### Step 4: Add ARKit Framework

1. Select your project in Xcode
2. Select your target
3. Go to "Frameworks, Libraries, and Embedded Content"
4. Click "+" button
5. Search for "ARKit.framework"
6. Add it

---

### Step 5: Update SettingsView.swift

Add navigation link to eye tracking settings in your SettingsView.

**File**: `Views/SettingsView.swift`

Add this section in the List:
```swift
Section {
    NavigationLink {
        EyeTrackingSettingsView()
            .environmentObject(appSettings)
    } label: {
        Label("Eye Tracking", systemImage: "eye.circle")
    }
} header: {
    Text("Accessibility")
} footer: {
    Text("Configure hands-free eye tracking (iPhone X or newer required)")
}
```

---

### Step 6: Integrate Gaze Indicator in Main View

Add the gaze indicator overlay to your main communication view.

**File**: `Views/SymbolGridView.swift` or `ContentView.swift`

Wrap your main view in a ZStack and add the indicator:
```swift
ZStack {
    // Your existing symbol grid
    ScrollView {
        // ... symbol grid content
    }
    
    // Eye tracking overlay
    if appSettings.eyeTracking.enabled && appSettings.eyeTracking.showGazeCursor {
        GazeIndicatorView(eyeTracking: EyeTrackingManager.shared)
    }
}
```

---

### Step 7: Handle Dwell Selections

Add dwell-time symbol selection to your SymbolGridViewModel.

**File**: `ViewModels/SymbolGridViewModel.swift`

Add this method:
```swift
func setupEyeTracking() {
    guard appSettings.eyeTracking.enabled else { return }
    
    EyeTrackingManager.shared.onDwellComplete = { [weak self] gazePoint in
        self?.handleGazeSelection(at: gazePoint)
    }
}

private func handleGazeSelection(at point: CGPoint) {
    // Find which symbol is at this point
    // This depends on your grid layout
    // Example:
    if let symbol = findSymbol(at: point) {
        selectSymbol(symbol)
    }
}
```

Call `setupEyeTracking()` in your view's `onAppear`.

---

### Step 8: Start Eye Tracking Session

Initialize eye tracking when the app launches or when enabled.

**File**: `ContentView.swift` or main view

```swift
.onAppear {
    if appSettings.eyeTracking.enabled {
        startEyeTracking()
    }
}

private func startEyeTracking() {
    let sceneView = ARSCNView()
    // Add sceneView to your view hierarchy (can be hidden)
    
    EyeTrackingManager.shared.startTracking(with: sceneView)
}
```

---

### Step 9: Update CalibrationView (Optional)

If you want to use the enhanced CalibrationView from Phase 4, replace the existing placeholder.

**Option A**: Replace entirely
1. Delete existing `Views/CalibrationView.swift`
2. Add new CalibrationView from Phase 4

**Option B**: Keep both versions
1. Rename old to `CalibrationView_Legacy.swift`
2. Add new CalibrationView

---

### Step 10: Build and Test

1. **Build the Project**
   ```bash
   Command + B
   ```
   Fix any compilation errors

2. **Deploy to Physical Device**
   - Eye tracking ONLY works on real devices
   - Simulator does not support ARKit face tracking
   - Connect iPhone X or newer
   - Select device in Xcode
   - Run (Command + R)

3. **Grant Permissions**
   - App will request camera access
   - Tap "Allow"

4. **Test Eye Tracking**
   - Open Settings → Eye Tracking
   - Tap "Calibrate Eye Tracking"
   - Complete 9-point calibration
   - Enable eye tracking
   - Test on symbol grid!

---

## 🧪 Testing Checklist

After integration, verify these features:

### Basic Functionality
- [ ] App builds without errors
- [ ] Camera permission requested
- [ ] Eye tracking can be enabled in settings
- [ ] Gaze cursor appears when enabled
- [ ] Cursor follows eye movement

### Calibration
- [ ] Calibration view opens
- [ ] 9 calibration points appear
- [ ] Can complete calibration
- [ ] Calibration saves/persists
- [ ] Can recalibrate

### Selection
- [ ] Dwell on symbol starts progress ring
- [ ] Holding gaze selects symbol
- [ ] Moving gaze cancels selection
- [ ] Selected symbol added to phrase
- [ ] Haptic feedback works (if enabled)

### Settings
- [ ] All settings accessible
- [ ] Dwell time adjustment works
- [ ] Movement tolerance affects sensitivity
- [ ] Presets apply correctly
- [ ] Settings persist between launches

### Performance
- [ ] Smooth gaze cursor movement (60 FPS)
- [ ] No significant lag
- [ ] No memory warnings
- [ ] Battery usage reasonable
- [ ] App remains responsive

---

## 🐛 Common Integration Issues

### Issue: "Use of undeclared type 'ARSCNView'"
**Solution**: 
- Ensure ARKit framework is added
- Import ARKit at top of file: `import ARKit`

### Issue: "Camera access denied"
**Solution**:
- Check Info.plist has camera usage description
- Go to Settings → Privacy → Camera → OpenVoice → Enable

### Issue: "Face tracking not supported"
**Solution**:
- Only works on devices with TrueDepth camera
- iPhone X or newer required
- iPad Pro 11" (2018+) or 12.9" (3rd gen+)
- Not available on older devices or simulator

### Issue: Gaze cursor not appearing
**Solution**:
- Ensure eye tracking is enabled in settings
- Check `showGazeCursor` is true
- Verify `GazeIndicatorView` is in view hierarchy
- Face must be detected (check tracking quality)

### Issue: Poor tracking accuracy
**Solution**:
- Run calibration
- Improve lighting
- Position face 30-60cm from device
- Keep head relatively still
- Ensure eyes are visible (no sunglasses)

### Issue: Compilation error in AppSettings
**Solution**:
- Ensure `EyeTrackingSettings` struct is defined
- Check all properties have default values
- Verify struct conforms to `Codable`

---

## 📱 Device Testing Strategy

### Minimum Testing
1. **One Modern Device** (iPhone 12+)
   - Best performance
   - Latest features

### Recommended Testing
1. **Oldest Supported** (iPhone X)
   - Verify minimum performance
   - Check edge cases

2. **Latest Model** (iPhone 15)
   - Optimal experience
   - Future compatibility

3. **iPad Pro** (with Face ID)
   - Larger screen
   - Different aspect ratio

### Test Conditions
- **Good Lighting**: Bright, even light
- **Poor Lighting**: Dim, mixed light
- **Moving**: User in motion
- **Stationary**: User sitting still
- **Different Distances**: 20cm to 80cm
- **Different Angles**: Straight on, tilted
- **With/Without Glasses**: If user wears them

---

## 🔄 Update Workflow

If Phase 4 files are updated:

1. **Pull latest changes**
2. **Replace updated files** in your project
3. **Clean build folder** (Command + Shift + K)
4. **Build and test** on device
5. **Recalibrate** eye tracking if needed

---

## 📊 Performance Optimization Tips

### For Smooth 60 FPS:
1. Use release builds for testing (not debug)
2. Close background apps
3. Ensure device isn't overheating
4. Reduce smoothing if latency noticed
5. Disable debug mode in production

### For Better Accuracy:
1. Complete full 9-point calibration
2. Calibrate in position you'll use
3. Recalibrate if you move significantly
4. Keep face centered and at consistent distance
5. Use "Accessible" preset if needed

---

## 🎓 Next Steps After Integration

1. **Test Thoroughly**
   - Try all features
   - Test edge cases
   - Get user feedback

2. **Customize Settings**
   - Adjust default dwell time
   - Set appropriate tolerance
   - Configure feedback options

3. **Train Users**
   - Show calibration process
   - Explain dwell selection
   - Demonstrate settings

4. **Monitor Performance**
   - Track calibration quality
   - Monitor accuracy metrics
   - Collect user feedback

5. **Iterate**
   - Adjust based on feedback
   - Fine-tune parameters
   - Add improvements

---

## ✅ Integration Complete!

Once all steps are done:
- ✅ Phase 4 fully integrated
- ✅ Eye tracking operational
- ✅ Calibration working
- ✅ Settings configured
- ✅ Tested on device

**You now have hands-free communication in OpenVoice!** 🎉👁️

---

## 📞 Need Help?

If you encounter issues:
1. Check this integration guide
2. Review PHASE_4_COMPLETE.md
3. Check code comments in files
4. Verify device compatibility
5. Test on different device
6. Check Apple's ARKit documentation

---

**Happy integrating!** 🚀

*Every person deserves a voice - now hands-free!*
