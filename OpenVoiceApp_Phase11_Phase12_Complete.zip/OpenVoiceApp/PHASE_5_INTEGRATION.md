# 🔧 PHASE 5 INTEGRATION GUIDE

## Quick Integration Steps

This guide will help you integrate Phase 5 (Data Persistence) into your existing OpenVoice project.

---

## ⚡ Quick Start (30 Minutes)

### Step 1: Add Core Data Model (10 min)

1. **In Xcode**: File → New → File → Data Model
2. **Name it**: `OpenVoiceDataModel.xcdatamodeld`
3. **Create 4 entities** (follow CoreDataModel_Setup.swift for details):
   - ConversationEntity
   - SymbolUsageEntity
   - CustomSymbolEntity
   - SessionEntity

### Step 2: Copy Files (5 min)

Copy these folders to your project:
- `Models/CoreData/` → All Core Data entity files
- `Services/Persistence/` → All persistence service files
- `Views/Analytics/` → Analytics dashboard

### Step 3: Initialize Core Data (5 min)

**In `OpenVoiceApp.swift`:**

```swift
import SwiftUI

@main
struct OpenVoiceApp: App {
    // ADD THIS:
    let persistence = PersistenceService.shared
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                // ADD THIS:
                .environment(\.managedObjectContext, persistence.viewContext)
        }
    }
}
```

### Step 4: Integrate with Symbol Grid (10 min)

**In `SymbolGridViewModel.swift`:**

Add at top of class:
```swift
private let conversationHistory = ConversationHistoryService.shared
private let analytics = AnalyticsService.shared
```

In your `speak()` or `speakPhrase()` method, add:
```swift
func speakPhrase() {
    let text = currentPhrase.text
    let symbolIds = currentPhrase.symbols.map { $0.id }
    
    // Your existing speech code
    speechService.speak(text)
    
    // ADD THIS: Save conversation
    conversationHistory.saveConversationAsync(
        text: text,
        symbols: symbolIds
    )
    
    // ADD THIS: Track usage
    for symbol in currentPhrase.symbols {
        analytics.recordSymbolUsage(
            symbolId: symbol.id,
            label: symbol.label,
            category: symbol.category
        )
    }
}
```

### Step 5: Add Analytics to Navigation

**In `ContentView.swift` or `SettingsView.swift`:**

```swift
NavigationLink {
    AnalyticsDashboardView()
} label: {
    Label("Analytics", systemImage: "chart.bar")
}
```

### Step 6: Test

1. Build and run
2. Speak a few phrases
3. Close and reopen app
4. Check if phrases are still in history
5. Open Analytics Dashboard
6. Verify data is showing

**Done! Data persistence is now active!** ✅

---

## 📋 Detailed Integration Steps

### A. Core Data Model Setup

#### Create the .xcdatamodeld File

1. In Xcode: File → New → File
2. Search for "Data Model"
3. Click "Data Model" template
4. Name: `OpenVoiceDataModel`
5. Save to project root

#### Add Entities

Reference `Models/CoreData/CoreDataModel_Setup.swift` for complete entity definitions.

**ConversationEntity**:
- Attributes: id (UUID), text (String), symbolIds (Transformable), timestamp (Date), duration (Double)
- Relationships: session (To-One → SessionEntity)

**SymbolUsageEntity**:
- Attributes: id (UUID), symbolId (String), label (String), category (String), usageCount (Integer 64), firstUsed (Date), lastUsed (Date)
- Relationships: session (To-One → SessionEntity), customSymbol (To-One → CustomSymbolEntity)

**CustomSymbolEntity**:
- Attributes: id (UUID), label (String), imageData (Binary Data), category (String), tags (Transformable), createdAt (Date), lastModified (Date), usageCount (Integer 64), isFavorite (Boolean)
- Relationships: usages (To-Many → SymbolUsageEntity)

**SessionEntity**:
- Attributes: id (UUID), startTime (Date), endTime (Date), phraseCount (Integer 64), symbolCount (Integer 64)
- Relationships: conversations (To-Many → ConversationEntity), symbolUsages (To-Many → SymbolUsageEntity)

#### Set Indexes

For performance, add indexes on:
- ConversationEntity.timestamp
- SymbolUsageEntity.symbolId
- SymbolUsageEntity.lastUsed
- CustomSymbolEntity.createdAt
- SessionEntity.startTime

### B. Service Integration

#### 1. Conversation Saving

**Location**: Wherever you call speech service

```swift
// When user speaks a phrase
let text = buildPhraseText()
let symbolIds = getSymbolIds()

// Existing: Speak the text
speechService.speak(text)

// NEW: Save to history
ConversationHistoryService.shared.saveConversationAsync(
    text: text,
    symbols: symbolIds
)
```

#### 2. Symbol Usage Tracking

**Location**: Symbol selection handler

```swift
func symbolTapped(_ symbol: Symbol) {
    // Existing: Add to phrase
    currentPhrase.symbols.append(symbol)
    
    // NEW: Track usage
    AnalyticsService.shared.recordSymbolUsage(
        symbolId: symbol.id,
        label: symbol.label,
        category: symbol.category
    )
}
```

#### 3. Custom Symbol Persistence

**Location**: Custom symbol creation

```swift
func saveCustomSymbol(label: String, image: UIImage) {
    guard let imageData = image.jpegData(compressionQuality: 0.8) else { return }
    
    let context = PersistenceService.shared.viewContext
    
    // NEW: Save to Core Data
    let entity = CustomSymbolEntity.create(
        in: context,
        label: label,
        imageData: imageData,
        category: selectedCategory
    )
    
    PersistenceService.shared.save()
    
    // Create app Symbol from entity
    let symbol = Symbol(
        id: entity.id?.uuidString ?? UUID().uuidString,
        label: label,
        imageName: nil,
        imageData: imageData,
        category: selectedCategory
    )
    
    // Add to your symbol array
    customSymbols.append(symbol)
}
```

#### 4. Loading Custom Symbols on App Start

**Location**: App initialization or ViewModel init

```swift
func loadCustomSymbols() {
    let context = PersistenceService.shared.viewContext
    let entities = CustomSymbolEntity.fetchAll(in: context)
    
    customSymbols = entities.compactMap { entity in
        guard let id = entity.id,
              let label = entity.label,
              let imageData = entity.imageData else {
            return nil
        }
        
        return Symbol(
            id: id.uuidString,
            label: label,
            imageName: nil,
            imageData: imageData,
            category: entity.category
        )
    }
}
```

### C. UI Integration

#### 1. Add Analytics to Settings

**In `SettingsView.swift`:**

```swift
Section("Data & Analytics") {
    NavigationLink {
        AnalyticsDashboardView()
    } label: {
        HStack {
            Image(systemName: "chart.bar")
                .foregroundColor(.blue)
            Text("Usage Analytics")
        }
    }
    
    NavigationLink {
        BackupManagementView()
    } label: {
        HStack {
            Image(systemName: "arrow.up.doc")
                .foregroundColor(.green)
            Text("Backup & Export")
        }
    }
}
```

#### 2. Enhanced History View

Replace your existing `SpeechHistoryView` with enhanced version:

```swift
// Use ConversationHistoryService instead of local array
@StateObject private var historyService = ConversationHistoryService.shared

var body: some View {
    List {
        ForEach(historyService.recentConversations) { conversation in
            VStack(alignment: .leading) {
                Text(conversation.text ?? "")
                    .font(.body)
                
                HStack {
                    Text(conversation.timeAgo)
                    Text("•")
                    Text("\(conversation.symbolCount) symbols")
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
        }
        .onDelete { indexSet in
            let toDelete = indexSet.map { historyService.recentConversations[$0] }
            historyService.deleteConversations(toDelete)
        }
    }
    .onAppear {
        historyService.loadRecentConversations()
    }
}
```

### D. Backup Management UI (Simple Version)

Create a simple backup view:

```swift
struct BackupManagementView: View {
    @StateObject private var backup = BackupService.shared
    @State private var showingShareSheet = false
    @State private var backupURL: URL?
    
    var body: some View {
        List {
            Section("Backup") {
                Button {
                    createBackup()
                } label: {
                    HStack {
                        Image(systemName: "arrow.up.doc")
                        Text("Create Backup")
                    }
                }
                
                if let date = backup.lastBackupDate {
                    Text("Last backup: \(date, style: .relative)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Section("Export") {
                Button {
                    exportCSV()
                } label: {
                    HStack {
                        Image(systemName: "doc.text")
                        Text("Export to CSV")
                    }
                }
                
                Button {
                    exportJSON()
                } label: {
                    HStack {
                        Image(systemName: "doc.badge.gearshape")
                        Text("Export to JSON")
                    }
                }
            }
        }
        .navigationTitle("Backup & Export")
        .sheet(isPresented: $showingShareSheet) {
            if let url = backupURL {
                ShareSheet(items: [url])
            }
        }
    }
    
    private func createBackup() {
        backup.createFullBackup { result in
            switch result {
            case .success(let url):
                backupURL = url
                showingShareSheet = true
            case .failure(let error):
                print("Backup error: \(error)")
            }
        }
    }
    
    private func exportCSV() {
        if let url = backup.exportToCSV() {
            backupURL = url
            showingShareSheet = true
        }
    }
    
    private func exportJSON() {
        if let url = backup.exportConversationsJSON() {
            backupURL = url
            showingShareSheet = true
        }
    }
}

// Share sheet helper
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
```

---

## 🧪 Testing Your Integration

### Test 1: Conversation Persistence
1. Speak 3-5 phrases
2. Close app completely
3. Reopen app
4. Check if phrases are in history
5. **Expected**: All phrases persist

### Test 2: Symbol Usage Tracking
1. Use same symbol multiple times
2. Open Analytics Dashboard
3. Check "Most Used Symbols"
4. **Expected**: Symbol appears with correct count

### Test 3: Custom Symbol Persistence
1. Create a custom symbol with photo
2. Close and reopen app
3. Check if custom symbol still exists
4. **Expected**: Symbol and image persist

### Test 4: Backup & Restore
1. Create some data (phrases, symbols)
2. Create backup
3. Clear all data (optional test)
4. Restore from backup
5. **Expected**: All data restored correctly

### Test 5: Analytics Accuracy
1. Use app for several "sessions"
2. Open Analytics Dashboard
3. Check statistics match expectations
4. **Expected**: Accurate counts and trends

---

## 🐛 Common Issues & Solutions

### Issue 1: Core Data Model Not Found

**Error**: "Could not find model named OpenVoiceDataModel"

**Solution**:
1. Check file name is exactly `OpenVoiceDataModel.xcdatamodeld`
2. Verify file is in project target
3. Clean build folder (Cmd+Shift+K)
4. Rebuild project

### Issue 2: Conversations Not Saving

**Symptoms**: History is empty after restart

**Debug**:
```swift
// Add to your speak method
print("💾 Saving conversation: \(text)")
ConversationHistoryService.shared.saveConversation(text: text, symbols: symbolIds)

// Check database
PersistenceService.shared.printDatabaseContents()
```

**Common Causes**:
- Core Data not initialized
- Wrong context being used
- Save not being called
- Context not being passed to environment

### Issue 3: Analytics Not Updating

**Symptoms**: Dashboard shows no data

**Debug**:
```swift
// Force reload
AnalyticsService.shared.loadAnalytics()

// Check data exists
let stats = AnalyticsService.shared.getUsageStatistics()
print("Total usages: \(stats.totalSymbolUsages)")
```

**Common Causes**:
- Data not being tracked (missing recordSymbolUsage calls)
- Published properties not updating UI
- Wrong thread for UI updates

### Issue 4: App Crashes on Launch

**Error**: Core Data related crash

**Solution**:
1. Check all entity names match code
2. Verify all attributes defined
3. Check relationship names and types
4. Delete app and reinstall for clean database
5. Check migration code if model changed

### Issue 5: Backup Export Fails

**Error**: File write error

**Solution**:
1. Check documents directory access
2. Verify sufficient storage space
3. Test with smaller dataset
4. Check file permissions

---

## 📊 Verification Checklist

After integration, verify:

- [ ] App builds without errors
- [ ] App launches successfully
- [ ] Can speak phrases
- [ ] Phrases persist after restart
- [ ] Analytics Dashboard opens
- [ ] Analytics show data
- [ ] Can create backup
- [ ] Can export CSV
- [ ] Can export JSON
- [ ] Custom symbols persist
- [ ] Symbol usage tracked correctly
- [ ] No memory leaks
- [ ] No crashes during normal use

---

## 💡 Pro Tips

### 1. Gradual Integration

Don't integrate everything at once:
1. First: Just Core Data model and PersistenceService
2. Then: Conversation saving
3. Then: Analytics
4. Finally: Backup system

### 2. Use Background Contexts

For better performance:
```swift
// Use async saving for non-critical data
conversationHistory.saveConversationAsync(text: text, symbols: symbols)

// Use sync saving only when user needs immediate feedback
let conversation = conversationHistory.saveConversation(text: text, symbols: symbols)
```

### 3. Batch Operations

For bulk operations:
```swift
// Bad: Multiple saves
for symbol in symbols {
    analytics.recordSymbolUsage(...)
}

// Good: Batch operation
analytics.recordSymbolUsages(symbols)
```

### 4. Monitor Database Size

Add to settings:
```swift
let stats = PersistenceService.shared.getDatabaseStats()
Text("Database: \(stats.databaseSize / 1024 / 1024) MB")
```

### 5. Implement Data Cleanup

Give users control:
```swift
Button("Clear Old Data") {
    let oneMonthAgo = Calendar.current.date(byAdding: .month, value: -1, to: Date())!
    conversationHistory.deleteConversationsOlderThan(date: oneMonthAgo)
}
```

---

## 🚀 Next Steps

Once Phase 5 is integrated:

1. **Test thoroughly** with real usage
2. **Monitor performance** (check console for slow queries)
3. **Gather user feedback** on analytics
4. **Plan Phase 6** (CoreML integration will use this data!)

---

## 📞 Need Help?

If you run into issues:

1. Check console for error messages
2. Use `PersistenceService.shared.printDatabaseContents()` to verify data
3. Test each component individually
4. Review the example code in Phase 5 files
5. Ensure Core Data model matches entity definitions

---

**Good luck with integration! You're adding enterprise-grade data persistence to OpenVoice!** 💪

---

*Last Updated: Phase 5 Complete*  
*Questions? Review PHASE_5_COMPLETE.md for more details*
