//
//  SymbolGridViewModel.swift
//  OpenVoice
//
//  ViewModel for symbol grid - handles symbol selection and filtering
//

import Foundation
import Combine

class SymbolGridViewModel: ObservableObject {
    @Published var visibleSymbols: [Symbol] = []
    @Published var selectedCategory: SymbolCategory?
    @Published var showFavoritesOnly: Bool = false
    @Published var showRecentsOnly: Bool = false
    
    private var cancellables = Set<AnyCancellable>()
    private let library = SymbolLibraryService.shared
    
    init() {
        setupBindings()
    }
    
    private func setupBindings() {
        // Update visible symbols when category changes
        $selectedCategory
            .sink { [weak self] _ in
                self?.updateVisibleSymbols()
            }
            .store(in: &cancellables)
        
        // Listen to library changes
        library.$allSymbols
            .sink { [weak self] _ in
                self?.updateVisibleSymbols()
            }
            .store(in: &cancellables)
        
        // Listen to favorites changes
        $showFavoritesOnly
            .sink { [weak self] _ in
                self?.updateVisibleSymbols()
            }
            .store(in: &cancellables)
        
        // Listen to recents changes
        $showRecentsOnly
            .sink { [weak self] _ in
                self?.updateVisibleSymbols()
            }
            .store(in: &cancellables)
    }
    
    func loadSymbols() {
        // Library auto-loads on init
        updateVisibleSymbols()
    }
    
    func selectSymbol(_ symbol: Symbol) {
        // Add to current phrase
        PhraseManager.shared.addSymbol(symbol)
        
        // Track usage in library
        library.markAsUsed(symbol)
        
        // Haptic feedback
        HapticManager.shared.impact(.light)
    }
    
    private func updateVisibleSymbols() {
        var symbols: [Symbol]
        
        if showFavoritesOnly {
            symbols = library.favoriteSymbols
        } else if showRecentsOnly {
            symbols = library.recentSymbols
        } else if let category = selectedCategory {
            symbols = library.getSymbols(in: category)
        } else {
            // Show most frequently used symbols on main grid
            symbols = library.allSymbols.sorted { $0.frequency > $1.frequency }
            // Limit to top 24 for main grid
            symbols = Array(symbols.prefix(24))
        }
        
        visibleSymbols = symbols
    }
    
    func toggleFavoritesView() {
        showFavoritesOnly.toggle()
        if showFavoritesOnly {
            showRecentsOnly = false
        }
    }
    
    func toggleRecentsView() {
        showRecentsOnly.toggle()
        if showRecentsOnly {
            showFavoritesOnly = false
        }
    }
}

// MARK: - Phrase Manager

class PhraseManager: ObservableObject {
    static let shared = PhraseManager()
    
    @Published var currentPhrase = Phrase()
    @Published var phraseHistory: [Phrase] = []
    
    private init() {
        loadHistory()
    }
    
    func addSymbol(_ symbol: Symbol) {
        currentPhrase.add(symbol)
    }
    
    func removeLastSymbol() {
        currentPhrase.removeLast()
    }
    
    func clearPhrase() {
        currentPhrase.clear()
    }
    
    func speakPhrase() {
        guard !currentPhrase.isEmpty else { return }
        
        // Speak using SpeechService (Phase 3)
        SpeechService.shared.speak(currentPhrase.formattedText)
        
        // Mark as spoken and save to history
        currentPhrase.wasSpoken = true
        saveToHistory()
        
        // Clear current phrase
        currentPhrase = Phrase()
    }
    
    private func saveToHistory() {
        phraseHistory.insert(currentPhrase, at: 0)
        
        // Keep only last 100 phrases
        if phraseHistory.count > 100 {
            phraseHistory = Array(phraseHistory.prefix(100))
        }
        
        // Phase 5: Persist to database
        saveToDisk()
    }
    
    private func loadHistory() {
        guard let data = UserDefaults.standard.data(forKey: "PhraseHistory"),
              let history = try? JSONDecoder().decode([Phrase].self, from: data) else {
            return
        }
        phraseHistory = history
    }
    
    private func saveToDisk() {
        if let data = try? JSONEncoder().encode(phraseHistory) {
            UserDefaults.standard.set(data, forKey: "PhraseHistory")
        }
    }
}

// MARK: - Haptic Manager

class HapticManager {
    static let shared = HapticManager()
    
    private let light = UIImpactFeedbackGenerator(style: .light)
    private let medium = UIImpactFeedbackGenerator(style: .medium)
    private let heavy = UIImpactFeedbackGenerator(style: .heavy)
    
    enum Style {
        case light, medium, heavy
    }
    
    func impact(_ style: Style) {
        switch style {
        case .light:
            light.impactOccurred()
        case .medium:
            medium.impactOccurred()
        case .heavy:
            heavy.impactOccurred()
        }
    }
    
    func prepare() {
        light.prepare()
        medium.prepare()
        heavy.prepare()
    }
}
