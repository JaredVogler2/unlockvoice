//
//  PredictionViewModel.swift
//  OpenVoice - Enhanced with Phase 6 ML
//
//  Manages word/symbol predictions using CoreML integration
//

import SwiftUI
import Combine

// MARK: - Legacy Prediction Model (Kept for backwards compatibility)
struct Prediction: Identifiable {
    let id = UUID()
    var text: String
    var confidence: Double // 0.0 to 1.0
    var source: PredictionSource
    
    enum PredictionSource {
        case frequency      // Based on usage frequency
        case context        // Context-aware (Phase 6)
        case rag            // RAG system (Phase 8)
        case grammar        // Grammar/sentence completion (Phase 9)
    }
}

// MARK: - Enhanced Prediction ViewModel (Phase 6)

@MainActor
class PredictionViewModel: ObservableObject {
    // MARK: - Published Properties
    @Published var predictions: [MLPrediction] = []
    @Published var legacyPredictions: [Prediction] = []  // Backwards compatibility
    @Published var isLoading = false
    @Published var lastUpdateTime: Date?
    
    // MARK: - Private Properties
    private let mlService = MLPredictionService.shared
    private let analytics = AnalyticsService.shared
    private var cancellables = Set<AnyCancellable>()
    
    // Configuration
    private let maxPredictions = 8
    private let maxDisplayedPredictions = 6
    private let useMLPredictions = true  // Toggle for testing
    
    // MARK: - Initialization
    init() {
        setupSubscriptions()
    }
    
    private func setupSubscriptions() {
        // Subscribe to ML service predictions
        mlService.$predictions
            .receive(on: DispatchQueue.main)
            .sink { [weak self] predictions in
                guard let self = self else { return }
                self.predictions = Array(predictions.prefix(self.maxDisplayedPredictions))
                self.lastUpdateTime = Date()
                
                // Convert to legacy format for backwards compatibility
                self.legacyPredictions = self.convertToLegacyPredictions(predictions)
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Public Methods (Phase 6 - ML Enhanced)
    
    /// Update predictions based on current phrase context
    func updatePredictions(
        currentPhrase: [Symbol],
        allSymbols: [Symbol]
    ) {
        guard useMLPredictions else {
            // Fallback to legacy predictions
            updateLegacyPredictions(for: Phrase(symbols: currentPhrase))
            return
        }
        
        Task {
            isLoading = true
            
            // Extract context from current phrase
            let context = currentPhrase.map { $0.label }
            
            // Get ML predictions
            let mlPredictions = await mlService.predictNext(
                context: context,
                currentSymbols: allSymbols,
                timeOfDay: Date(),
                maxResults: maxDisplayedPredictions
            )
            
            await MainActor.run {
                self.predictions = mlPredictions
                self.isLoading = false
            }
        }
    }
    
    /// Legacy update method (backwards compatible)
    func updatePredictions(for phrase: Phrase) {
        updateLegacyPredictions(for: phrase)
    }
    
    /// Quick predictions for empty context
    func getStarterPredictions(allSymbols: [Symbol]) {
        Task {
            // Use frequency-based predictions when no context
            let quickPredictions = await mlService.getQuickPredictions(
                lastSymbols: [],
                symbols: allSymbols
            )
            
            await MainActor.run {
                self.predictions = quickPredictions
            }
        }
    }
    
    /// User selected a prediction
    func selectPrediction(_ prediction: MLPrediction) {
        // Record that this prediction was accepted
        mlService.recordPredictionAccepted(symbolId: prediction.symbolId)
        
        // Log analytics
        analytics.recordSymbolUsage(
            symbolId: prediction.symbolId,
            label: prediction.label,
            category: prediction.category
        )
    }
    
    /// User did not select any prediction
    func rejectPredictions(context: [String]) {
        // In production, this helps tune the model
        for prediction in predictions {
            mlService.recordPredictionRejected(
                symbolId: prediction.symbolId,
                context: context
            )
        }
    }
    
    /// Refresh predictions with latest usage data
    func refreshPredictions() {
        mlService.refreshModels()
    }
    
    // MARK: - Legacy Prediction Methods (Backwards Compatibility)
    
    private func updateLegacyPredictions(for phrase: Phrase) {
        if phrase.isEmpty {
            legacyPredictions = getMostFrequentPredictions()
        } else {
            legacyPredictions = getContextualPredictions(for: phrase)
        }
    }
    
    private func getMostFrequentPredictions() -> [Prediction] {
        let commonWords = ["I", "want", "need", "help", "yes", "no", "more", "stop"]
        
        return commonWords.prefix(maxPredictions).map { word in
            Prediction(
                text: word,
                confidence: 0.5,
                source: .frequency
            )
        }
    }
    
    private func getContextualPredictions(for phrase: Phrase) -> [Prediction] {
        guard let lastSymbol = phrase.symbols.last else {
            return getMostFrequentPredictions()
        }
        
        let contextMap: [String: [String]] = [
            "I": ["want", "need", "am", "like", "feel"],
            "want": ["to", "eat", "drink", "play", "go"],
            "need": ["help", "bathroom", "break", "rest"],
            "eat": ["food", "snack", "lunch", "dinner"],
            "drink": ["water", "juice", "milk"],
            "feel": ["happy", "sad", "tired", "angry", "good"],
            "go": ["home", "outside", "bathroom", "bed"],
        ]
        
        let nextWords = contextMap[lastSymbol.label.lowercased()] ?? []
        
        return nextWords.prefix(maxPredictions).map { word in
            Prediction(
                text: word,
                confidence: 0.6,
                source: .context
            )
        }
    }
    
    // MARK: - Conversion Methods
    
    private func convertToLegacyPredictions(_ mlPredictions: [MLPrediction]) -> [Prediction] {
        return mlPredictions.map { mlPred in
            Prediction(
                text: mlPred.label,
                confidence: mlPred.confidence,
                source: .context  // Map to context for now
            )
        }
    }
    
    // MARK: - Utility Methods
    
    /// Get confidence color for UI
    func confidenceColor(for confidence: Double) -> Color {
        switch confidence {
        case 0.8...1.0:
            return .green
        case 0.5..<0.8:
            return .orange
        default:
            return .gray
        }
    }
    
    /// Format confidence as percentage
    func formatConfidence(_ confidence: Double) -> String {
        return String(format: "%.0f%%", confidence * 100)
    }
    
    /// Get icon for prediction source
    func sourceIcon(for source: MLPrediction.PredictionSource) -> String {
        switch source {
        case .nGram:
            return "link"
        case .contextual:
            return "clock"
        case .frequency:
            return "chart.bar"
        case .hybrid:
            return "sparkles"
        }
    }
    
    // MARK: - Phase 8: RAG Predictions (Placeholder)
    
    private func getRAGPredictions(for phrase: Phrase) async -> [Prediction] {
        // Will be implemented in Phase 8
        // Queries backend RAG system for personalized predictions
        return []
    }
    
    // MARK: - Phase 9: BERT Grammar (Placeholder)
    
    private func getBERTCompletions(for phrase: Phrase) async -> [Prediction] {
        // Will be implemented in Phase 9
        // Uses BERT for grammatically correct sentence completions
        return []
    }
}

// MARK: - Preview Provider
#if DEBUG
extension PredictionViewModel {
    static var preview: PredictionViewModel {
        let vm = PredictionViewModel()
        vm.predictions = [
            MLPrediction(
                symbolId: "water",
                label: "water",
                category: "food_drink",
                confidence: 0.85,
                source: .hybrid,
                reasoning: "Commonly follows 'want'"
            ),
            MLPrediction(
                symbolId: "help",
                label: "help",
                category: "verbs",
                confidence: 0.72,
                source: .nGram,
                reasoning: "Common at this time"
            ),
            MLPrediction(
                symbolId: "food",
                label: "food",
                category: "food_drink",
                confidence: 0.68,
                source: .frequency,
                reasoning: "Frequently used"
            ),
        ]
        return vm
    }
}
#endif
