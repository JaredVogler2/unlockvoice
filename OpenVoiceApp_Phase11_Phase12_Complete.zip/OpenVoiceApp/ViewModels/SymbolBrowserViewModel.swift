//
//  SymbolBrowserViewModel.swift
//  OpenVoice
//
//  ViewModel for symbol browsing and searching
//

import Foundation
import Combine

class SymbolBrowserViewModel: ObservableObject {
    @Published var searchQuery: String = ""
    @Published var selectedCategory: SymbolCategory? = nil
    @Published var filteredSymbols: [Symbol] = []
    @Published var showFavoritesOnly: Bool = false
    @Published var showRecentsOnly: Bool = false
    
    private var cancellables = Set<AnyCancellable>()
    private let library = SymbolLibraryService.shared
    
    init() {
        setupBindings()
    }
    
    private func setupBindings() {
        // Update filtered symbols when search query or category changes
        Publishers.CombineLatest3($searchQuery, $selectedCategory, $showFavoritesOnly)
            .debounce(for: .milliseconds(300), scheduler: DispatchQueue.main)
            .sink { [weak self] query, category, favoritesOnly in
                self?.updateFilteredSymbols()
            }
            .store(in: &cancellables)
        
        // Listen to library changes
        library.$allSymbols
            .sink { [weak self] _ in
                self?.updateFilteredSymbols()
            }
            .store(in: &cancellables)
        
        library.$favoriteSymbols
            .sink { [weak self] _ in
                if self?.showFavoritesOnly == true {
                    self?.updateFilteredSymbols()
                }
            }
            .store(in: &cancellables)
    }
    
    func updateFilteredSymbols() {
        var symbols: [Symbol]
        
        // Start with appropriate base set
        if showFavoritesOnly {
            symbols = library.favoriteSymbols
        } else if showRecentsOnly {
            symbols = library.recentSymbols
        } else if let category = selectedCategory {
            symbols = library.getSymbols(in: category)
        } else {
            symbols = library.allSymbols
        }
        
        // Apply search filter
        if !searchQuery.isEmpty {
            symbols = library.search(query: searchQuery)
            
            // If category is selected, further filter by category
            if let category = selectedCategory {
                symbols = symbols.filter { $0.category == category }
            }
        }
        
        // Sort by frequency (most used first)
        symbols.sort { $0.frequency > $1.frequency }
        
        filteredSymbols = symbols
    }
    
    func clearFilters() {
        searchQuery = ""
        selectedCategory = nil
        showFavoritesOnly = false
        showRecentsOnly = false
    }
}
