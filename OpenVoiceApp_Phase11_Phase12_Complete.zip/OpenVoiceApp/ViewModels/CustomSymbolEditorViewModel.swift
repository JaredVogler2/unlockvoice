//
//  CustomSymbolEditorViewModel.swift
//  OpenVoice
//
//  ViewModel for creating and editing custom symbols
//

import Foundation
import UIKit
import Combine

class CustomSymbolEditorViewModel: ObservableObject {
    @Published var selectedImage: UIImage?
    @Published var label: String = ""
    @Published var selectedCategory: SymbolCategory = .custom
    @Published var tagsText: String = ""
    
    private var editingSymbol: Symbol?
    private let library = SymbolLibraryService.shared
    
    var tags: [String] {
        tagsText
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }
    
    var canSave: Bool {
        selectedImage != nil && !label.isEmpty
    }
    
    var previewSymbol: Symbol {
        Symbol(
            label: label.isEmpty ? "Preview" : label,
            imageName: "photo", // Placeholder
            category: selectedCategory,
            tags: tags,
            customImageData: selectedImage?.jpegData(compressionQuality: 0.8)
        )
    }
    
    func loadSymbol(_ symbol: Symbol) {
        editingSymbol = symbol
        label = symbol.label
        selectedCategory = symbol.category
        tagsText = symbol.tags.joined(separator: ", ")
        
        if let imageData = symbol.customImageData {
            selectedImage = UIImage(data: imageData)
        }
    }
    
    func save() {
        guard canSave else { return }
        
        let imageData = selectedImage?.jpegData(compressionQuality: 0.8)
        
        if let existing = editingSymbol {
            // Update existing symbol
            var updated = existing
            updated.label = label
            updated.category = selectedCategory
            updated.tags = tags
            updated.customImageData = imageData
            
            library.updateCustomSymbol(updated)
        } else {
            // Create new symbol
            let newSymbol = Symbol(
                label: label,
                imageName: "photo", // Custom symbols use actual image data
                category: selectedCategory,
                tags: tags,
                customImageData: imageData
            )
            
            library.saveCustomSymbol(newSymbol)
        }
        
        // Haptic feedback
        HapticManager.shared.impact(.medium)
    }
}
