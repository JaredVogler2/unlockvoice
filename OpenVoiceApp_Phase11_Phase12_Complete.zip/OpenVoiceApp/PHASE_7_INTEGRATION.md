# 🔌 PHASE 7: INTEGRATION GUIDE

## 📋 Step-by-Step Integration

This guide walks you through integrating the Python backend with your iOS app.

---

## ⏱️ Time Required

- **Backend Setup**: 15 minutes
- **iOS Integration**: 20 minutes
- **Testing**: 15 minutes
- **Total**: ~50 minutes

---

## 🎯 Integration Path

```
1. Setup Backend → 2. Add iOS Service → 3. Update ViewModel → 4. Test → Done!
```

---

## STEP 1: Setup Python Backend (15 min)

### Option A: Docker (Recommended)

```bash
# Navigate to project
cd OpenVoiceApp/PythonBackend

# Start backend
docker-compose up -d

# Verify it's running
curl http://localhost:8000/health

# Should see:
# {"status":"healthy","models_loaded":true,...}
```

### Option B: Local Python

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run server
cd src
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Keep this terminal open
```

### Verify Backend Works

```bash
# Test health
curl http://localhost:8000/health

# Test prediction
curl -X POST http://localhost:8000/api/v1/predict \
  -H "Content-Type: application/json" \
  -d '{"context": ["I", "want"], "max_predictions": 3}'

# Should see predictions with confidence scores
```

---

## STEP 2: Add iOS Service (20 min)

### 2.1 Add APIService to Xcode

1. **Open Xcode project**: `OpenVoiceApp.xcodeproj`

2. **Add file**: 
   - Right-click `Services` folder
   - Select "Add Files to OpenVoiceApp..."
   - Navigate to and select `Services/APIService.swift`
   - ✅ Check "Copy items if needed"
   - ✅ Check "OpenVoiceApp" target
   - Click "Add"

3. **Verify**: Build project (Cmd+B) - should succeed

### 2.2 Configure Base URL

For **Simulator**:
```swift
// No changes needed - uses localhost:8000
```

For **Physical Device** (same WiFi):
```swift
// In APIService.swift, change init():
init(baseURL: String = "http://YOUR_COMPUTER_IP:8000") {
    // Replace YOUR_COMPUTER_IP with actual IP
    // Find IP: macOS → System Settings → Network → WiFi → Details
}
```

---

## STEP 3: Update ViewModel (20 min)

### 3.1 Import APIService

Add to top of `PredictionViewModel.swift`:

```swift
import Foundation

// Add APIService singleton reference
private let apiService = APIService.shared
```

### 3.2 Add Backend-Enhanced Prediction Method

Add this new method to `PredictionViewModel`:

```swift
/// Update predictions using backend when available, fallback to local
func updatePredictionsWithBackend(
    currentPhrase: [Symbol],
    allSymbols: [Symbol]
) async {
    // Try backend first
    if await apiService.checkHealth() {
        do {
            let context = currentPhrase.map { $0.label }
            let timeOfDay = getTimeOfDay()
            
            let response = try await apiService.getPredictions(
                context: context,
                maxPredictions: 10,
                timeOfDay: timeOfDay
            )
            
            // Convert to local format
            let backendPredictions = response.predictions.map { pred in
                MLPrediction(
                    symbolId: pred.text,
                    label: pred.text,
                    confidence: pred.confidence,
                    source: .hybrid
                )
            }
            
            await MainActor.run {
                self.predictions = backendPredictions
            }
            
            print("✅ Backend predictions (\(response.latencyMs)ms)")
            return
            
        } catch {
            print("⚠️ Backend failed, using local: \(error.localizedDescription)")
        }
    }
    
    // Fallback to local CoreML
    self.updatePredictions(currentPhrase: currentPhrase, allSymbols: allSymbols)
}

/// Helper to determine time of day
private func getTimeOfDay() -> String {
    let hour = Calendar.current.component(.hour, from: Date())
    if hour >= 5 && hour < 12 {
        return "morning"
    } else if hour >= 12 && hour < 17 {
        return "afternoon"
    } else if hour >= 17 && hour < 21 {
        return "evening"
    } else {
        return "night"
    }
}
```

### 3.3 Update SymbolGridViewModel

In `SymbolGridViewModel.swift`, update the `selectSymbol` method:

```swift
func selectSymbol(_ symbol: Symbol) {
    currentPhrase.addSymbol(symbol)
    
    // Use async prediction update
    Task {
        await predictionViewModel.updatePredictionsWithBackend(
            currentPhrase: currentPhrase.symbols,
            allSymbols: availableSymbols
        )
    }
    
    // Record to conversation history (for RAG)
    Task {
        if currentPhrase.symbols.count > 2 {
            let text = currentPhrase.symbols.map { $0.label }.joined(separator: " ")
            try? await APIService.shared.addConversation(text: text)
        }
    }
}
```

### 3.4 Add Health Check (Optional)

In `OpenVoiceApp.swift`, add health check on startup:

```swift
@main
struct OpenVoiceApp: App {
    init() {
        // Check backend connection
        Task {
            let connected = await APIService.shared.checkHealth()
            if connected {
                print("✅ Connected to ML backend")
            } else {
                print("⚠️ Backend unavailable - using local predictions")
            }
        }
    }
    
    var body: some Scene {
        // ... existing code ...
    }
}
```

---

## STEP 4: Test Integration (15 min)

### 4.1 Test Backend Connection

Add this to a test view or debug panel:

```swift
Button("Test Backend") {
    Task {
        // Test health
        let healthy = await APIService.shared.checkHealth()
        print("Backend healthy: \(healthy)")
        
        if healthy {
            // Test prediction
            do {
                let response = try await APIService.shared.getPredictions(
                    context: ["I", "want"],
                    maxPredictions: 5
                )
                print("Got \(response.predictions.count) predictions")
                print("Latency: \(response.latencyMs)ms")
            } catch {
                print("Error: \(error)")
            }
        }
    }
}
```

### 4.2 Test Predictions

1. **Run the app** (Cmd+R)
2. **Select symbols** to build a phrase (e.g., "I want")
3. **Check console** for log messages:
   ```
   ✅ Backend predictions (25.3ms)
   ```
4. **Verify predictions appear** in the prediction bar

### 4.3 Test Fallback

1. **Stop the backend**:
   ```bash
   docker-compose down
   ```

2. **In iOS app**, select more symbols
3. **Check console** for fallback message:
   ```
   ⚠️ Backend unavailable - using local predictions
   ```

4. **Verify predictions still appear** (from local CoreML)

5. **Restart backend**:
   ```bash
   docker-compose up -d
   ```

---

## STEP 5: Advanced Features (Optional)

### 5.1 Add Sentence Formation

```swift
Button("Form Sentence") {
    Task {
        let symbols = currentPhrase.symbols.map { $0.label }
        
        do {
            let response = try await APIService.shared.formSentence(
                symbols: symbols,
                addGrammar: true
            )
            
            print("Formed: \(response.formedSentence)")
            print("Confidence: \(response.confidence)")
            
            // Update phrase bar with formed sentence
            await MainActor.run {
                self.formedSentence = response.formedSentence
            }
            
        } catch {
            print("Sentence formation failed: \(error)")
        }
    }
}
```

### 5.2 Add Metrics Display

```swift
Button("Show Metrics") {
    Task {
        do {
            let metrics = try await APIService.shared.getMetrics()
            print("Backend Metrics:")
            print("- Predictions served: \(metrics["predictions_served"] ?? 0)")
            print("- Sentences formed: \(metrics["sentences_formed"] ?? 0)")
            print("- Average latency: \(metrics["average_latency_ms"] ?? 0)ms")
        } catch {
            print("Failed to get metrics")
        }
    }
}
```

---

## ✅ Verification Checklist

After integration, verify:

- [ ] Backend server is running
- [ ] iOS app can connect to backend
- [ ] Predictions come from backend (check logs)
- [ ] Predictions are accurate and relevant
- [ ] Fallback to local works when backend is down
- [ ] No UI blocking or lag
- [ ] Confidence scores display correctly
- [ ] Sentence formation works (if enabled)
- [ ] Conversations saved to RAG (if enabled)

---

## 🎨 UI Enhancements (Optional)

### Show Backend Status

```swift
// Add to your main view
HStack {
    Circle()
        .fill(isBackendConnected ? Color.green : Color.gray)
        .frame(width: 8, height: 8)
    Text(isBackendConnected ? "Backend Active" : "Local Mode")
        .font(.caption)
        .foregroundColor(.secondary)
}
.task {
    isBackendConnected = await APIService.shared.checkHealth()
}
```

### Show Prediction Source

```swift
// In prediction card
Text(prediction.source)
    .font(.caption2)
    .foregroundColor(prediction.source == "hybrid" ? .blue : .gray)
```

---

## 🐛 Troubleshooting

### Issue: "Connection refused"

**Cause**: Backend not running or wrong URL

**Fix**:
```bash
# Check backend
curl http://localhost:8000/health

# Restart if needed
docker-compose restart
```

### Issue: "No predictions from backend"

**Cause**: Models not loaded

**Fix**:
```bash
# Check backend logs
docker-compose logs api

# Look for: "✅ All models loaded successfully!"
```

### Issue: "Predictions slow"

**Cause**: Network latency or slow models

**Fix**:
```python
# Increase workers in docker-compose.yml
CMD ["uvicorn", "src.main:app", "--workers", "8"]
```

### Issue: "Physical device can't connect"

**Cause**: Wrong IP address

**Fix**:
```bash
# Find your computer's IP
ifconfig | grep "inet " | grep -v 127.0.0.1

# Use that IP in APIService
let apiService = APIService(baseURL: "http://192.168.1.XXX:8000")
```

---

## 📊 Performance Optimization

### Reduce Latency

```swift
// In APIService, adjust timeouts
let config = URLSessionConfiguration.default
config.timeoutIntervalForRequest = 5.0  // Faster timeout
config.timeoutIntervalForResource = 10.0
```

### Cache Predictions

```swift
// Add caching layer
private var predictionCache: [String: PredictionResponse] = [:]

func getPredictionsCached(context: [String]) async throws -> PredictionResponse {
    let key = context.joined(separator: "_")
    
    if let cached = predictionCache[key] {
        return cached
    }
    
    let response = try await getPredictions(context: context)
    predictionCache[key] = response
    return response
}
```

---

## 🚀 Deployment Tips

### For Development
- Use `localhost:8000`
- Backend runs on your Mac
- Easy debugging

### For TestFlight
- Deploy backend to cloud (AWS, GCP, Azure)
- Use production URL: `https://api.yourdomain.com`
- Add authentication

### For App Store
- Backend optional (works without it)
- Mention in privacy policy if used
- Provide self-hosting option

---

## 📚 Next Steps

After successful integration:

1. ✅ Monitor backend metrics
2. ✅ Test with real users
3. ✅ Optimize for your use case
4. ✅ Consider deploying to cloud
5. ✅ Move to Phase 8 (Advanced RAG)

---

## 🎯 Success Criteria

Integration is successful when:

- ✅ App uses backend when available
- ✅ App works without backend
- ✅ No crashes or blocking
- ✅ Predictions are relevant
- ✅ Latency <100ms
- ✅ Fallback is seamless

---

**Integration Complete!** 🎉

Your app now has optional, powerful backend ML!

**Next**: Test thoroughly and move to Phase 8 (Advanced RAG)

---

*Made with 🔌 for seamless integration*
